<?php
/**
 * Plugin Name: Odoo Commerce Sync (WordPress Plugin)
 * Description: Fast, signed WooCommerce product, variant, customer, confirmed-order and Odoo warehouse stock synchronization.
 * Version: 2.1.6
 * Author: mazen
 * License: GPL-2.0-or-later
 * Requires at least: 6.5
 * Requires PHP: 8.0
 * Requires Plugins: woocommerce
 * WC requires at least: 8.2
 * Text Domain: odoo-woo-stock-sync
 */
defined('ABSPATH') || exit;
define('MW_SYNC_VERSION', '2.1.6');
define('MW_SYNC_FILE', __FILE__);
foreach (['config', 'queue', 'payload', 'events', 'stock', 'admin'] as $part) {
    require_once __DIR__ . '/includes/class-mw-' . $part . '.php';
}
register_activation_hook(__FILE__, ['MW_Queue', 'install']);
register_deactivation_hook(__FILE__, function () {
    if (function_exists('as_unschedule_all_actions')) {
        as_unschedule_all_actions('mw_sync_tick', [], 'mw-sync');
        as_unschedule_all_actions('mw_sync_wake', [], 'mw-sync');
    }
    wp_clear_scheduled_hook('mw_sync_tick');
    wp_clear_scheduled_hook('mw_sync_wake');
});
add_action('before_woocommerce_init', function () {
    if (class_exists('Automattic\\WooCommerce\\Utilities\\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
    }
});
add_action('plugins_loaded', function () {
    if (!class_exists('WooCommerce')) { return; }
    if (get_option('mw_sync_schema') !== MW_SYNC_VERSION) { MW_Queue::install(); }
    MW_Events::boot();
    MW_Stock::boot();
    MW_Admin::boot();
    add_action('mw_sync_tick', ['MW_Queue', 'run']);
    add_action('mw_sync_wake', ['MW_Queue', 'run']);
    add_action('init', ['MW_Queue', 'schedule'], 30);
}, 30);
