<?php
defined('ABSPATH') || exit;
final class MW_Events {
    private static function historical(WC_Order $o): bool {
        $row = MW_Queue::row('order', $o->get_id());
        if ($row) { return (bool) $row->historical; }
        $date = $o->get_date_created();
        $cutover = MW_Config::get('cutover');
        return $date && $cutover && $date->getTimestamp() < strtotime($cutover . ' UTC');
    }
    private static function rma_exchange_child(WC_Order $o): bool {
        return (bool) $o->get_meta('wps_wrma_exchange_order', true);
    }
    public static function boot(): void {
        foreach (['woocommerce_new_product', 'woocommerce_update_product', 'woocommerce_new_product_variation', 'woocommerce_update_product_variation'] as $hook) {
            add_action($hook, [__CLASS__, 'product'], 100);
        }
        add_action('trashed_post', [__CLASS__, 'product']);
        add_action('untrashed_post', [__CLASS__, 'product']);
        foreach (['woocommerce_created_customer', 'woocommerce_update_customer', 'profile_update'] as $hook) { add_action($hook, [__CLASS__, 'customer'], 100); }
        add_action('user_register', [__CLASS__, 'customer'], 100);
        add_action('delete_comment', [__CLASS__, 'delete_note'], 100, 2);
        add_action('woocommerce_new_order_item', [__CLASS__, 'saved_item'], 100, 3);
        add_action('woocommerce_update_order_item', [__CLASS__, 'saved_item'], 100, 3);
        add_action('woocommerce_before_delete_order_item', [__CLASS__, 'deleted_item'], 100);
        add_action('woocommerce_customer_save_address', [__CLASS__, 'customer'], 100);
        foreach (['added_user_meta', 'updated_user_meta', 'deleted_user_meta'] as $hook) { add_action($hook, [__CLASS__, 'user_meta'], 100, 4); }
        add_action('woocommerce_after_order_object_save', [__CLASS__, 'order'], 100);
        add_action('woocommerce_order_status_changed', [__CLASS__, 'status'], 100, 4);
        foreach (['woocommerce_update_order', 'woocommerce_new_order', 'woocommerce_payment_complete', 'woocommerce_saved_order_items'] as $hook) { add_action($hook, [__CLASS__, 'order'], 100); }
        add_action('woocommerce_order_refunded', [__CLASS__, 'order'], 100);
        add_action('woocommerce_refund_deleted', [__CLASS__, 'refund_deleted'], 100, 2);
        add_action('woocommerce_order_note_added', [__CLASS__, 'note'], 100, 2);
        foreach (['added_post_meta', 'updated_post_meta', 'deleted_post_meta'] as $hook) { add_action($hook, [__CLASS__, 'post_meta'], 100, 4); }
        foreach (['added_order_item_meta', 'updated_order_item_meta', 'deleted_order_item_meta'] as $hook) { add_action($hook, [__CLASS__, 'item_meta'], 100, 4); }
        // Record a guard before core stock deductions; no API/network calls on checkout.
        add_filter('woocommerce_can_reduce_order_stock', [__CLASS__, 'before_reduce'], 100, 2);
        add_action('woocommerce_reduce_order_stock', [__CLASS__, 'stock_reduced'], 100);
        add_action('woocommerce_restore_order_stock', [__CLASS__, 'restored'], 100);
        // WPS RMA Pro fires this after it marks the pending exchange as complete
        // and persists the authoritative FROM/TO lines. We only enqueue work;
        // approval itself never waits on Odoo/network I/O.
        add_action('wps_rma_exchange_request_accept', [__CLASS__, 'exchange_approved'], 100, 2);
    }
    public static function exchange_approved($refund_details, $order_id): void {
        if (!MW_Config::enabled()) { return; }
        $order = wc_get_order(absint($order_id));
        if (!$order instanceof WC_Order) { return; }

        // Prefer the RMA helper because it supports both HPOS and legacy storage.
        $details = function_exists('wps_rma_pro_get_meta_data')
            ? wps_rma_pro_get_meta_data($order->get_id(), 'wps_wrma_exchange_product', true)
            : $order->get_meta('wps_wrma_exchange_product', true);
        if (!is_array($details) || !$details) { return; }

        // Approval changes exactly one pending request to complete. If the hook is
        // repeated, choosing the most recently approved request gives us the same
        // request key and the queue's unique key prevents duplicate delivery.
        $selected_key = null;
        $selected = null;
        $best_approved = -1;
        foreach ($details as $request_key => $detail) {
            if (!is_array($detail) || ($detail['status'] ?? '') !== 'complete') { continue; }
            $approved = absint($detail['approve'] ?? 0);
            if ($approved >= $best_approved) {
                $best_approved = $approved;
                $selected_key = (string) $request_key;
                $selected = $detail;
            }
        }
        if ($selected_key === null || !is_array($selected)) { return; }

        try {
            $payload = MW_Payload::exchange_from_rma($order, $selected);
            MW_Queue::enqueue_exchange($order->get_id(), $selected_key, $payload);
        } catch (Throwable $e) {
            // Never break the RMA approval screen. Surface the failure in the PHP
            // error log without including customer addresses or gateway data.
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Odoo exchange queue: ' . sanitize_text_field($e->getMessage()));
            }
        }
    }

    public static function product($id): void {
        if (MW_Queue::$importing_stock) { return; }
        $id = $id instanceof WC_Product ? $id->get_id() : absint($id);
        if (in_array(get_post_type($id), ['product', 'product_variation'], true)) { MW_Queue::touch('product', $id); }
    }
    public static function customer($id): void { MW_Queue::touch('customer', absint($id)); }
    public static function user_meta($meta_id, $id, $key, $value = null): void {
        $extra = array_filter(array_map('trim', preg_split('/[\r\n,]+/', (string) MW_Config::get('extra_customer_meta', ''))));
        if (preg_match('/^_?(billing_|shipping_|first_name|last_name|display_name|delivery_|national_address|sa_na_)/', (string) $key) || in_array($key, $extra, true)) { self::customer($id); }
    }
    public static function status($id, $from, $to, $order): void {
        if (!MW_Config::enabled()) { return; }
        $order = $order instanceof WC_Order ? $order : wc_get_order(absint($id));
        if ($order instanceof WC_Order && self::rma_exchange_child($order)) { return; }
        $known = MW_Queue::row('order', (int) $id);
        if ($to === 'processing' || $from === 'processing' || ($known && $known->confirmed_at)) {
            MW_Queue::touch('order', (int) $id, self::historical($order), true);
            self::order($id);
        }
    }
    public static function order($id): void {
        if (!MW_Config::enabled()) { return; }
        $o = $id instanceof WC_Order ? $id : wc_get_order(absint($id));
        if (!$o || !$o instanceof WC_Order || self::rma_exchange_child($o)) { return; }
        $known = MW_Queue::row('order', $o->get_id());
        $confirmed = $o->has_status('processing') || ($known && $known->confirmed_at);
        if (!$confirmed) { return; }
        $version = MW_Queue::touch('order', $o->get_id(), self::historical($o), true);
        $row = MW_Queue::row('order', $o->get_id());
        if (!$row->historical) {
            foreach ($o->get_items() as $item) {
                $p = $item->get_product();
                if ($p && !$p->is_virtual() && $p->get_stock_managed_by_id()) {
                    MW_Queue::hold($o->get_id(), $p->get_stock_managed_by_id(), $version);
                }
            }
        }
    }
    public static function before_reduce($allowed, $o) {
        if (!$allowed || !MW_Config::enabled() || !$o instanceof WC_Order || self::rma_exchange_child($o)) { return $allowed; }
        $version = MW_Queue::touch('order', $o->get_id(), self::historical($o), $o->has_status('processing'));
        $row = MW_Queue::row('order', $o->get_id());
        if ($row && !$row->historical) {
            foreach ($o->get_items() as $item) {
                $p = $item->get_product();
                if ($p && $p->managing_stock() && !$item->get_meta('_reduced_stock', true)) {
                    MW_Queue::hold($o->get_id(), $p->get_stock_managed_by_id(), $version);
                }
            }
        }
        return $allowed;
    }
    public static function stock_reduced($o): void { self::order($o); }
    public static function restored($o): void {
        if (!$o instanceof WC_Order) { $o = wc_get_order($o); }
        if (!$o) { return; }
        $row = MW_Queue::row('order', $o->get_id());
        if ($row && $row->confirmed_at) { self::order($o); }
        else {
            global $wpdb; $wpdb->delete(MW_Config::table('holds'), ['order_id' => $o->get_id()], ['%d']);
        }
    }
    public static function refund_deleted($refund_id, $order_id): void { self::order($order_id); }
    public static function note($note_id, $o): void { self::order($o); }
    public static function post_meta($meta_id, $id, $key, $value = null): void {
        if (MW_Queue::$importing_stock || MW_Payload::secret_key((string) $key)) { return; }
        if (get_post_type($id) === 'shop_order') { self::order($id); }
        elseif (in_array(get_post_type($id), ['product', 'product_variation'], true) && in_array($key, ['_sku', '_price', '_regular_price', '_sale_price', '_global_unique_id', '_thumbnail_id', '_product_image_gallery'], true)) { self::product($id); }
    }
    public static function saved_item($item_id, $item, $order_id): void { self::order($order_id); }
    public static function deleted_item($item_id): void { self::order(wc_get_order_id_by_order_item_id($item_id)); }
    public static function delete_note($comment_id, $comment): void {
        if ($comment && $comment->comment_type === 'order_note') { self::order((int) $comment->comment_post_ID); }
    }
    public static function item_meta($meta_id, $item_id, $key, $value = null): void {
        if (!MW_Config::enabled() || MW_Payload::secret_key((string) $key)) { return; }
        $id = wc_get_order_id_by_order_item_id($item_id);
        if ($id) { self::order($id); }
    }
}
