<?php
defined('ABSPATH') || exit;
final class MW_Config {
    public static function all(): array {
        return wp_parse_args(get_option('mw_sync_settings', []), [
            'enabled' => 0, 'stock_enabled' => 0, 'url' => '',
            'store_key' => '', 'out_secret' => '', 'in_secret' => '',
            'worker_batch' => 30, 'network_batch' => 10, 'scan_batch' => 100,
            'timeout' => 8, 'images' => 1,
            'extra_order_meta' => '', 'extra_customer_meta' => '', 'extra_product_meta' => '',
            'history_statuses' => 'processing,completed',
            'cutover' => '',
        ]);
    }
    public static function get(string $key, $default = null) { return self::all()[$key] ?? $default; }
    public static function enabled(): bool { return (bool) self::get('enabled'); }
    public static function table(string $suffix): string { global $wpdb; return $wpdb->prefix . 'mw_sync_' . $suffix; }
    public static function lock(string $name, int $wait = 0): bool {
        global $wpdb;
        return '1' === (string) $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, %d)', 'mw:' . substr(hash('sha256', $wpdb->prefix . $name), 0, 48), $wait));
    }
    public static function unlock(string $name): void {
        global $wpdb;
        $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', 'mw:' . substr(hash('sha256', $wpdb->prefix . $name), 0, 48)));
    }
    public static function iso($date): ?string {
        return $date instanceof DateTimeInterface ? gmdate('Y-m-d\\TH:i:s\\Z', $date->getTimestamp()) : null;
    }
    public static function money($value): string { return wc_format_decimal($value, wc_get_price_decimals()); }
    public static function json($data): string {
        $json = wp_json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if (false === $json) { throw new RuntimeException('JSON encoding failed.'); }
        return $json;
    }
    public static function post(array $data): array {
        $url = (string) self::get('url');
        if (strtolower((string) wp_parse_url($url, PHP_URL_SCHEME)) !== 'https' || !wp_http_validate_url($url)) {
            throw new RuntimeException('Configure a public HTTPS Odoo endpoint. Private-network endpoints require a reviewed transport customization.');
        }
        $raw = self::json($data);
        if (strlen($raw) > 2097152) { throw new RuntimeException('Payload exceeds 2 MiB. Review oversized custom metadata/images.'); }
        $ts = (string) time();
        $secret = (string) self::get('out_secret');
        if (strlen($secret) < 32) { throw new RuntimeException('Outgoing HMAC secret must contain at least 32 characters.'); }
        $r = wp_safe_remote_post($url, [
            'timeout' => max(3, min(20, (int) self::get('timeout'))),
            'redirection' => 0, 'sslverify' => true, 'limit_response_size' => 524288,
            'headers' => ['Content-Type' => 'application/json; charset=utf-8',
                'X-MW-Store' => self::get('store_key'), 'X-MW-Timestamp' => $ts,
                'X-MW-Signature' => hash_hmac('sha256', $ts . '.' . $raw, $secret)],
            'body' => $raw, 'data_format' => 'body',
        ]);
        if (is_wp_error($r)) { throw new RuntimeException('Network error: ' . $r->get_error_code()); }
        $status = wp_remote_retrieve_response_code($r);
        $body = json_decode(wp_remote_retrieve_body($r), true);
        if ($status < 200 || $status >= 300 || !is_array($body) || empty($body['ok'])) {
            throw new RuntimeException('Odoo HTTP ' . $status . '; code=' . sanitize_key(is_array($body) ? ($body['error'] ?? 'invalid_reply') : 'invalid_reply'));
        }
        return $body;
    }
}
