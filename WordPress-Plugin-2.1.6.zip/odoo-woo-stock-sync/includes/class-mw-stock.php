<?php
defined('ABSPATH') || exit;
final class MW_Stock {
    public static function boot(): void {
        add_action('rest_api_init', function () {
            register_rest_route('mw-sync/v2', '/stock', [
                'methods' => 'POST', 'permission_callback' => [__CLASS__, 'authorize'], 'callback' => [__CLASS__, 'receive'],
            ]);
        });
    }
    public static function authorize(WP_REST_Request $r) {
        if (!MW_Config::enabled()) { return new WP_Error('mw_disabled', 'Connector disabled.', ['status' => 503]); }
        $raw = $r->get_body();
        if (!$raw || strlen($raw) > 1048576) { return new WP_Error('mw_size', 'Invalid body size.', ['status' => 413]); }
        $secret = (string) MW_Config::get('in_secret');
        $ts = (string) $r->get_header('x-mw-timestamp');
        $sig = (string) $r->get_header('x-mw-signature');
        $store = (string) $r->get_header('x-mw-store');
        if (strlen($secret) < 32 || !ctype_digit($ts) || abs(time() - (int) $ts) > 300 ||
            !hash_equals((string) MW_Config::get('store_key'), $store) ||
            !hash_equals(hash_hmac('sha256', $ts . '.' . $raw, $secret), $sig)) {
            return new WP_Error('mw_auth', 'Authentication failed.', ['status' => 401]);
        }
        return true;
    }
    public static function receive(WP_REST_Request $r) {
        $d = json_decode($r->get_body(), true);
        if (!is_array($d) || ($d['schema'] ?? null) !== 2 || ($d['store'] ?? '') !== MW_Config::get('store_key') ||
            !is_array($d['items'] ?? null) || count($d['items']) > 100 || !is_array($d['order_acks'] ?? []) || count($d['order_acks'] ?? []) > 100) {
            return new WP_Error('mw_payload', 'Invalid stock payload.', ['status' => 400]);
        }
        $out = ['ok' => true, 'items' => [], 'acknowledged' => []];
        foreach ($d['order_acks'] ?? [] as $ack) {
            if (is_array($ack) && MW_Queue::acknowledge($ack)) { $out['acknowledged'][] = ['order_id' => (int) $ack['order_id'], 'source_version' => (int) $ack['source_version']]; }
        }
        $parents = [];
        foreach ($d['items'] as $item) {
            if (!is_array($item)) { $out['items'][] = ['product_id' => 0, 'version' => 0, 'status' => 'error', 'code' => 'invalid_item']; continue; }
            $id = absint($item['product_id'] ?? 0); $version = absint($item['version'] ?? 0);
            $status = 'error'; $message = 'invalid_item';
            if (MW_Config::get('stock_enabled') && $id && $version && isset($item['quantity']) && is_numeric($item['quantity']) && is_finite((float) $item['quantity']) && (float) $item['quantity'] >= 0 && (float) $item['quantity'] <= 1000000000) {
                if (MW_Config::lock('stock:' . $id)) {
                    try { [$status, $message, $parent] = self::apply($id, $version, $item); if ($parent) { $parents[$parent] = true; } }
                    catch (Throwable $e) { $status = 'error'; $message = 'stock_write_failed'; }
                    finally { MW_Config::unlock('stock:' . $id); MW_Queue::$importing_stock = false; }
                } else { $status = 'deferred'; $message = 'busy'; }
            } elseif (!MW_Config::get('stock_enabled')) { $status = 'deferred'; $message = 'stock_sync_disabled'; }
            $out['items'][] = ['product_id' => $id, 'version' => $version, 'status' => $status, 'code' => $message];
        }
        MW_Queue::$importing_stock = true;
        try {
            foreach (array_keys($parents) as $id) { WC_Product_Variable::sync($id); wc_delete_product_transients($id); }
        } finally { MW_Queue::$importing_stock = false; }
        return new WP_REST_Response($out, 200);
    }
    private static function apply(int $id, int $version, array $item): array {
        global $wpdb;
        $t = MW_Config::table('stock'); $h = MW_Config::table('holds');
        $last = (int) $wpdb->get_var($wpdb->prepare("SELECT version FROM $t WHERE product_id=%d", $id));
        if ($version <= $last) { return ['stale', '', 0]; }
        $p = wc_get_product($id);
        if (!$p || $p->get_sku() !== (string) ($item['sku'] ?? '') || !$p->get_sku()) { return ['error', 'sku_or_product_mismatch', 0]; }
        if ($p->is_type('variable') || $p->is_virtual()) { return ['error', 'not_a_stock_leaf', 0]; }
        if ($p->is_type('variation') && $p->get_stock_managed_by_id() !== $id) { return ['error', 'variation_must_manage_own_stock', 0]; }
        $qty = wc_stock_amount($item['quantity']);
        if ((float) $qty !== (float) $item['quantity']) { return ['error', 'unit_precision_mismatch', 0]; }
        MW_Queue::$importing_stock = true;
        if (!$p->managing_stock()) {
            $blocked = $wpdb->get_var($wpdb->prepare("SELECT order_id FROM $h WHERE product_id=%d AND (stock_version=0 OR stock_version>%d) LIMIT 1", $id, $version));
            if ($blocked) { return ['deferred', 'waiting_for_order_reservation', 0]; }
            $existing = $p->get_stock_quantity();
            $p->set_manage_stock(true); $p->set_stock_quantity(is_numeric($existing) ? $existing : 0); $p->save();
        }
        // Read the actual stock before the guard query. Apply an atomic delta, not a blind SET:
        // a new local reduction after this read is preserved by the WooCommerce increment.
        $current = $wpdb->get_var($wpdb->prepare("SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id=%d AND meta_key='_stock' LIMIT 1", $id));
        if ($current === null || !is_numeric($current)) { return ['error', 'missing_stock_value', 0]; }
        $blocked = $wpdb->get_var($wpdb->prepare("SELECT order_id FROM $h WHERE product_id=%d AND (stock_version=0 OR stock_version>%d) LIMIT 1", $id, $version));
        if ($blocked) { return ['deferred', 'waiting_for_order_reservation', 0]; }
        $delta = (float) $qty - (float) $current;
        $new = wc_update_product_stock($p, abs($delta), $delta >= 0 ? 'increase' : 'decrease');
        if (is_wp_error($new) || $new === null) { return ['error', 'stock_write_failed', 0]; }
        $status = (float) $new > 0 ? 'instock' : ($p->backorders_allowed() ? 'onbackorder' : 'outofstock');
        if ($p->get_stock_status() !== $status) { wc_update_product_stock_status($id, $status); }
        $wpdb->query($wpdb->prepare("INSERT INTO $t (product_id,version,quantity,updated_at) VALUES (%d,%d,%f,%s)
            ON DUPLICATE KEY UPDATE version=VALUES(version),quantity=VALUES(quantity),updated_at=VALUES(updated_at)", $id, $version, $qty, gmdate('Y-m-d H:i:s')));
        $wpdb->query($wpdb->prepare("DELETE FROM $h WHERE product_id=%d AND stock_version>0 AND stock_version<=%d", $id, $version));
        return ['applied', '', $p->is_type('variation') ? $p->get_parent_id() : 0];
    }
}
