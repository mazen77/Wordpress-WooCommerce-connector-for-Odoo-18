<?php
defined('ABSPATH') || exit;
final class MW_Payload {
    public static function build(string $kind, int $id, $row): ?array {
        if ($kind === 'product') { $p = wc_get_product($id); return $p ? self::product($p) : null; }
        if ($kind === 'customer') { return self::customer($id); }
        if ($kind === 'exchange') {
            global $wpdb;
            $t = MW_Config::table('exchanges');
            $raw = $wpdb->get_var($wpdb->prepare("SELECT payload FROM $t WHERE id=%d", $id));
            $data = $raw ? json_decode($raw, true) : null;
            return is_array($data) ? $data : null;
        }
        $o = wc_get_order($id);
        if (!$o || !$o instanceof WC_Order || !$row->confirmed_at) { return null; }
        // WPS RMA creates a replacement Woo order after exchange approval. That
        // child order is transport detail, not a second customer sale for Odoo.
        if ($o->get_meta('wps_wrma_exchange_order', true)) { return null; }
        return self::order($o, $row);
    }
    public static function clean_text($value): string {
        $text = html_entity_decode((string) $value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = function_exists('wp_strip_all_tags') ? wp_strip_all_tags($text, true) : strip_tags($text);
        $text = str_replace(["\xC2\xA0", "\u{00A0}"], ' ', $text);
        $text = preg_replace('/[\s\x{200B}\x{FEFF}]+/u', ' ', $text);
        return trim((string) $text);
    }
    public static function safe_value($value, int $depth = 0) {
        if ($depth > 8) { throw new RuntimeException('Custom metadata nesting exceeds the safe limit.'); }
        if ($value instanceof DateTimeInterface) { return MW_Config::iso($value); }
        if (is_array($value)) {
            $out = [];
            foreach ($value as $k => $v) {
                if (self::secret_key((string) $k)) { continue; }
                $out[$k] = self::safe_value($v, $depth + 1);
            }
            return $out;
        }
        if (is_scalar($value) || is_null($value)) { return $value; }
        return null;
    }
    public static function secret_key(string $key): bool {
        return (bool) preg_match('/password|passwd|secret|token|authorization|api.?key|access.?key|license.?key|cookie|session|nonce|private.?key|card.?number|credit.?card|cc.?number|security.?code|account.?pin|client.?info|credential|(?:^|[^a-z])(?:pan|cvv|cvc|pin)(?:$|[^a-z])|cryptogram|raw.?response|gateway.?response|payment.?payload/i', $key);
    }
    public static function metadata($object, string $kind): array {
        $out = [];
        $extra = array_filter(array_map('trim', preg_split('/[\r\n,]+/', (string) MW_Config::get('extra_' . $kind . '_meta', ''))));
        foreach ($object->get_meta_data() as $meta) {
            $data = $meta->get_data(); $key = (string) ($data['key'] ?? '');
            if (!$key || self::secret_key($key)) { continue; }
            $business = (bool) preg_match('/^_?(billing_|shipping_|delivery_|tracking_|shipment_|wc_order_attribution_|wc_shipment_tracking_items|refunded_item_id)/i', $key);
            $public_line = $kind === 'line' && $key[0] !== '_';
            if ($business || $public_line || in_array($key, $extra, true)) {
                $value = self::safe_value($data['value'] ?? null);
                if (strlen(MW_Config::json($value)) > 65536) { throw new RuntimeException('A selected metadata value exceeds 64 KiB; review the metadata allowlist.'); }
                $out[] = ['key' => $key, 'value' => $value];
            }
        }
        return apply_filters('mw_sync_safe_metadata', $out, $object, $kind);
    }
    private static function image(int $id, bool $inline): ?array {
        if (!$id) { return null; }
        $src = wp_get_attachment_image_src($id, 'large');
        $url = $src ? $src[0] : wp_get_attachment_url($id);
        if (!$url) { return null; }
        $out = ['id' => $id, 'url' => esc_url_raw($url), 'alt' => self::clean_text(get_post_meta($id, '_wp_attachment_image_alt', true)), 'name' => self::clean_text(get_the_title($id))];
        if ($inline && MW_Config::get('images')) {
            $full = get_attached_file($id);
            $meta = wp_get_attachment_metadata($id);
            $file = !empty($meta['sizes']['large']['file']) && $full ? dirname($full) . '/' . $meta['sizes']['large']['file'] : $full;
            $uploads = wp_upload_dir();
            $real = $file ? realpath($file) : false;
            $base = realpath($uploads['basedir']);
            if ($real && $base && str_starts_with($real, $base . DIRECTORY_SEPARATOR) && is_readable($real)) {
                $size = filesize($real); $mime = wp_check_filetype($real)['type'];
                if ($size > 0 && $size <= 524288 && in_array($mime, ['image/jpeg', 'image/png', 'image/webp'], true)) {
                    $bytes = file_get_contents($real);
                    $out['content_b64'] = base64_encode($bytes);
                    $out['sha256'] = hash('sha256', $bytes);
                    $out['mime'] = $mime;
                } else { $out['binary_note'] = 'URL retained; local file exceeds 512 KiB or has an unsupported format.'; }
            } else { $out['binary_note'] = 'URL retained; media is not present in local uploads.'; }
        }
        return $out;
    }
    private static function attribute_payload(WC_Product $p, ?WC_Product $base = null): array {
        $out = [];
        $base = $base ?: $p;
        foreach ($p->get_attributes() as $key => $attribute) {
            if ($attribute instanceof WC_Product_Attribute) {
                $name = (string) $attribute->get_name();
                $options = [];
                if ($attribute->is_taxonomy()) {
                    foreach ($attribute->get_options() as $term_id) {
                        $term = get_term((int) $term_id, $name);
                        if ($term && !is_wp_error($term)) {
                            $options[] = ['key' => (string) $term->slug, 'label' => self::clean_text($term->name)];
                        }
                    }
                } else {
                    foreach ($attribute->get_options() as $value) {
                        $label = self::clean_text($value);
                        if ($label !== '') { $options[] = ['key' => $label, 'label' => $label]; }
                    }
                }
                $out[] = [
                    'key' => $name,
                    'label' => self::clean_text(wc_attribute_label($name, $base)),
                    'variation' => (bool) $attribute->get_variation(),
                    'visible' => (bool) $attribute->get_visible(),
                    'taxonomy' => (bool) $attribute->is_taxonomy(),
                    'options' => $options,
                ];
                continue;
            }
            $name = (string) $key;
            $raw = (string) $attribute;
            $label = self::clean_text(wc_attribute_label($name, $base));
            $value_label = self::clean_text($raw);
            if (taxonomy_exists($name) && $raw !== '') {
                $term = get_term_by('slug', $raw, $name);
                if ($term && !is_wp_error($term)) { $value_label = self::clean_text($term->name); }
            }
            $out[] = [
                'key' => $name,
                'label' => $label ?: self::clean_text($name),
                'variation' => true,
                'taxonomy' => taxonomy_exists($name),
                'value_key' => $raw,
                'value_label' => $value_label,
            ];
        }
        return $out;
    }
    public static function product(WC_Product $p, bool $embedded = false): array {
        $d = self::safe_value($p->get_data());
        foreach (['meta_data', 'attributes', 'downloads', 'stock_quantity', 'stock_status', 'total_sales', 'rating_counts', 'average_rating', 'review_count', 'date_modified', 'date_created'] as $key) { unset($d[$key]); }
        $base = $p->is_type('variation') ? wc_get_product($p->get_parent_id()) : $p;
        $d['id'] = $p->get_id(); $d['type'] = $p->get_type(); $d['parent_id'] = $p->get_parent_id();
        $d['name'] = self::clean_text($p->get_name()); $d['sku'] = trim((string) $p->get_sku());
        $d['currency'] = get_woocommerce_currency();
        $d['price_ex_tax'] = MW_Config::money(wc_get_price_excluding_tax($p));
        $d['prices_include_tax'] = wc_prices_include_tax();
        $d['weight_unit'] = get_option('woocommerce_weight_unit', 'kg');
        $d['dimension_unit'] = get_option('woocommerce_dimension_unit', 'cm');
        $d['weight_kg'] = $p->get_weight() !== '' ? wc_get_weight((float) $p->get_weight(), 'kg') : null;
        $d['permalink'] = get_permalink($p->get_id());
        $d['global_unique_id'] = method_exists($p, 'get_global_unique_id') ? $p->get_global_unique_id() : '';
        $d['metadata'] = self::metadata($p, 'product');
        $d['attributes'] = self::attribute_payload($p, $base ?: $p);
        $d['parent_name'] = $base ? self::clean_text($base->get_name()) : '';
        $d['categories'] = []; $d['tags'] = [];
        if ($base) {
            foreach ($base->get_category_ids() as $cid) {
                $term = get_term($cid, 'product_cat');
                if (!$term || is_wp_error($term)) { continue; }
                $path = [];
                foreach (array_reverse(get_ancestors($cid, 'product_cat', 'taxonomy')) as $parent) {
                    $pt = get_term($parent, 'product_cat');
                    if ($pt && !is_wp_error($pt)) { $path[] = ['id' => $pt->term_id, 'name' => self::clean_text($pt->name)]; }
                }
                $path[] = ['id' => $term->term_id, 'name' => self::clean_text($term->name)];
                $d['categories'][] = ['id' => $term->term_id, 'name' => self::clean_text($term->name), 'slug' => $term->slug, 'path' => $path];
            }
            $d['tags'] = array_values(array_map([__CLASS__, 'clean_text'], wc_get_product_terms($base->get_id(), 'product_tag', ['fields' => 'names'])));
        }
        $image_id = $p->get_image_id();
        if (!$image_id && $base) { $image_id = $base->get_image_id(); }
        $d['images'] = [];
        $image = self::image((int) $image_id, !$embedded && !$p->is_type('variation'));
        if ($image) { $d['images'][] = $image; }
        if ($base) {
            $gallery_ids = $base->get_gallery_image_ids();
            foreach (array_slice($gallery_ids, 0, 50) as $gid) {
                $image = self::image((int) $gid, false);
                if ($image && $gid !== $image_id) { $d['images'][] = $image; }
            }
            $d['gallery_has_more'] = count($gallery_ids) > 50;
        }
        $d['download_names'] = array_values(array_map(static function ($f) { return MW_Payload::clean_text($f->get_name()); }, $p->get_downloads()));
        $d['deleted'] = get_post_status($p->get_id()) === 'trash';
        return apply_filters('mw_sync_product_payload', $d, $p);
    }
    public static function customer(int $id): ?array {
        $user = get_userdata($id);
        if (!$user || user_can($id, 'manage_options') || user_can($id, 'manage_woocommerce')) { return null; }
        if (!array_intersect(['customer', 'subscriber'], (array) $user->roles) && !get_user_meta($id, 'billing_email', true)) { return null; }
        $c = new WC_Customer($id);
        $data = $c->get_data();
        $out = ['id' => $id, 'email' => $c->get_email(), 'first_name' => $c->get_first_name(), 'last_name' => $c->get_last_name(),
            'display_name' => $user->display_name, 'billing' => $data['billing'] ?? [], 'shipping' => $data['shipping'] ?? [],
            'is_vat_exempt' => $c->get_is_vat_exempt(), 'metadata' => self::metadata($c, 'customer')];
        return apply_filters('mw_sync_customer_payload', self::safe_value($out), $c);
    }
    private static function line($item): array {
        $d = self::safe_value($item->get_data());
        unset($d['meta_data']);
        if (isset($d['name'])) { $d['name'] = self::clean_text($d['name']); }
        if (isset($d['method_title'])) { $d['method_title'] = self::clean_text($d['method_title']); }
        $d['metadata'] = self::metadata($item, 'line');
        if ($item instanceof WC_Order_Item_Product) {
            // Use the order-line IDs explicitly. Custom product selectors can make
            // get_product() ambiguous; Odoo must always receive the real variation ID.
            $product_id = (int) $item->get_product_id();
            $variation_id = (int) $item->get_variation_id();
            $leaf_id = $variation_id > 0 ? $variation_id : $product_id;
            $p = $leaf_id > 0 ? wc_get_product($leaf_id) : false;
            if (!$p) { $p = $item->get_product(); }
            $d['product_id'] = $product_id;
            $d['variation_id'] = $variation_id;
            $d['catalog_lookup_id'] = $leaf_id;
            $d['sku'] = $p ? trim((string) $p->get_sku()) : trim((string) $item->get_meta('_sku', true));
            $d['stock_product_id'] = $p ? $p->get_stock_managed_by_id() : 0;
        }
        return $d;
    }
    /**
     * Convert the WPS/WooCommerce RMA exchange record into the compact contract
     * agreed with Odoo. The connector derives SKU/product IDs from WooCommerce
     * rather than trusting browser/session values when an authoritative object exists.
     */
    public static function exchange_from_rma(WC_Order $order, array $detail): array {
        $from = [];
        foreach ((array) ($detail['from'] ?? []) as $raw) {
            if (!is_array($raw)) { continue; }
            $item_id = absint($raw['item_id'] ?? 0);
            $item = $item_id ? $order->get_item($item_id) : false;
            if (!$item instanceof WC_Order_Item_Product) { continue; }
            $product_id = (int) $item->get_product_id();
            $variation_id = (int) $item->get_variation_id();
            $leaf = $variation_id > 0 ? wc_get_product($variation_id) : wc_get_product($product_id);
            $qty = max(1, absint($raw['qty'] ?? 1));
            $qty = min($qty, max(1, (int) $item->get_quantity()));
            $price = isset($raw['price']) && is_numeric($raw['price']) ? (float) $raw['price'] : 0.0;
            $from[] = [
                'item_id' => $item_id,
                'product_id' => $product_id,
                'variation_id' => $variation_id,
                'sku' => $leaf ? trim((string) $leaf->get_sku()) : '',
                'qty' => $qty,
                'price' => (float) MW_Config::money($price),
            ];
        }

        $to = [];
        foreach ((array) ($detail['to'] ?? []) as $raw) {
            if (!is_array($raw)) { continue; }
            $variation_id = absint($raw['variation_id'] ?? 0);
            $raw_product_id = absint($raw['product_id'] ?? ($raw['id'] ?? 0));
            $leaf_id = $variation_id > 0 ? $variation_id : $raw_product_id;
            $product = $leaf_id ? wc_get_product($leaf_id) : false;
            if (!$product) { continue; }
            $product_id = $variation_id > 0 ? (int) $product->get_parent_id() : (int) $product->get_id();
            if ($product_id < 1) { $product_id = $raw_product_id ?: (int) $product->get_id(); }
            $price = isset($raw['price']) && is_numeric($raw['price']) ? (float) $raw['price'] : (float) wc_get_price_to_display($product);
            $to[] = [
                'product_id' => $product_id,
                'variation_id' => $variation_id,
                'sku' => trim((string) $product->get_sku()),
                'qty' => max(1, absint($raw['qty'] ?? 1)),
                'price' => (float) MW_Config::money($price),
            ];
        }

        if (!$from || !$to) {
            throw new RuntimeException('Approved exchange is missing valid FROM or TO product lines.');
        }
        return apply_filters('mw_sync_exchange_payload', [
            'exchange_status' => 'approved',
            'reason' => self::clean_text($detail['reason'] ?? $detail['subject'] ?? ''),
            'from' => $from,
            'to' => $to,
        ], $order, $detail);
    }

    public static function order(WC_Order $o, $row): array {
        $d = self::safe_value($o->get_data());
        foreach (['meta_data', 'order_key', 'customer_ip_address', 'customer_user_agent', 'cart_hash', 'line_items', 'tax_lines', 'shipping_lines', 'fee_lines', 'coupon_lines'] as $key) { unset($d[$key]); }
        $d['order_number'] = $o->get_order_number();
        $d['confirmed_at'] = str_replace(' ', 'T', $row->confirmed_at) . 'Z';
        $d['historical'] = (bool) $row->historical;
        $d['decimals'] = wc_get_price_decimals();
        $d['metadata'] = self::metadata($o, 'order');
        $d['paid'] = $o->get_payment_method() !== 'cod' && (bool) $o->get_date_paid();
        $d['paid_rule'] = 'COD is unpaid; otherwise date_paid must exist';
        $d['woo_is_paid'] = $o->is_paid();
        $d['is_cod'] = $o->get_payment_method() === 'cod';
        $d['payment_method_title'] = $o->get_payment_method_title();
        $d['date_paid'] = MW_Config::iso($o->get_date_paid());
        $d['date_created'] = MW_Config::iso($o->get_date_created());
        $d['date_modified'] = MW_Config::iso($o->get_date_modified());
        $d['date_completed'] = MW_Config::iso($o->get_date_completed());
        $d['transaction_id'] = $o->get_transaction_id();
        $d['amount_refunded'] = MW_Config::money($o->get_total_refunded());
        $d['sale_savings'] = ['amount' => null, 'source' => 'not_recorded', 'informational_only' => true];
        $d['catalog'] = [];
        $keys = ['line_item' => 'line_items', 'shipping' => 'shipping_lines', 'fee' => 'fee_lines', 'coupon' => 'coupon_lines', 'tax' => 'tax_lines'];
        foreach ($keys as $type => $field) {
            $d[$field] = [];
            foreach ($o->get_items($type) as $item) {
                $d[$field][] = self::line($item);
                if ($type === 'line_item') {
                    $variation_id = (int) $item->get_variation_id();
                    $product_id = (int) $item->get_product_id();
                    $leaf_id = $variation_id > 0 ? $variation_id : $product_id;
                    $p = $leaf_id > 0 ? wc_get_product($leaf_id) : false;
                    if (!$p) { $p = $item->get_product(); }
                    if ($variation_id > 0) {
                        $parent = wc_get_product($product_id ?: ($p ? $p->get_parent_id() : 0));
                        if ($parent && !isset($d['catalog'][$parent->get_id()])) { $d['catalog'][$parent->get_id()] = self::product($parent, true); }
                    }
                    if ($p && !isset($d['catalog'][$p->get_id()])) { $d['catalog'][$p->get_id()] = self::product($p, true); }
                }
            }
        }
        ksort($d['catalog'], SORT_NUMERIC);
        $d['catalog'] = array_values($d['catalog']);
        if (count($d['line_items']) > 500) { throw new RuntimeException('Order exceeds 500 lines; split/review before integration.'); }
        $d['refunds'] = [];
        foreach ($o->get_refunds() as $refund) {
            $r = ['id' => $refund->get_id(), 'amount' => $refund->get_amount(), 'reason' => $refund->get_reason(),
                'date_created' => MW_Config::iso($refund->get_date_created()), 'line_items' => []];
            foreach ($refund->get_items(['line_item', 'shipping', 'fee']) as $item) { $r['line_items'][] = self::line($item); }
            $d['refunds'][] = $r;
        }
        $notes = wc_get_order_notes(['order_id' => $o->get_id(), 'type' => 'customer', 'limit' => 51, 'orderby' => 'comment_ID', 'order' => 'DESC']);
        $d['customer_notes'] = [];
        foreach (array_slice($notes, 0, 50) as $note) {
            $d['customer_notes'][] = ['id' => $note->id, 'content' => $note->content, 'date' => MW_Config::iso($note->date_created)];
        }
        $d['customer_notes_has_more'] = count($notes) > 50;
        $d['privacy_exclusions'] = ['credentials', 'payment_tokens', 'card_data', 'IP_and_user_agent', 'unapproved_private_meta', 'internal_order_notes'];
        return apply_filters('mw_sync_order_payload', $d, $o);
    }
}
