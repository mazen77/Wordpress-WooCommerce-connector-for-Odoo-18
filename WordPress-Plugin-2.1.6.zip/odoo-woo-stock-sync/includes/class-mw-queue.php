<?php
defined('ABSPATH') || exit;
final class MW_Queue {
    private static array $touched = [];
    private static array $held = [];
    private static bool $shutdown_registered = false;
    public static bool $importing_stock = false;

    public static function install(): void {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $c = $wpdb->get_charset_collate();
        $t = MW_Config::table('objects');
        dbDelta("CREATE TABLE $t (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            kind varchar(16) NOT NULL,
            object_id bigint(20) unsigned NOT NULL,
            version bigint(20) unsigned NOT NULL DEFAULT 1,
            delivered_version bigint(20) unsigned NOT NULL DEFAULT 0,
            state varchar(16) NOT NULL DEFAULT 'pending',
            priority smallint NOT NULL DEFAULT 10,
            attempts smallint unsigned NOT NULL DEFAULT 0,
            due_at datetime NOT NULL,
            touched_at datetime NOT NULL,
            confirmed_at datetime NULL,
            historical tinyint NOT NULL DEFAULT 0,
            fingerprint varchar(64) NOT NULL DEFAULT '',
            payload longtext NULL,
            payload_version bigint(20) unsigned NOT NULL DEFAULT 0,
            last_error varchar(500) NOT NULL DEFAULT '',
            PRIMARY KEY  (id),
            UNIQUE KEY entity (kind,object_id),
            KEY work (state,due_at,priority),
            KEY confirmation (kind,confirmed_at)
        ) $c;");
        $t = MW_Config::table('holds');
        dbDelta("CREATE TABLE $t (
            order_id bigint(20) unsigned NOT NULL,
            product_id bigint(20) unsigned NOT NULL,
            source_version bigint(20) unsigned NOT NULL DEFAULT 1,
            stock_version bigint(20) unsigned NOT NULL DEFAULT 0,
            touched_at datetime NOT NULL,
            PRIMARY KEY  (order_id,product_id),
            KEY product_hold (product_id,stock_version)
        ) $c;");
        $t = MW_Config::table('stock');
        dbDelta("CREATE TABLE $t (
            product_id bigint(20) unsigned NOT NULL,
            version bigint(20) unsigned NOT NULL DEFAULT 0,
            quantity decimal(20,6) NOT NULL DEFAULT 0,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (product_id)
        ) $c;");
        $t = MW_Config::table('exchanges');
        dbDelta("CREATE TABLE $t (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            order_id bigint(20) unsigned NOT NULL,
            request_key varchar(80) NOT NULL,
            version bigint(20) unsigned NOT NULL DEFAULT 1,
            payload_hash varchar(64) NOT NULL DEFAULT '',
            payload longtext NULL,
            touched_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY order_request (order_id,request_key)
        ) $c;");
        $s = MW_Config::all();
        if (!$s['store_key']) { $s['store_key'] = wp_generate_uuid4(); }
        if (!$s['out_secret']) { $s['out_secret'] = wp_generate_password(64, false, false); }
        if (!$s['in_secret']) { $s['in_secret'] = wp_generate_password(64, false, false); }
        update_option('mw_sync_settings', $s, false);
        update_option('mw_sync_schema', MW_SYNC_VERSION, false);
    }

    public static function schedule(): void {
        if (!MW_Config::enabled()) { return; }
        if (function_exists('as_has_scheduled_action') && function_exists('as_schedule_recurring_action')) {
            if (!as_has_scheduled_action('mw_sync_tick', [], 'mw-sync')) {
                as_schedule_recurring_action(time() + 60, 60, 'mw_sync_tick', [], 'mw-sync', true);
            }
        } else {
            add_filter('cron_schedules', function ($s) {
                $s['mw_minute'] = ['interval' => 60, 'display' => 'Odoo queue recovery'];
                return $s;
            });
            if (!wp_next_scheduled('mw_sync_tick')) { wp_schedule_event(time() + 60, 'mw_minute', 'mw_sync_tick'); }
        }
    }

    public static function wake(): void {
        if (!MW_Config::enabled()) { return; }
        // WooCommerce bundles Action Scheduler. Queue an async action so live sync and
        // backfills do not depend on the next WP-Cron tick. as_has_scheduled_action()
        // keeps this debounced to one wake-up, while the MySQL worker lock prevents
        // concurrent workers from increasing server load.
        if (function_exists('as_enqueue_async_action') && function_exists('as_has_scheduled_action') && did_action('init')) {
            if (!as_has_scheduled_action('mw_sync_wake', [], 'mw-sync')) {
                as_enqueue_async_action('mw_sync_wake', [], 'mw-sync', true);
            }
            return;
        }
        if (function_exists('as_schedule_single_action') && did_action('init')) {
            if (!function_exists('as_has_scheduled_action') || !as_has_scheduled_action('mw_sync_wake', [], 'mw-sync')) {
                as_schedule_single_action(time() + 1, 'mw_sync_wake', [], 'mw-sync', true);
            }
        } elseif (!wp_next_scheduled('mw_sync_wake')) {
            wp_schedule_single_event(time() + 1, 'mw_sync_wake');
        }
    }

    public static function row(string $kind, int $id) {
        global $wpdb; $t = MW_Config::table('objects');
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE kind=%s AND object_id=%d", $kind, $id));
    }

    public static function touch(string $kind, int $id, bool $historical = false, bool $confirmed = false): int {
        if (!MW_Config::enabled() || $id < 1 || !in_array($kind, ['product', 'customer', 'order'], true)) { return 0; }
        if (!self::$shutdown_registered) { add_action('shutdown', [__CLASS__, 'finalize'], 999); self::$shutdown_registered = true; }
        global $wpdb; $t = MW_Config::table('objects');
        $key = $kind . ':' . $id;
        if (!isset(self::$touched[$key])) {
            $now = gmdate('Y-m-d H:i:s');
            $due = gmdate('Y-m-d H:i:s', time() + 5);
            $confirm = $confirmed ? $now : null;
            $priority = ['order' => 0, 'product' => 10, 'customer' => 20][$kind];
            // Keep product revisions globally forward-moving across a local queue
            // rebuild/reset. Odoo persists the last accepted revision and ignores
            // older revisions by design, so a fresh WordPress queue starting at 1
            // must not make legitimate product saves look stale.
            $seed_version = $kind === 'product' ? time() : 1;
            $sql = $wpdb->prepare("INSERT INTO $t (kind,object_id,version,state,priority,due_at,touched_at,confirmed_at,historical)
                VALUES (%s,%d,%d,'pending',%d,%s,%s,NULLIF(%s,''),%d)
                ON DUPLICATE KEY UPDATE version=GREATEST(version+1,VALUES(version)),state='pending',attempts=0,due_at=VALUES(due_at),
                touched_at=VALUES(touched_at),confirmed_at=COALESCE(confirmed_at,VALUES(confirmed_at)),historical=VALUES(historical),payload=NULL,payload_version=0,last_error=''",
                $kind, $id, $seed_version, $priority, $due, $now, $confirm ?? '', (int) $historical);
            if (false === $wpdb->query($sql)) { throw new RuntimeException('Cannot persist synchronization event.'); }
            self::$touched[$key] = (int) self::row($kind, $id)->version;
            self::wake();
        } elseif ($confirmed) {
            $wpdb->query($wpdb->prepare("UPDATE $t SET confirmed_at=COALESCE(confirmed_at,%s) WHERE kind=%s AND object_id=%d", gmdate('Y-m-d H:i:s'), $kind, $id));
        }
        return self::$touched[$key];
    }

    private static function enqueue_backfill(string $kind, int $id, bool $confirmed = false): void {
        global $wpdb; $t = MW_Config::table('objects');
        $now = gmdate('Y-m-d H:i:s');
        $priority = ['order' => 0, 'product' => 10, 'customer' => 20][$kind];
        $confirm = $confirmed ? $now : '';
        // Product backfill is also the recovery/reconciliation path. Odoo keeps
        // the last accepted revision per Woo product and correctly ignores an
        // older revision. If this WordPress queue was ever rebuilt/reset while
        // Odoo retained its mapping rows, a normal small integer revision can be
        // lower than Odoo's stored revision and Odoo will acknowledge the batch
        // without re-applying the product. Seed manual product backfills from a
        // forward-only Unix revision so recovery cannot be mistaken for stale
        // delivery. Existing rows still advance monotonically via GREATEST().
        $seed_version = $kind === 'product' ? time() : 1;
        $wpdb->query($wpdb->prepare("INSERT INTO $t (kind,object_id,version,state,priority,due_at,touched_at,confirmed_at,historical)
            VALUES (%s,%d,%d,'pending',%d,%s,%s,NULLIF(%s,''),1)
            ON DUPLICATE KEY UPDATE version=GREATEST(version+1,VALUES(version)),state='pending',attempts=0,due_at=VALUES(due_at),touched_at=VALUES(touched_at),
            confirmed_at=COALESCE(confirmed_at,VALUES(confirmed_at)),historical=VALUES(historical),payload=NULL,payload_version=0,last_error=''",
            $kind, $id, $seed_version, $priority, $now, $now, $confirm));
    }

    /**
     * Persist an approved RMA exchange as an immutable business snapshot and
     * enqueue it using a connector-owned numeric exchange ID. The unique
     * (order_id, request_key) pair makes repeated approval hooks idempotent.
     */
    public static function enqueue_exchange(int $order_id, string $request_key, array $data): int {
        if (!MW_Config::enabled() || $order_id < 1 || $request_key === '') { return 0; }
        global $wpdb;
        $et = MW_Config::table('exchanges');
        $qt = MW_Config::table('objects');
        $request_key = substr(sanitize_text_field($request_key), 0, 80);
        if (!MW_Config::lock('exchange:' . $order_id . ':' . $request_key, 2)) {
            throw new RuntimeException('Could not lock exchange event.');
        }
        try {
            $now = gmdate('Y-m-d H:i:s');
            $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM $et WHERE order_id=%d AND request_key=%s", $order_id, $request_key));
            if (!$existing) {
                $ok = $wpdb->insert($et, [
                    'order_id' => $order_id,
                    'request_key' => $request_key,
                    'version' => 1,
                    'payload_hash' => '',
                    'payload' => null,
                    'touched_at' => $now,
                ], ['%d','%s','%d','%s','%s','%s']);
                if (false === $ok) { throw new RuntimeException('Cannot allocate exchange event ID.'); }
                $exchange_id = (int) $wpdb->insert_id;
                $version = 1;
                $existing_hash = '';
            } else {
                $exchange_id = (int) $existing->id;
                $version = max(1, (int) $existing->version);
                $existing_hash = (string) $existing->payload_hash;
            }

            $data['id'] = $exchange_id;
            $data['order_id'] = $order_id;
            $encoded = MW_Config::json($data);
            if (strlen($encoded) > 524288) { throw new RuntimeException('Exchange payload exceeds 512 KiB.'); }
            $hash = hash('sha256', $encoded);

            if ($existing && $existing_hash && !hash_equals($existing_hash, $hash)) {
                $version++;
            }
            $wpdb->update($et, [
                'version' => $version,
                'payload_hash' => $hash,
                'payload' => $encoded,
                'touched_at' => $now,
            ], ['id' => $exchange_id], ['%d','%s','%s','%s'], ['%d']);

            $row = self::row('exchange', $exchange_id);
            if ($row && (int) $row->delivered_version >= $version && $row->fingerprint && hash_equals((string) $row->fingerprint, $hash)) {
                return $exchange_id;
            }
            $due = gmdate('Y-m-d H:i:s', time() + 1);
            $sql = $wpdb->prepare("INSERT INTO $qt (kind,object_id,version,state,priority,attempts,due_at,touched_at,confirmed_at,historical,fingerprint,payload,payload_version,last_error)
                VALUES ('exchange',%d,%d,'pending',0,0,%s,%s,NULL,0,'',%s,%d,'')
                ON DUPLICATE KEY UPDATE version=VALUES(version),state='pending',priority=0,attempts=0,due_at=VALUES(due_at),
                touched_at=VALUES(touched_at),historical=0,payload=VALUES(payload),payload_version=VALUES(payload_version),last_error=''",
                $exchange_id, $version, $due, $now, $encoded, $version);
            if (false === $wpdb->query($sql)) { throw new RuntimeException('Cannot queue exchange event.'); }
            self::wake();
            return $exchange_id;
        } finally {
            MW_Config::unlock('exchange:' . $order_id . ':' . $request_key);
        }
    }

    public static function finalize(): void {
        global $wpdb; $t = MW_Config::table('objects');
        foreach (array_keys(self::$touched) as $key) {
            [$kind, $id] = explode(':', $key);
            $wpdb->query($wpdb->prepare("UPDATE $t SET version=version+1,state='pending',attempts=0,payload=NULL,payload_version=0,due_at=%s WHERE kind=%s AND object_id=%d", gmdate('Y-m-d H:i:s', time() + 5), $kind, (int) $id));
            $row = self::row($kind, (int) $id);
            if (!$row) { continue; }
            self::$touched[$key] = (int) $row->version;
            if ($kind === 'order' && !$row->historical) {
                $h = MW_Config::table('holds');
                $wpdb->query($wpdb->prepare("UPDATE $h SET source_version=%d,stock_version=0 WHERE order_id=%d", $row->version, (int) $id));
                if ($row->confirmed_at) { MW_Events::order((int) $id); }
            }
        }
        if (self::$touched) { self::wake(); }
        self::$touched = []; self::$held = [];
    }

    public static function hold(int $order_id, int $product_id, int $version): void {
        if (!$product_id || !$version) { return; }
        $key = $order_id . ':' . $product_id;
        if ((self::$held[$key] ?? 0) === $version) { return; }
        self::$held[$key] = $version;
        global $wpdb; $t = MW_Config::table('holds');
        $wpdb->query($wpdb->prepare("INSERT INTO $t (order_id,product_id,source_version,stock_version,touched_at) VALUES (%d,%d,%d,0,%s)
            ON DUPLICATE KEY UPDATE source_version=GREATEST(source_version,VALUES(source_version)),stock_version=0,touched_at=VALUES(touched_at)",
            $order_id, $product_id, $version, gmdate('Y-m-d H:i:s')));
    }

    public static function acknowledge(array $ack): bool {
        global $wpdb;
        $id = absint($ack['order_id'] ?? 0); $version = absint($ack['source_version'] ?? 0);
        if (!$id || !$version || !is_array($ack['stock_versions'] ?? null)) { return false; }
        $t = MW_Config::table('holds');
        foreach ($ack['stock_versions'] as $pid => $stock_version) {
            $wpdb->query($wpdb->prepare("UPDATE $t SET stock_version=%d WHERE order_id=%d AND product_id=%d AND source_version<=%d AND stock_version<=%d",
                absint($stock_version), $id, absint($pid), $version, absint($stock_version)));
        }
        $t = MW_Config::table('objects');
        $wpdb->query($wpdb->prepare("UPDATE $t SET delivered_version=GREATEST(delivered_version,%d),state='done',last_error='' WHERE kind='order' AND object_id=%d AND version=%d", $version, $id, $version));
        if (!empty($ack['live'])) {
            $wpdb->query($wpdb->prepare("UPDATE $t SET historical=0 WHERE kind='order' AND object_id=%d AND version=%d", $id, $version));
        }
        return true;
    }

    private static function retry_row($row, string $message): void {
        global $wpdb; $t = MW_Config::table('objects');
        $tries = (int) $row->attempts + 1;
        $delays = [30, 60, 120, 300, 900, 1800, 3600, 10800];
        $wpdb->query($wpdb->prepare("UPDATE $t SET attempts=%d,state=%s,due_at=%s,last_error=%s WHERE id=%d AND version=%d",
            $tries, $tries >= 8 ? 'failed' : 'pending', gmdate('Y-m-d H:i:s', time() + $delays[min($tries - 1, 7)]),
            substr(sanitize_text_field($message), 0, 490), $row->id, $row->version));
    }

    private static function mark_result($row, string $hash, array $reply): void {
        global $wpdb; $t = MW_Config::table('objects');
        if (($reply['kind'] ?? '') !== $row->kind || (int) ($reply['id'] ?? 0) !== (int) $row->object_id || (int) ($reply['version'] ?? 0) !== (int) $row->version) {
            self::retry_row($row, 'Odoo acknowledgement does not match the queued entity/version.');
            return;
        }
        if (empty($reply['ok'])) {
            $error = sanitize_key((string) ($reply['error'] ?? 'invalid_reply'));
            $review_codes = ['invalid_payload', 'configuration_or_business_rule', 'integration_user_permissions'];
            if (($reply['state'] ?? '') === 'review' || in_array($error, $review_codes, true)) {
                $wpdb->query($wpdb->prepare("UPDATE $t SET state='review',last_error=%s,attempts=0 WHERE id=%d AND version=%d",
                    substr('Odoo review: ' . $error, 0, 490), $row->id, $row->version));
            } else {
                self::retry_row($row, 'Odoo retry: ' . $error);
            }
            return;
        }
        $state = ($reply['state'] ?? '') === 'review' ? 'review' : 'done';
        $wpdb->query($wpdb->prepare("UPDATE $t SET state=%s,delivered_version=%d,fingerprint=%s,last_error=%s,attempts=0,payload=IF(%s='done',NULL,payload) WHERE id=%d AND version=%d",
            $state, $row->version, $hash, $state === 'review' ? 'Accepted by Odoo; native operation needs review in Odoo.' : '', $state, $row->id, $row->version));
        if (!empty($reply['ack']) && is_array($reply['ack'])) { self::acknowledge($reply['ack']); }
    }

    private static function send_batch(array $prepared): void {
        if (!$prepared) { return; }
        $max_items = max(1, min(20, (int) MW_Config::get('network_batch', 10)));
        $chunks = [];
        $current = []; $size = 256;
        foreach ($prepared as $entry) {
            $item = $entry['item'];
            $item_size = strlen(MW_Config::json($item)) + 2;
            if ($current && (count($current) >= $max_items || $size + $item_size > 1700000)) {
                $chunks[] = $current; $current = []; $size = 256;
            }
            $current[] = $entry; $size += $item_size;
        }
        if ($current) { $chunks[] = $current; }

        foreach ($chunks as $chunk) {
            try {
                $reply = MW_Config::post([
                    'schema' => 2,
                    'store' => MW_Config::get('store_key'),
                    'kind' => 'batch',
                    'version' => '1',
                    'items' => array_values(array_map(static fn($e) => $e['item'], $chunk)),
                ]);
                $results = is_array($reply['results'] ?? null) ? $reply['results'] : [];
                $by_key = [];
                foreach ($results as $result) {
                    if (!is_array($result)) { continue; }
                    $by_key[($result['kind'] ?? '') . ':' . (int) ($result['id'] ?? 0) . ':' . (int) ($result['version'] ?? 0)] = $result;
                }
                foreach ($chunk as $entry) {
                    $row = $entry['row'];
                    $key = $row->kind . ':' . (int) $row->object_id . ':' . (int) $row->version;
                    if (!isset($by_key[$key])) {
                        self::retry_row($row, 'Odoo batch response omitted this entity/version.');
                        continue;
                    }
                    self::mark_result($row, $entry['hash'], $by_key[$key]);
                }
            } catch (Throwable $e) {
                foreach ($chunk as $entry) { self::retry_row($entry['row'], $e->getMessage()); }
            }
        }
    }

    public static function run(): void {
        if (!MW_Config::enabled() || !MW_Config::lock('worker')) { return; }
        global $wpdb; $t = MW_Config::table('objects');
        $started = microtime(true);
        try {
            self::backfill_step();
            $limit = max(1, min(50, (int) MW_Config::get('worker_batch', 30)));
            $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM $t WHERE state='pending' AND due_at<=%s ORDER BY priority,id LIMIT %d",
                gmdate('Y-m-d H:i:s'), $limit));
            $prepared = [];
            foreach ($rows as $row) {
                if (microtime(true) - $started > 22) { break; }
                try {
                    $data = $row->payload && (int) $row->payload_version === (int) $row->version ? json_decode($row->payload, true) : MW_Payload::build($row->kind, (int) $row->object_id, $row);
                    if ($data === null) {
                        $wpdb->query($wpdb->prepare("UPDATE $t SET state='skipped',last_error='Not eligible or no longer exists' WHERE id=%d AND version=%d", $row->id, $row->version));
                        continue;
                    }
                    $encoded = MW_Config::json($data);
                    $hash = hash('sha256', $encoded);
                    if (!$row->payload || (int) $row->payload_version !== (int) $row->version) {
                        $wpdb->query($wpdb->prepare("UPDATE $t SET payload=%s,payload_version=%d WHERE id=%d AND version=%d", $encoded, $row->version, $row->id, $row->version));
                        $fresh = self::row($row->kind, (int) $row->object_id);
                        if (!$fresh || (int) $fresh->version !== (int) $row->version) { continue; }
                    }
                    if ($row->kind !== 'order' && !(bool) $row->historical && $row->fingerprint && hash_equals($row->fingerprint, $hash) && (int) $row->delivered_version > 0) {
                        $wpdb->query($wpdb->prepare("UPDATE $t SET state='done',delivered_version=version,payload=NULL,last_error='' WHERE id=%d AND version=%d", $row->id, $row->version));
                        continue;
                    }
                    $item = [
                        'kind' => $row->kind,
                        'id' => (int) $row->object_id,
                        'version' => (int) $row->version,
                        'data' => $data,
                    ];
                    if ($row->kind === 'exchange') {
                        // Match the exchange contract agreed with Odoo: order_id is
                        // present both on the entity wrapper and inside data.
                        $item['order_id'] = absint($data['order_id'] ?? 0);
                    } else {
                        $item['event_id'] = MW_Config::get('store_key') . ':' . $row->kind . ':' . $row->object_id . ':' . $row->version;
                    }
                    $prepared[] = [
                        'row' => $row,
                        'hash' => $hash,
                        'item' => $item,
                    ];
                } catch (Throwable $e) {
                    self::retry_row($row, $e->getMessage());
                }
            }
            self::send_batch($prepared);
            self::backfill_step();
            $left = $wpdb->get_var($wpdb->prepare("SELECT id FROM $t WHERE state='pending' AND due_at<=%s LIMIT 1", gmdate('Y-m-d H:i:s', time() + 5)));
            $job = get_option('mw_sync_backfill', []);
            if ($left || !empty($job['active'])) { self::wake(); }
        } finally { MW_Config::unlock('worker'); }
    }

    public static function backfill_step(): void {
        $job = get_option('mw_sync_backfill', []);
        if (empty($job['active'])) { return; }
        global $wpdb;
        $qt = MW_Config::table('objects');
        $pending = (int) $wpdb->get_var("SELECT COUNT(*) FROM (SELECT id FROM $qt WHERE state='pending' LIMIT 300) AS pending_window");
        if ($pending >= 300) { return; }
        $cursor = (int) ($job['cursor'] ?? 0); $max = (int) ($job['max'] ?? 0); $kind = (string) ($job['kind'] ?? '');
        $scan = min(max(20, min(200, (int) MW_Config::get('scan_batch', 100))), max(1, 300 - $pending));
        if ($kind === 'product') {
            $ids = $wpdb->get_col($wpdb->prepare("SELECT ID FROM {$wpdb->posts} WHERE ID>%d AND ID<=%d AND post_type IN ('product','product_variation') AND post_status NOT IN ('trash','auto-draft') ORDER BY ID LIMIT %d", $cursor, $max, $scan));
        } elseif ($kind === 'customer') {
            $ids = $wpdb->get_col($wpdb->prepare("SELECT ID FROM {$wpdb->users} WHERE ID>%d AND ID<=%d ORDER BY ID LIMIT %d", $cursor, $max, $scan));
        } else {
            $hpos = class_exists('Automattic\\WooCommerce\\Utilities\\OrderUtil') && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
            $table = $hpos ? $wpdb->prefix . 'wc_orders' : $wpdb->posts;
            $type = $hpos ? 'type' : 'post_type';
            $ids = $wpdb->get_col($wpdb->prepare("SELECT id FROM $table WHERE id>%d AND id<=%d AND $type='shop_order' ORDER BY id LIMIT %d", $cursor, $max, $scan));
        }
        foreach ($ids as $id) {
            $job['cursor'] = (int) $id;
            if ($kind === 'order') {
                $order = wc_get_order($id);
                $allowed = array_filter(array_map('trim', explode(',', (string) MW_Config::get('history_statuses'))));
                $known = self::row('order', (int) $id);
                if (!$order || $order->get_meta('wps_wrma_exchange_order', true) || (!($known && $known->confirmed_at) && !in_array($order->get_status(), $allowed, true))) {
                    $job['skipped'] = ($job['skipped'] ?? 0) + 1; continue;
                }
                self::enqueue_backfill($kind, (int) $id, true);
            } else {
                self::enqueue_backfill($kind, (int) $id, false);
            }
            $job['queued'] = ($job['queued'] ?? 0) + 1;
        }
        if (!$ids || ((int) end($ids) >= $max) || count($ids) < $scan) { $job['active'] = false; }
        update_option('mw_sync_backfill', $job, false);
    }
}
