<?php
defined('ABSPATH') || exit;
final class MW_Admin {
    public static function boot(): void {
        add_action('admin_menu', function () {
            add_submenu_page('woocommerce', 'Odoo Sync', 'Odoo Sync', 'manage_options', 'mw-sync', [__CLASS__, 'page']);
        });
        add_action('admin_post_mw_sync_save', [__CLASS__, 'save']);
        add_action('admin_post_mw_sync_action', [__CLASS__, 'action']);
    }

    private static function check(string $nonce): void {
        if (!current_user_can('manage_options')) { wp_die('Not authorized.'); }
        check_admin_referer($nonce);
    }

    public static function save(): void {
        self::check('mw_sync_save');
        $old = MW_Config::all(); $s = $old;
        foreach (['enabled', 'stock_enabled', 'images'] as $k) { $s[$k] = isset($_POST[$k]) ? 1 : 0; }
        $s['url'] = esc_url_raw(wp_unslash($_POST['url'] ?? ''));
        if ($s['url'] && (wp_parse_url($s['url'], PHP_URL_SCHEME) !== 'https' || !wp_http_validate_url($s['url']))) {
            wp_die('Use a public HTTPS endpoint without URL credentials.');
        }
        foreach (['out_secret', 'in_secret'] as $k) {
            $value = trim((string) wp_unslash($_POST[$k] ?? ''));
            if ($value !== '') {
                if (strlen($value) < 32 || strlen($value) > 128) { wp_die('Secrets must be 32-128 characters.'); }
                $s[$k] = $value;
            }
        }
        foreach (['extra_order_meta', 'extra_customer_meta', 'extra_product_meta', 'history_statuses'] as $k) {
            $s[$k] = sanitize_textarea_field(wp_unslash($_POST[$k] ?? $old[$k]));
        }
        $s['worker_batch'] = max(1, min(50, absint($_POST['worker_batch'] ?? 30)));
        $s['network_batch'] = max(1, min(20, absint($_POST['network_batch'] ?? 10)));
        $s['scan_batch'] = max(20, min(200, absint($_POST['scan_batch'] ?? 100)));
        $s['timeout'] = max(3, min(20, absint($_POST['timeout'] ?? 8)));
        if ($s['enabled'] && !$s['cutover']) { $s['cutover'] = gmdate('Y-m-d H:i:s'); }
        update_option('mw_sync_settings', $s, false);
        MW_Queue::wake();
        wp_safe_redirect(admin_url('admin.php?page=mw-sync&saved=1')); exit;
    }

    public static function action(): void {
        self::check('mw_sync_action');
        global $wpdb;
        $action = sanitize_key($_POST['op'] ?? '');
        if ($action === 'retry') {
            $t = MW_Config::table('objects');
            $wpdb->query($wpdb->prepare("UPDATE $t SET state='pending',attempts=0,due_at=%s WHERE state IN ('failed','review')", gmdate('Y-m-d H:i:s')));
            MW_Queue::wake();
        } elseif ($action === 'stop') {
            $j = get_option('mw_sync_backfill', []); $j['active'] = false; update_option('mw_sync_backfill', $j, false);
        } elseif ($action === 'resync_order') {
            $id = absint($_POST['order_id'] ?? 0);
            MW_Events::order($id);
        } elseif ($action === 'test') {
            try {
                $r = MW_Config::post(['schema' => 2, 'store' => MW_Config::get('store_key'), 'kind' => 'ping']);
                update_option('mw_sync_test', !empty($r['ok']) ? 'Authenticated Odoo connection succeeded.' : 'Connection failed.', false);
            } catch (Throwable $e) {
                update_option('mw_sync_test', sanitize_text_field($e->getMessage()), false);
            }
        } elseif (in_array($action, ['product', 'customer', 'order'], true)) {
            $current = get_option('mw_sync_backfill', []);
            if (!empty($current['active'])) { wp_die('Finish or stop the current backfill first.'); }
            if ($action === 'order' && empty($_POST['history_confirm'])) { wp_die('Confirm the historical-status selection first.'); }
            $table = $action === 'customer' ? $wpdb->users : $wpdb->posts;
            if ($action === 'order' && class_exists('Automattic\\WooCommerce\\Utilities\\OrderUtil') && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled()) {
                $table = $wpdb->prefix . 'wc_orders';
            }
            $max = (int) $wpdb->get_var("SELECT MAX(id) FROM $table");
            update_option('mw_sync_backfill', ['active' => true, 'kind' => $action, 'cursor' => 0, 'max' => $max, 'queued' => 0, 'skipped' => 0, 'started_at' => gmdate('c')], false);
            // Prime only the lightweight database scan before redirecting. No Odoo HTTP
            // request runs in this admin action; network delivery remains background work.
            MW_Queue::backfill_step();
            MW_Queue::wake();
        }
        wp_safe_redirect(admin_url('admin.php?page=mw-sync')); exit;
    }

    private static function toggle(string $name, string $label, bool $checked, string $hint = ''): void {
        echo '<label class="mw-switch-row"><span><strong>' . esc_html($label) . '</strong>';
        if ($hint) { echo '<small>' . esc_html($hint) . '</small>'; }
        echo '</span><span class="mw-switch"><input type="checkbox" name="' . esc_attr($name) . '" value="1" ' . checked($checked, true, false) . '><span></span></span></label>';
    }

    private static function stat(string $label, int $value, string $tone = ''): void {
        echo '<div class="mw-stat ' . esc_attr($tone) . '"><span>' . esc_html($label) . '</span><strong>' . number_format_i18n($value) . '</strong></div>';
    }

    private static function action_button(string $op, string $label, string $class = 'secondary'): void {
        echo '<button class="mw-btn mw-' . esc_attr($class) . '" name="op" value="' . esc_attr($op) . '">' . esc_html($label) . '</button>';
    }

    public static function page(): void {
        if (!current_user_can('manage_options')) { return; }
        global $wpdb; $s = MW_Config::all(); $t = MW_Config::table('objects');
        $raw_counts = $wpdb->get_results("SELECT state,COUNT(*) AS count FROM $t GROUP BY state");
        $counts = [];
        foreach ($raw_counts as $r) { $counts[$r->state] = (int) $r->count; }
        $errors = $wpdb->get_results("SELECT kind,object_id,state,attempts,last_error FROM $t WHERE state IN ('failed','review') ORDER BY id DESC LIMIT 30");
        $holds = (int) $wpdb->get_var('SELECT COUNT(*) FROM ' . MW_Config::table('holds'));
        $job = get_option('mw_sync_backfill', []);
        $test = (string) get_option('mw_sync_test', '');
        $progress = !empty($job['max']) ? min(100, max(0, ((int) ($job['cursor'] ?? 0) / (int) $job['max']) * 100)) : 0;
        $connected = str_contains($test, 'succeeded');

        echo '<style>
        .mw-shell{max-width:1220px;margin:22px 20px 40px 0;color:#1d2327}.mw-head{display:flex;align-items:flex-start;justify-content:space-between;gap:20px;margin-bottom:20px}.mw-head h1{font-size:28px;margin:0 0 6px}.mw-sub{color:#646970;margin:0;max-width:820px}.mw-pill{display:inline-flex;align-items:center;gap:7px;border-radius:999px;padding:7px 11px;font-weight:600;background:#f0f0f1}.mw-pill:before{content:"";width:8px;height:8px;border-radius:50%;background:#8c8f94}.mw-pill.ok{background:#edfaef;color:#126b2d}.mw-pill.ok:before{background:#19a247}.mw-grid{display:grid;grid-template-columns:repeat(12,minmax(0,1fr));gap:16px}.mw-card{grid-column:span 12;background:#fff;border:1px solid #dcdcde;border-radius:12px;box-shadow:0 1px 2px rgba(0,0,0,.04);padding:20px}.mw-card.half{grid-column:span 6}.mw-card h2{font-size:17px;margin:0 0 6px}.mw-card .desc{color:#646970;margin:0 0 18px}.mw-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:16px 0}.mw-stat{border:1px solid #e2e4e7;background:#f6f7f7;border-radius:10px;padding:14px}.mw-stat span{display:block;color:#646970;font-size:12px;text-transform:uppercase;letter-spacing:.04em}.mw-stat strong{display:block;font-size:24px;margin-top:4px}.mw-stat.warn strong{color:#b26200}.mw-stat.bad strong{color:#b32d2e}.mw-fields{display:grid;grid-template-columns:1fr 1fr;gap:16px}.mw-field label{display:block;font-weight:600;margin-bottom:6px}.mw-field small{display:block;color:#646970;margin-top:5px}.mw-field input[type=url],.mw-field input[type=password],.mw-field input[type=text],.mw-field input[type=number],.mw-field textarea{width:100%;border-radius:7px;min-height:40px}.mw-switch-row{display:flex;justify-content:space-between;align-items:center;gap:15px;padding:13px 0;border-bottom:1px solid #f0f0f1}.mw-switch-row:last-child{border-bottom:0}.mw-switch-row small{display:block;color:#646970;font-weight:400;margin-top:3px}.mw-switch{position:relative;width:42px;height:24px;flex:0 0 auto}.mw-switch input{opacity:0;width:0;height:0}.mw-switch span{position:absolute;inset:0;background:#8c8f94;border-radius:30px;transition:.15s}.mw-switch span:before{content:"";position:absolute;width:18px;height:18px;left:3px;top:3px;background:#fff;border-radius:50%;transition:.15s}.mw-switch input:checked+span{background:#2271b1}.mw-switch input:checked+span:before{transform:translateX(18px)}.mw-btn{display:inline-flex;align-items:center;justify-content:center;min-height:38px;padding:0 14px;border-radius:7px;border:1px solid #2271b1;font-weight:600;cursor:pointer;margin:0 7px 7px 0}.mw-primary{background:#2271b1;color:#fff}.mw-secondary{background:#fff;color:#135e96}.mw-danger{background:#fff;color:#b32d2e;border-color:#d63638}.mw-actions{display:flex;flex-wrap:wrap;align-items:center;margin-top:14px}.mw-code{display:block;overflow:auto;background:#f6f7f7;border:1px solid #e2e4e7;padding:9px 11px;border-radius:7px}.mw-progress{height:9px;border-radius:20px;background:#e7e8ea;overflow:hidden;margin:12px 0 8px}.mw-progress i{display:block;height:100%;background:#2271b1}.mw-note{padding:12px 14px;border-radius:8px;background:#f6f7f7;margin:12px 0}.mw-note.good{background:#edfaef;color:#126b2d}.mw-note.bad{background:#fcf0f1;color:#8a2424}.mw-advanced{margin-top:14px;border-top:1px solid #eee;padding-top:12px}.mw-advanced summary{cursor:pointer;font-weight:600}.mw-table{margin-top:12px;border:1px solid #e2e4e7;border-radius:9px;overflow:hidden}.mw-table table{border:0}.mw-table th{background:#f6f7f7}.mw-footer{color:#646970;font-size:12px;margin-top:18px}.mw-inline{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.mw-inline input{max-width:180px}.mw-muted{color:#646970}.mw-kicker{font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:#646970;font-weight:700;margin-bottom:6px}@media(max-width:960px){.mw-card.half{grid-column:span 12}.mw-fields{grid-template-columns:1fr}.mw-stats{grid-template-columns:1fr 1fr}}@media(max-width:560px){.mw-stats{grid-template-columns:1fr}.mw-shell{margin-right:10px}}
        </style>';

        echo '<div class="wrap mw-shell">';
        echo '<div class="mw-head"><div><div class="mw-kicker">Store integration</div><h1>WooCommerce ↔ Odoo 18</h1><p class="mw-sub">Fast queued synchronization for catalog, real Odoo variants, customers, confirmed orders and warehouse stock. Normal storefront browsing never waits for Odoo.</p></div><div class="mw-pill ' . ($connected ? 'ok' : '') . '">' . ($connected ? 'Connected' : 'Connection not tested') . '</div></div>';
        if (isset($_GET['saved'])) { echo '<div class="notice notice-success is-dismissible"><p>Settings saved.</p></div>'; }

        echo '<div class="mw-grid">';
        echo '<section class="mw-card half"><h2>Sync status</h2><p class="desc">A bounded queue protects both servers while batching multiple entities into fewer HTTP requests.</p><div class="mw-stats">';
        self::stat('Pending', $counts['pending'] ?? 0);
        self::stat('Done', $counts['done'] ?? 0);
        self::stat('Review', $counts['review'] ?? 0, 'warn');
        self::stat('Failed', $counts['failed'] ?? 0, 'bad');
        echo '</div><div class="mw-note"><strong>Stock guards:</strong> ' . number_format_i18n($holds) . ' awaiting matching Odoo acknowledgement.</div>';
        echo '<span class="mw-muted">Store ID</span><code class="mw-code">' . esc_html($s['store_key']) . '</code><span class="mw-muted">Odoo → Woo stock endpoint</span><code class="mw-code">' . esc_html(rest_url('mw-sync/v2/stock')) . '</code></section>';

        echo '<section class="mw-card half"><h2>Controlled backfill</h2><p class="desc">Backfill is throttled and resumable. Products are scanned in ID order so variable parents are normally queued before their variations.</p>';
        if ($job) {
            $kind_label = ucfirst((string) ($job['kind'] ?? ''));
            echo '<div class="mw-inline"><span class="mw-pill ' . (!empty($job['active']) ? 'ok' : '') . '">' . (!empty($job['active']) ? 'Running' : 'Idle') . '</span><strong>' . esc_html($kind_label) . '</strong><span class="mw-muted">' . number_format_i18n((int) ($job['queued'] ?? 0)) . ' queued · ' . number_format_i18n((int) ($job['skipped'] ?? 0)) . ' skipped</span></div>';
            echo '<div class="mw-progress"><i style="width:' . esc_attr(number_format($progress, 2, '.', '')) . '%"></i></div><div class="mw-muted">Scan position: ' . number_format_i18n((int) ($job['cursor'] ?? 0)) . ' / ' . number_format_i18n((int) ($job['max'] ?? 0)) . ' (' . esc_html(number_format_i18n($progress, 1)) . '%)</div>';
        } else { echo '<div class="mw-note">No backfill has been started.</div>'; }
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="mw_sync_action">'; wp_nonce_field('mw_sync_action');
        echo '<div class="mw-actions">';
        self::action_button('test', 'Test connection', 'primary'); self::action_button('product', 'Backfill products', 'secondary'); self::action_button('customer', 'Backfill customers', 'secondary'); self::action_button('order', 'Backfill confirmed orders', 'secondary'); self::action_button('stop', 'Stop', 'danger');
        echo '</div><label style="display:block;margin:6px 0 12px"><input type="checkbox" name="history_confirm" value="1"> I confirm the configured historical statuses are confirmed orders. Historical import does not reserve stock again.</label>';
        echo '<div class="mw-inline"><label for="mw-order-resend"><strong>Resend confirmed order</strong></label><input id="mw-order-resend" type="number" name="order_id" min="1" placeholder="Order ID">'; self::action_button('resync_order', 'Resend', 'secondary'); echo '</div>';
        echo '</form>';
        if ($test) { echo '<div class="mw-note ' . ($connected ? 'good' : 'bad') . '">' . esc_html($test) . '</div>'; }
        echo '</section>';

        echo '<section class="mw-card"><h2>Connection & performance</h2><p class="desc">Defaults are tuned for faster backfills without turning page views into API calls or allowing unbounded work.</p>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="mw_sync_save">'; wp_nonce_field('mw_sync_save');
        echo '<div class="mw-fields"><div>';
        self::toggle('enabled', 'Catalog, customer and confirmed-order sync', (bool) $s['enabled'], 'Events are queued; checkout and browsing do not wait for Odoo.');
        self::toggle('stock_enabled', 'Allow Odoo to update WooCommerce stock', (bool) $s['stock_enabled'], 'Enable only after product mappings have been reviewed.');
        self::toggle('images', 'Send small featured images', (bool) $s['images'], 'Only locally available JPEG/PNG/WebP files up to 512 KiB are embedded.');
        echo '</div><div class="mw-field"><label>Odoo event URL</label><input type="url" name="url" value="' . esc_attr($s['url']) . '" placeholder="https://odoo.example.com/mw-sync/v2/event"><small>HTTPS only. No redirects or credentials in the URL.</small></div></div>';
        echo '<div class="mw-fields" style="margin-top:16px">';
        foreach (['out_secret' => 'WooCommerce → Odoo secret', 'in_secret' => 'Odoo → WooCommerce secret'] as $k => $label) {
            echo '<div class="mw-field"><label>' . esc_html($label) . '</label><input type="password" name="' . esc_attr($k) . '" value="" autocomplete="new-password" placeholder="Leave blank to keep current"><small>' . (!empty($s[$k]) ? 'A secret is already stored. Leave this blank to keep it.' : 'Enter a random 32-128 character secret.') . '</small></div>';
        }
        echo '</div>';
        echo '<div class="mw-fields" style="margin-top:16px">';
        $nums = [
            'worker_batch' => ['Entities prepared per worker', 1, 50, '30'],
            'network_batch' => ['Entities per HTTP batch', 1, 20, '10'],
            'scan_batch' => ['Backfill records scanned per step', 20, 200, '100'],
            'timeout' => ['Network timeout (seconds)', 3, 20, '8'],
        ];
        foreach ($nums as $k => $n) {
            echo '<div class="mw-field"><label>' . esc_html($n[0]) . '</label><input type="number" name="' . esc_attr($k) . '" min="' . (int) $n[1] . '" max="' . (int) $n[2] . '" value="' . (int) $s[$k] . '"></div>';
        }
        echo '</div>';
        echo '<details class="mw-advanced"><summary>Advanced field allowlists & historical statuses</summary><div class="mw-fields" style="margin-top:14px">';
        foreach (['history_statuses' => 'Confirmed historical statuses', 'extra_order_meta' => 'Additional approved order meta keys', 'extra_customer_meta' => 'Additional approved customer meta keys', 'extra_product_meta' => 'Additional approved product meta keys'] as $k => $label) {
            echo '<div class="mw-field"><label>' . esc_html($label) . '</label><textarea rows="4" name="' . esc_attr($k) . '">' . esc_textarea($s[$k]) . '</textarea></div>';
        }
        echo '</div></details><div class="mw-actions"><button class="mw-btn mw-primary" type="submit">Save settings</button></div></form></section>';

        echo '<section class="mw-card"><div class="mw-inline" style="justify-content:space-between"><div><h2>Needs attention</h2><p class="desc" style="margin-bottom:0">Only failed or review items are shown here; normal pending items stay out of the table.</p></div>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="mw_sync_action">'; wp_nonce_field('mw_sync_action'); self::action_button('retry', 'Retry failed / review', 'secondary'); echo '</form></div>';
        echo '<div class="mw-table"><table class="widefat striped"><thead><tr><th>Type</th><th>Woo ID</th><th>State</th><th>Attempts</th><th>Diagnostic</th></tr></thead><tbody>';
        if (!$errors) { echo '<tr><td colspan="5"><span class="mw-muted">No failed or review items.</span></td></tr>'; }
        foreach ($errors as $r) {
            echo '<tr><td>' . esc_html($r->kind) . '</td><td>' . (int) $r->object_id . '</td><td><span class="mw-pill">' . esc_html($r->state) . '</span></td><td>' . (int) $r->attempts . '</td><td>' . esc_html($r->last_error) . '</td></tr>';
        }
        echo '</tbody></table></div><p class="mw-footer">Odoo Commerce Sync ' . esc_html(MW_SYNC_VERSION) . ' · One bounded queue worker · HMAC-signed HTTPS · no Odoo requests during ordinary storefront browsing. Action Scheduler async wake-ups run live sync/backfills without waiting for the next WP-Cron tick; the recurring recovery action remains as a safety net. Keep both servers clock-synchronized.</p></section>';
        echo '</div></div>';
    }
}
