import json

from odoo import api, fields, models, Command, _
from odoo.exceptions import UserError, ValidationError
from ..protocol import clean_text, digest, integer, number, parse_date, validate_order

import logging
logger = logging.getLogger(__name__)


class WooOrder(models.Model):
    _name = 'mw.order'
    _description = 'WooCommerce confirmed order'
    _rec_name = 'name'
    _order = 'id desc'

    connector_id = fields.Many2one('mw.connector', required=True, ondelete='restrict', index=True)
    company_id = fields.Many2one(related='connector_id.company_id', store=True, index=True)
    woo_id = fields.Char(required=True, index=True)
    name = fields.Char(required=True)
    woo_status = fields.Char(index=True)
    version = fields.Integer(default=0)
    fingerprint = fields.Char()
    native_fingerprint = fields.Char()
    snapshot = fields.Json(readonly=True)
    snapshot_text = fields.Text(compute='_snapshot_text')
    sync_state = fields.Selection([('done', 'Synchronized'), ('review', 'Needs review'), ('history', 'History - no stock movement')], default='done', index=True)
    last_error = fields.Text(readonly=True)
    live_order = fields.Boolean(default=False, readonly=True)
    customer_id = fields.Many2one('mw.customer', ondelete='restrict')
    partner_id = fields.Many2one(related='customer_id.partner_id', store=True)
    billing_partner_id = fields.Many2one('res.partner', ondelete='restrict')
    shipping_partner_id = fields.Many2one('res.partner', ondelete='restrict')
    sale_order_id = fields.Many2one('sale.order', ondelete='set null', copy=False)
    currency_id = fields.Many2one('res.currency', required=True)
    total = fields.Monetary(currency_field='currency_id', readonly=True)
    total_tax = fields.Monetary(currency_field='currency_id', readonly=True)
    shipping_total = fields.Monetary(currency_field='currency_id', readonly=True)
    shipping_tax = fields.Monetary(currency_field='currency_id', readonly=True)
    fee_total = fields.Monetary(currency_field='currency_id', readonly=True)
    coupon_discount = fields.Monetary(currency_field='currency_id', readonly=True)
    coupon_discount_tax = fields.Monetary(currency_field='currency_id', readonly=True)
    sale_savings = fields.Monetary(currency_field='currency_id', readonly=True)
    sale_savings_recorded = fields.Boolean(readonly=True)
    amount_refunded = fields.Monetary(currency_field='currency_id', readonly=True)
    reviewed_refund_amount = fields.Monetary(currency_field='currency_id', default=0, readonly=True)
    paid = fields.Boolean(readonly=True, index=True)
    is_cod = fields.Boolean(readonly=True)
    payment_method = fields.Char(readonly=True)
    transaction_reference = fields.Char(readonly=True)
    date_paid = fields.Datetime(readonly=True)
    date_created_woo = fields.Datetime(readonly=True)
    confirmed_at = fields.Datetime(readonly=True)
    coupon_codes = fields.Char(readonly=True)
    customer_note = fields.Text(readonly=True)
    shipping_details = fields.Text(readonly=True)
    line_ids = fields.One2many('mw.order.line', 'order_id', readonly=True)
    stock_product_ids = fields.Many2many('product.product', 'mw_order_stock_product_rel', 'order_id', 'product_id', copy=False)
    stock_versions = fields.Json(readonly=True)
    ack_pending = fields.Boolean(default=False, index=True)
    reservation_warning = fields.Char(readonly=True)
    packaging_processed = fields.Boolean(string="Packaging Logic Processed", default=False, readonly=True)
    _sql_constraints = [
        ('woo_order_unique', 'unique(connector_id,woo_id)', 'Woo order already imported.'),
        ('native_order_unique', 'unique(sale_order_id)', 'A native sale order may only map once.'),
    ]

    def _snapshot_text(self):
        for r in self:
            r.snapshot_text = json.dumps(r.snapshot or {}, ensure_ascii=False, indent=2)

    @api.model
    def _ingest(self, connector, d, version):
        validate_order(d)
        key = str(integer(d.get('id')))
        r = self.search([('connector_id', '=', connector.id), ('woo_id', '=', key)], limit=1)
        h = digest(d)
        if r and version < r.version:
            return r
        if r and version == r.version and h != r.fingerprint:
            raise ValidationError(_('Order revision collision. Resave the order in WooCommerce.'))
        if r and version == r.version and r.sync_state in ('done', 'history'):
            return r
        currency = self.env['res.currency'].with_context(active_test=False).search([('name', '=', d['currency'])], limit=1)
        if not currency:
            raise UserError(_('Install/enable the WooCommerce order currency.'))
        savings = d.get('sale_savings') or {}
        shipping_details = {'shipping_lines': d.get('shipping_lines', []),
                            'metadata': [m for m in d.get('metadata', []) if any(word in str(m.get('key', '')).lower() for word in ('ship', 'deliver', 'tracking', 'aramex', 'smsa', 'national', 'sa_na'))]}
        values = {'connector_id': connector.id,
                  'woo_id': key,
                  'name': 'Woo #' + str(d.get('order_number') or key),
                  'woo_status': d['status'],
                  'snapshot': d,
                  'version': version,
                  'fingerprint': h,
                  'currency_id': currency.id,
                   'total': round(float(number(d.get('total'))), 2),
                  'total_tax': round(float(number(d.get('total_tax'))), 2),
                  'shipping_total': round(float(number(d.get('shipping_total'))), 2),
                  'shipping_tax': round(float(number(d.get('shipping_tax'))), 2),
                  'fee_total': round(sum(number(x.get('total')) for x in d.get('fee_lines', [])), 2),
                  'coupon_discount': float(number(d.get('discount_total'))),
                  'sale_savings': float(number(savings.get('amount'))),
                  'sale_savings_recorded': savings.get('amount') is not None,
                  'amount_refunded': float(number(d.get('amount_refunded'))),
                  'paid': d['paid'], 'is_cod': d.get('payment_method') == 'cod',
                  'payment_method': str(d.get('payment_method_title') or d.get('payment_method') or ''),
                  'transaction_reference': str(d.get('transaction_id') or ''),
                  'date_paid': parse_date(d.get('date_paid')),
                  'date_created_woo': parse_date(d.get('date_created')),
                  'confirmed_at': parse_date(d.get('confirmed_at')),
                  'coupon_codes': ', '.join(str(x.get('code') or '') for x in d.get('coupon_lines', [])),
                  'customer_note': str(d.get('customer_note') or ''),
                  'shipping_details': json.dumps(shipping_details, ensure_ascii=False, indent=2)}
        if r:
            previous_ids = [str(x.get('variation_id') or x.get('product_id') or '') for x in (r.snapshot or {}).get('line_items', [])]
            previous_maps = self.env['mw.catalog'].search([('connector_id', '=', connector.id), ('woo_id', 'in', previous_ids)])
            r.stock_product_ids = [Command.link(pid) for pid in previous_maps.mapped('product_id').ids]
            r.write(values)
        else:
            values['live_order'] = not bool(d.get('historical'))
            r = self.create(values)
        if r.sale_order_id:
            r.stock_product_ids = [Command.link(pid) for pid in r.sale_order_id.order_line.mapped('product_id').ids]
        r._snapshot_lines()
        try:
            with self.env.cr.savepoint():
                r._apply_native()
            if not r.live_order:
                r.write({'sync_state': 'history', 'last_error': False})
            else:
                r.write({'sync_state': 'done', 'last_error': False})
                r._prepare_stock_ack()
        except (UserError, ValidationError, ValueError) as exc:
            r.write({'sync_state': 'review', 'last_error': str(exc)[:2000], 'ack_pending': False})
        return r

    def _snapshot_lines(self):
        self.ensure_one()
        # One fixed snapshot per Woo line, not an ever-growing event log.
        existing = {line.woo_key: line for line in self.line_ids}
        keep = set()
        for field, kind in [('line_items', 'product'), ('shipping_lines', 'shipping'), ('fee_lines', 'fee')]:
            for line in self.snapshot.get(field, []):
                key = kind + ':' + str(line['id'])
                keep.add(key)
                vals = {'order_id': self.id,
                        'woo_key': key,
                        'kind': kind,
                        'name': clean_text(line.get('name') or line.get('method_title') or kind, 512),
                        'sku': str(line.get('sku') or ''),
                        'quantity': float(number(line.get('quantity', 1))),
                        'subtotal': float(number(line.get('subtotal', line.get('total')))), 'total': float(number(line.get('total'))),
                        'tax': float(number(line.get('total_tax'))), 'details': line}
                if key in existing:
                    existing[key].write(vals)
                else:
                    self.env['mw.order.line'].create(vals)
        self.line_ids.filtered(lambda x: x.woo_key not in keep).unlink()

    def _taxes(self, line):
        self.ensure_one()
        taxes = self.env['account.tax']
        total = (line.get('taxes') or {}).get('total') or {}
        if not isinstance(total, dict):
            raise UserError(_('Malformed WooCommerce line tax allocation.'))
        for rate, value in total.items():
            if value == '':
                continue
            matches = self.connector_id.tax_map_ids.filtered(lambda x: x.woo_rate_id == str(rate))
            if len(matches) != 1:
                raise UserError(_('Missing tax mapping for Woo rate ID %s. No tax amount was guessed.') % rate)
            tax = matches.tax_id
            if tax.price_include or tax.company_id != self.company_id:
                raise UserError(_('Mapped tax must be tax-exclusive and from this company.'))
            taxes |= tax
        if not taxes:
            if number(line.get('total_tax')) != 0:
                raise UserError(_('A taxable line has no mapped Woo tax identifiers.'))
            exempt = self.connector_id.tax_map_ids.filtered(lambda x: x.woo_rate_id == '2').tax_id
            if len(exempt) == 1:
                taxes = exempt
        return taxes

    def _catalog_regular_unit_ex_tax(self, mapped, line, qty, net):
        """Return the best tax-exclusive pre-discount unit price available.

        Woo order lines store the charged amount, but the embedded catalog snapshot
        also carries regular/current prices.  Use the current tax-exclusive catalog
        price as a conversion anchor so the Odoo sale/invoice line can show the
        original unit price with a native discount instead of replacing the unit
        price with the discounted amount.  Fall back to the Woo line subtotal for
        historical/legacy payloads where no usable catalog snapshot exists.
        """
        qty_num = number(qty)
        net_num = number(net)
        if qty_num <= 0:
            return float(net_num)
        net_unit = net_num / qty_num
        subtotal_unit = number(line.get('subtotal', line.get('total'))) / qty_num
        base_unit = max(net_unit, subtotal_unit)
        snapshot = (mapped.snapshot or {}) if mapped else {}
        regular = number(snapshot.get('regular_price'))
        current = number(snapshot.get('price'))
        current_ex = number(snapshot.get('price_ex_tax'))
        if regular > 0:
            regular_ex = number(0)
            if current > 0 and current_ex > 0:
                regular_ex = current_ex * regular / current
            elif not snapshot.get('prices_include_tax'):
                regular_ex = regular
            if regular_ex > base_unit:
                base_unit = regular_ex
        return float(base_unit)

    def _mark_service_charge_lines_delivered(self, order):
        """Make connector shipping/fee service lines invoiceable when needed.

        The connector service product may be configured with invoicing based on
        delivered quantity.  Shipping and payment fees are considered delivered once
        the Woo order reaches the configured fulfillment stage, so mark only those connector
        lines delivered before creating the invoice.  Product lines are untouched.
        """
        charge_lines = order.order_line.filtered(
            lambda line: not line.display_type
            and line.mw_line_key
            and (line.mw_line_key.startswith('shipping:') or line.mw_line_key.startswith('fee:'))
        )
        for line in charge_lines:
            if getattr(line.product_id, 'invoice_policy', False) == 'delivery' and line.qty_delivered < line.product_uom_qty:
                line.qty_delivered = line.product_uom_qty

    def _native_line_values(self):
        self.ensure_one()
        commands = []
        Catalog = self.env['mw.catalog']
        for d in sorted(self.snapshot.get('catalog', []), key=lambda x: int(x['id'])):
            Catalog._ingest(self.connector_id, d, 0)
        for field, kind in [('line_items', 'product'), ('shipping_lines', 'shipping'), ('fee_lines', 'fee')]:
            for line in self.snapshot.get(field, []):
                qty = float(number(line.get('quantity', 1))) if kind == 'product' else 1.0
                if qty <= 0:
                    raise UserError(_('Order quantities must be positive.'))
                if kind == 'product':
                    wid = str(line.get('variation_id') or line.get('product_id') or '')
                    mapped = Catalog.search([('connector_id', '=', self.connector_id.id), ('woo_id', '=', wid)],
                                            limit=1)
                    if not mapped or not mapped.product_id or mapped.sync_state != 'done':
                        raise UserError(_('Product mapping needs review for Woo product %s.') % wid)
                    product = mapped.product_id
                    if str(line.get('sku') or '') != mapped.sku:
                        raise UserError(_('The order SKU does not match the mapped catalog record.'))
                else:
                    product = self.connector_id.service_product_id
                taxes = self._taxes(line)
                net = round(float(number(line.get('total'))), 2)
                native_tax = round(float(number(line.get('total_tax'))), 2)
                price_unit = net / qty
                discount = 0.0
                if kind == 'product':
                    price_unit = self._catalog_regular_unit_ex_tax(mapped, line, qty, net)
                    if price_unit > 0 and net / qty <= price_unit:
                        discount = max(0.0, min(100.0, (price_unit - (net / qty)) * 100.0 / price_unit))
                vals = {'product_id': product.id,
                        'name': clean_text(line.get('name') or line.get('method_title') or product.display_name, 512),
                        'product_uom_qty': qty,
                        'product_uom': product.uom_id.id,
                        'price_unit': price_unit,
                        'discount': discount,
                        'tax_id': [Command.set(taxes.ids)],
                        'mw_line_key': kind + ':' + str(line['id']),
                        'woo_line_item_id': line['id'],
                        'mw_woo_net': net,
                        'mw_woo_tax': native_tax,
                        'mw_coupon_savings': float(
                            number(line.get('subtotal', line.get('total'))) - number(line.get('total'))),
                        'mw_line_details': line}
                commands.append(Command.create(vals))
        return commands

    def _clean_line_taxes(self, line):
        """it skips the empty value for taxes and resolved our commercial hash difference problem"""
        raw_taxes = (line.get('taxes') or {}).get('total') or {}
        if not isinstance(raw_taxes, dict):
            return {}
        return {rate: value for rate, value in raw_taxes.items() if value != ''}

    def _commercial_snapshot_data(self):
        keys = ('id', 'product_id', 'variation_id', 'sku', 'quantity', 'subtotal', 'total')
        relevant = {}
        relevant['currency'] = self.snapshot.get('currency')
        relevant['total'] = self.snapshot.get('total')
        relevant['shipping_total'] = self.snapshot.get('shipping_total')
        relevant['shipping_tax'] = self.snapshot.get('shipping_tax')
        relevant['fee_total'] = str(sum(number(x.get('total')) for x in self.snapshot.get('fee_lines', [])))
        relevant['shipping_lines'] = [
            {
                'id': line.get('id'),
                'name': line.get('method_title') or line.get('name'),
                'total': line.get('total'),
                'total_tax': line.get('total_tax'),
                'taxes': self._clean_line_taxes(line),
            }
            for line in self.snapshot.get('shipping_lines', [])
        ]
        relevant['fee_lines'] = [
            {
                'id': line.get('id'),
                'name': line.get('name'),
                'total': line.get('total'),
                'total_tax': line.get('total_tax'),
                'taxes': self._clean_line_taxes(line),
            }
            for line in self.snapshot.get('fee_lines', [])
        ]
        line_list = []
        for line in self.snapshot.get('line_items', []):
            line_data = {k: line.get(k) for k in keys}
            line_data['taxes'] = self._clean_line_taxes(line)
            line_list.append(line_data)
        relevant['line_items'] = line_list
        return relevant

    def _commercial_hash(self):
        return digest(self._commercial_snapshot_data())

    def _check_native_totals(self, order):
        tolerance = 0.05
        for line in order.order_line.filtered(lambda x: not x.display_type):
            subtotal_diff = abs(line.price_subtotal - line.mw_woo_net)
            tax_diff = abs(line.price_tax - line.mw_woo_tax)
            if subtotal_diff > tolerance or tax_diff > tolerance:
                raise UserError(_('Odoo line tax/net does not match WooCommerce. Check tax mapping, currency rounding and unit precision.'))
        # order_total_diff = abs(order.amount_total - self.total)
        # order_tax_diff = abs(order.amount_tax - self.total_tax)
        # if order_total_diff > tolerance or order_tax_diff > tolerance:
        #     raise UserError(_('Odoo totals differ from the recorded WooCommerce totals. No automatic balancing/discount line was added.'))

    def _register_payment(self, order):
        logger.info("register payment for order %s", order.name)
        self.ensure_one()
        invoices_to_pay = order.invoice_ids.filtered(lambda inv: inv.move_type == 'out_invoice' and inv.state == 'posted' and inv.payment_state in ('not_paid', 'partial') and inv.amount_residual > 0)
        if invoices_to_pay:
            logger.info("there are %d invoices to pay for order %s", invoices_to_pay, order.name)
            if self.is_cod:
                payment_journal = self.connector_id.cod_journal_id
            else:
                payment_journal = self.connector_id.journal_id
            if not payment_journal:
                raise UserError(_("Payment journal is not configured on the WooCommerce connector for '%s' payment method.") % ('COD' if self.is_cod else 'Online'))
            for invoice in invoices_to_pay:
                existing_payment = self.env['account.payment'].search_count([
                    ('invoice_ids', 'in', invoice.ids),
                    ('journal_id', '=', payment_journal.id),
                    ('state', 'not in', ('canceled', 'rejected')),
                ])
                if existing_payment:
                    logger.warning("Skip payment for invoice %s: a payment already exists but the invoice is still not paid.", invoice.name)
                    continue
                payment_register = self.env['account.payment.register'].with_context(active_model='account.move', active_ids=invoice.ids).create(
                    {
                        'journal_id': payment_journal.id,
                        'amount': invoice.amount_residual,
                        'payment_date': self.date_paid or fields.Date.today(),
                        'communication': invoice.name,
                    })
                payment_register._create_payments()

    def _synchronize_order_lines(self, order):
        self.ensure_one()
        is_shipped = order.picking_ids.filtered(lambda p: p.state == 'done')
        is_posted = order.invoice_ids.filtered(lambda i: i.state == 'posted')
        if is_shipped or is_posted:
            raise UserError(_(
                "The WooCommerce order has changed, but the Odoo order has already been "
                "shipped or invoiced. Please handle this discrepancy manually."
            ))
        order.locked = False
        if order.state != 'cancel':
            order.action_cancel()
        order.action_draft()
        new_line_vals = self._native_line_values()
        order.order_line.unlink()
        order.write({'order_line': new_line_vals, 'amount_total': round(order.amount_total, 2), 'amount_tax': round(order.amount_tax, 2)})
        order.action_confirm()

    def _apply_native(self):
        self.ensure_one()
        c = self.connector_id
        customer = self.env['mw.customer']._from_order(c, self.snapshot)
        self.customer_id = customer
        billing = self.snapshot.get('billing') or {}
        shipping = self.snapshot.get('shipping') or {}
        # An all-empty shipping structure means Woo is using billing as delivery.
        if not any(shipping.get(k) for k in ('address_1', 'address_2', 'city', 'postcode', 'country')):
            shipping = billing
        self.billing_partner_id = customer._order_address(self.woo_id, billing, 'invoice')
        self.shipping_partner_id = customer._order_address(self.woo_id, shipping, 'delivery')
        if not self.live_order:
            return
        for product in sorted(self.snapshot.get('catalog', []), key=lambda x: int(x['id'])):
            self.env['mw.catalog']._ingest(c, product, 0)
        order = self.sale_order_id
        commercial = self._commercial_hash()
        changed = not order or commercial != self.native_fingerprint
        Picking = self.env['stock.picking']
        if not order and 'owss_woo_order_id' in Picking._fields:
            legacy = Picking.search([('owss_woo_order_id', '=', self.woo_id), ('company_id', '=', self.company_id.id), ('state', '!=', 'cancel')], limit=1)
            if legacy:
                raise UserError(_('A reservation from the old stock-only connector exists. Review/migrate it before creating a second reservation.'))
        if self.woo_status in ('failed', 'pending'):
            if order and order.state != 'cancel':
                order._action_cancel()
            return
        vals = {'partner_id': customer.partner_id.id,
                'partner_invoice_id': self.billing_partner_id.id,
                'partner_shipping_id': self.shipping_partner_id.id,
                'company_id': self.company_id.id,
                'warehouse_id': c.warehouse_id.id,
                'pricelist_id': c._pricelist(self.currency_id.name).id,
                'client_order_ref': 'MW/%s/%s' % (c.store_key, self.woo_id), 'origin': self.name,
                'note': self.customer_note or '', 'mw_order_id': self.id}
        if not order:
            vals['order_line'] = self._native_line_values()
            order = self.env['sale.order'].with_context(tracking_disable=True, mail_create_nosubscribe=True).create(vals)
            order.write({
                'amount_total': round(order.amount_total, 2),
                'amount_tax': round(order.amount_tax, 2)
            })
            self.sale_order_id = order
        elif self.woo_status == 'cancelled' and order.mw_is_cod:
            logger.info("Processing COD cancellation for Woo order %s (Odoo: %s)", self.woo_id, order.name)
            if order.picking_ids.filtered(lambda p: p.state == 'done') or order.invoice_ids.filtered(lambda i: i.state == 'posted'):
                self._process_full_refund(order)
            else:
                if order.state != 'cancel':
                    order.locked = False
                    order.action_cancel()
                    logger.info("Successfully cancelled Odoo order %s and related documents.", order.name)
                return
        elif self.woo_status == 'refunded':
            logger.info("Processing full refund for Woo order %s (Odoo: %s)", self.woo_id, order.name)
            if order.mw_is_cod:
                raise UserError(_(
                    "The 'wc-refunded' status is for online payments, not COD. "
                    "Order %s is a COD order. Please use 'wc-cancelled' or handle manually.", order.name
                ))
            self._process_full_refund(order)
            return
        elif changed:
            self._synchronize_order_lines(order)
        elif order.state == 'cancel':
            order.action_draft()
            order.write(vals)
        else:
            order.write({key: vals[key] for key in ('partner_invoice_id', 'partner_shipping_id', 'note')})
        self._check_native_totals(order)
        if order.state in ('draft', 'sent'):
            order.action_confirm()
        if c.fulfillment_status and self.woo_status == c.fulfillment_status and not self.packaging_processed:
            pickings_to_process = order.picking_ids.filtered(lambda p: p.state not in ('done', 'cancel'))
            if pickings_to_process:
                pickings_to_process.action_assign()
                ready_pickings = pickings_to_process.filtered(lambda p: p.state == 'assigned')
                for picking in ready_pickings:
                    for move in picking.move_ids_without_package:
                        move._set_quantity_done(move.product_uom_qty)
                    picking.button_validate()
            has_done_picking = order.picking_ids.filtered(lambda p: p.state == 'done')
            if has_done_picking:
                self._mark_service_charge_lines_delivered(order)
                if not order.invoice_ids.filtered(lambda i: i.state == 'posted'):
                    if not order.invoice_ids:
                        journal = self.env['account.journal'].sudo().search([('type', '=', 'sale'), ('company_id', '=', self.company_id.id)], limit=1)
                        order_invoices = order._create_invoices()
                        for invoice in order_invoices:
                            if not invoice.journal_id and journal:
                                invoice.write({'journal_id': journal.id})
                            invoice.action_post()
                self.packaging_processed = True
        if self.paid:
            self._register_payment(order)
        pickings_to_process = order.picking_ids.filtered(lambda p: p.state not in ('done', 'cancel'))
        if pickings_to_process and pickings_to_process.partner_id != self.shipping_partner_id:
            logger.info("Setting partner_id to %s for pickings %s", self.shipping_partner_id.id, pickings_to_process.ids)
            pickings_to_process.write({'partner_id': self.shipping_partner_id.id})
        incomplete = order.picking_ids.filtered(lambda p: p.state in ('confirmed', 'waiting'))
        self.reservation_warning = _('Check availability for %s. Some items could not be reserved.') % order.name if incomplete else False
        self.native_fingerprint = commercial

    def _process_full_refund(self, order):
        self.ensure_one()
        logger.info("Starting full refund process for Odoo order %s.", order.name)
        posted_invoices = order.invoice_ids.filtered(lambda inv: inv.state == 'posted' and inv.move_type == 'out_invoice')
        if not posted_invoices:
            logger.warning("refunded: No posted invoice found for order %s. Cannot create credit note.", order.name)
        else:
            invoice_to_refund = posted_invoices[0]
            if invoice_to_refund.reversal_move_ids:
                logger.info("Credit note for invoice %s already exists. Skipping.", invoice_to_refund.name)
            else:
                reversal_wizard = self.env['account.move.reversal'].with_context(active_model="account.move", active_ids=invoice_to_refund.ids
                                                                                 ).create({
                    'reason': _('Full refund from WooCommerce order %s', self.woo_id),
                    'journal_id': invoice_to_refund.journal_id.id,
                })
                reversal_action = reversal_wizard.reverse_moves()
                credit_note = self.env['account.move'].browse(reversal_action['res_id'])
                credit_note.action_post()
                logger.info("Created and posted credit note %s for invoice %s.", credit_note.name,
                            invoice_to_refund.name)
        done_pickings = order.picking_ids.filtered(lambda p: p.state == 'done')
        if not done_pickings:
            logger.warning("wc-refunded: No 'Done' picking found for order %s. Cannot create return.", order.name)
        else:
            for picking_to_return in done_pickings:
                if self.env['stock.picking'].search_count([('origin', '=', f"Return of {picking_to_return.name}")]) > 0:
                    logger.info("Return for picking %s already exists. Skipping.", picking_to_return.name)
                    continue
                logger.info("Creating return for picking %s.", picking_to_return.name)
                return_wizard = self.env['stock.return.picking'].with_context(active_id=picking_to_return.id, active_model='stock.picking').create({})
                return_wizard.product_return_moves.quantity = 1
                # # Use default_get to prepare the wizard with all lines and quantities.
                # ReturnWizard = self.env['stock.return.picking'].with_context(active_id=picking_to_return.id, active_model='stock.picking')
                # default_data = ReturnWizard.default_get(['product_return_moves', 'parent_location_id', 'original_location_id', 'location_id'])
                # return_wizard = ReturnWizard.create(default_data)
                # # Create the return picking.
                return_action = return_wizard.action_create_returns()
                if return_action and return_action.get('res_id'):
                    return_picking = self.env['stock.picking'].browse(return_action['res_id'])
                    logger.info("Created return picking %s for original picking %s.", return_picking.name,
                                picking_to_return.name)

    def _prepare_stock_ack(self):
        self.ensure_one()
        maps = self.env['mw.catalog'].search([('connector_id', '=', self.connector_id.id), ('woo_id', 'in',
                                                                                            [str(x.get('variation_id') or x.get('product_id') or '') for x in self.snapshot.get('line_items', [])])])
        products = maps.mapped('product_id') | self.stock_product_ids
        if self.sale_order_id:
            products |= self.sale_order_id.order_line.mapped('product_id').filtered(lambda p: p.is_storable)
        self.stock_product_ids = [Command.link(pid) for pid in products.ids]
        self.env['mw.stock.outbox']._touch_products(products)
        rows = self.env['mw.stock.outbox'].search([('connector_id', '=', self.connector_id.id), ('product_id', 'in', products.ids)])
        self.stock_versions = {str(row.catalog_id.woo_id): row.version for row in rows}
        self.ack_pending = True

    def _ack_payload(self):
        self.ensure_one()
        return {'order_id': int(self.woo_id), 'source_version': self.version, 'stock_versions': self.stock_versions or {}, 'live': self.live_order}

    def action_retry(self):
        if not self.env.user.has_group('woo_commerce_connector.group_manager'):
            raise UserError(_('Connector Manager rights are required.'))
        for r in self:
            r.connector_id._lock('order:' + r.woo_id)
            with self.env.cr.savepoint():
                r._apply_native()
                r.write({'sync_state': 'done' if r.live_order else 'history', 'last_error': False})
                if r.live_order:
                    r._prepare_stock_ack()
        return True

    def action_promote(self):
        if not self.env.user.has_group('woo_commerce_connector.group_manager'):
            raise UserError(_('Connector Manager rights are required.'))
        for r in self:
            if r.woo_status != 'processing' or r.live_order:
                raise UserError(_('Only a historical order currently at Processing can be activated. Verify it has not already been fulfilled/reserved elsewhere.'))
            r.live_order = True
        return self.action_retry()

    def action_acknowledge_refund(self):
        if not self.env.user.has_group('woo_commerce_connector.group_manager'):
            raise UserError(_('Connector Manager rights are required.'))
        for r in self:
            r.reviewed_refund_amount = r.amount_refunded
            if r.woo_status == 'refunded':
                # Acknowledge financial history; do not manufacture a stock receipt.
                if r.sale_order_id and not r.sale_order_id.invoice_ids and not r.sale_order_id.picking_ids.filtered(lambda p: p.state == 'done'):
                    r.sale_order_id._action_cancel()
                r.write({'sync_state': 'done', 'last_error': False})
                r._prepare_stock_ack()
            else:
                r.action_retry()
        return True


class WooOrderLine(models.Model):
    _name = 'mw.order.line'
    _description = 'Exact WooCommerce order line'
    order_id = fields.Many2one('mw.order', required=True, ondelete='cascade', index=True)
    company_id = fields.Many2one(related='order_id.company_id', store=True)
    currency_id = fields.Many2one(related='order_id.currency_id')
    woo_key = fields.Char(required=True)
    kind = fields.Char()
    name = fields.Char()
    sku = fields.Char()
    quantity = fields.Float(digits='Product Unit of Measure')
    subtotal = fields.Monetary(currency_field='currency_id')
    total = fields.Monetary(currency_field='currency_id')
    tax = fields.Monetary(currency_field='currency_id')
    details = fields.Json()
    _sql_constraints = [('woo_line_unique', 'unique(order_id,woo_key)', 'Woo order line already exists.')]


class SaleOrder(models.Model):
    _inherit = 'sale.order'
    mw_order_id = fields.Many2one('mw.order', copy=False, index=True, ondelete='restrict')
    mw_woo_status = fields.Char(related='mw_order_id.woo_status')
    mw_paid = fields.Boolean(related='mw_order_id.paid')
    mw_is_cod = fields.Boolean(related='mw_order_id.is_cod')
    mw_sale_savings = fields.Monetary(related='mw_order_id.sale_savings', currency_field='currency_id')
    mw_shipping_details = fields.Text(related='mw_order_id.shipping_details')


class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'
    mw_line_key = fields.Char(copy=False)
    mw_woo_net = fields.Monetary(currency_field='currency_id', copy=False)
    mw_woo_tax = fields.Monetary(currency_field='currency_id', copy=False)
    mw_coupon_savings = fields.Monetary(currency_field='currency_id', copy=False)
    mw_line_details = fields.Json(copy=False)
    woo_line_item_id = fields.Char(string="Line Item ID", help="The unique ID for this line item from WooCommerce.", copy=False, readonly=True, index=True,)