import logging
import re
import secrets
from urllib.parse import urlparse

from odoo import api, fields, models, _
from odoo.exceptions import AccessError, ValidationError, UserError
from ..protocol import ProtocolError, validate_envelope, lock_key

_logger = logging.getLogger(__name__)


class Connector(models.Model):
    _name = 'mw.connector'
    _description = 'WooCommerce connection'
    _check_company_auto = True

    name = fields.Char(required=True, default='WooCommerce')
    active = fields.Boolean(default=True)
    enabled = fields.Boolean(default=False)
    stock_enabled = fields.Boolean(default=False)
    store_key = fields.Char(required=True, index=True, copy=False)
    company_id = fields.Many2one('res.company', required=True, default=lambda s: s.env.company)
    warehouse_id = fields.Many2one('stock.warehouse', required=True, check_company=True)
    integration_user_id = fields.Many2one('res.users', required=True, help='Dedicated internal user with Connector Service rights; no Settings rights required.')
    incoming_secret = fields.Char(required=True, groups='woo_commerce_connector.group_manager', copy=False, default=lambda s: secrets.token_hex(32))
    outgoing_secret = fields.Char(required=True, groups='woo_commerce_connector.group_manager', copy=False, default=lambda s: secrets.token_hex(32))
    stock_url = fields.Char(required=True)
    pricelist_id = fields.Many2one('product.pricelist', required=True, check_company=True, help='Website catalog currency. Orders may use a mapped pricelist for another currency.')
    service_product_id = fields.Many2one('product.product', required=True, check_company=True, domain="[('type', '=', 'service')]", help='Service product for shipping and fee lines. Never used as a tax substitute.')
    fulfillment_status = fields.Char(string='Automatic fulfillment status', help='Optional WooCommerce status slug without wc-. When received, validate available deliveries and issue invoices.')
    safety_stock = fields.Float(default=0)
    batch_size = fields.Integer(
        string='Stock queue batch ceiling', default=50,
        help='Legacy overall ceiling. The actual Woo request uses the lower of this value and Stock items per Woo request.'
    )
    stock_request_batch_size = fields.Integer(
        string='Stock items per Woo request', default=10,
        help='Maximum stock products sent to WooCommerce in one HTTP request. Lower values reduce Woo load and timeout risk.'
    )
    stock_deferred_retry_seconds = fields.Integer(
        string='Deferred stock retry (seconds)', default=120,
        help='Wait before retrying a temporarily busy WooCommerce stock item.'
    )
    stock_guard_retry_seconds = fields.Integer(
        string='Order guard retry (seconds)', default=900,
        help='Wait before retrying a stock item blocked by WooCommerce order reservation acknowledgement. A longer delay prevents guarded products from monopolizing the stock queue.'
    )
    network_timeout = fields.Integer(default=8)
    full_stock_cursor = fields.Integer(default=-1, help='-1 means no manual stock backfill is active.')
    last_error = fields.Char(readonly=True)
    last_success = fields.Datetime(readonly=True)
    delivery_failures = fields.Integer(default=0, readonly=True)
    delivery_after = fields.Datetime(readonly=True)
    tax_map_ids = fields.One2many('mw.tax.map', 'connector_id')
    currency_map_ids = fields.One2many('mw.currency.map', 'connector_id')
    journal_id = fields.Many2one('account.journal', string='Online Payment Journal', domain="[('type', '=', 'bank')]")
    cod_journal_id = fields.Many2one('account.journal', string='COD Journal', domain="[('type', '=', 'cash')]")
    _sql_constraints = [('store_key_unique', 'unique(store_key)', 'Store identifier must be unique.')]

    @api.constrains('stock_url', 'store_key', 'warehouse_id', 'company_id', 'integration_user_id', 'service_product_id',
                    'batch_size', 'stock_request_batch_size', 'stock_deferred_retry_seconds', 'stock_guard_retry_seconds', 'safety_stock')
    def _validate_config(self):
        for r in self:
            u = urlparse(r.stock_url or '')
            if u.scheme != 'https' or not u.hostname or u.username or u.password or u.query or u.fragment or u.port not in (None, 443):
                raise ValidationError(_('Use an HTTPS stock endpoint on port 443, without credentials, query or fragment.'))
            if not re.fullmatch(r'[A-Za-z0-9_-]{16,80}', r.store_key or ''):
                raise ValidationError(_('Use the store identifier displayed by the WordPress plugin.'))
            if r.warehouse_id.company_id != r.company_id or r.company_id not in r.integration_user_id.company_ids:
                raise ValidationError(_('Warehouse and integration user must belong to the configured company.'))
            if r.integration_user_id.share:
                raise ValidationError(_('The integration user must be an internal user.'))
            if not 1 <= r.batch_size <= 100 or r.safety_stock < 0:
                raise ValidationError(_('Batch must be 1-100; stock buffer must not be negative.'))
            if not 1 <= r.stock_request_batch_size <= 25:
                raise ValidationError(_('Stock items per Woo request must be between 1 and 25.'))
            if not 30 <= r.stock_deferred_retry_seconds <= 3600:
                raise ValidationError(_('Deferred stock retry must be between 30 and 3600 seconds.'))
            if not 120 <= r.stock_guard_retry_seconds <= 86400:
                raise ValidationError(_('Order guard retry must be between 120 and 86400 seconds.'))
            if r.service_product_id.type != 'service':
                raise ValidationError(_('Shipping/fee product must be a service.'))

    @api.constrains('incoming_secret', 'outgoing_secret')
    def _validate_secrets(self):
        for r in self:
            if len(r.incoming_secret or '') < 32 or len(r.outgoing_secret or '') < 32:
                raise ValidationError(_('Use separate secrets containing at least 32 characters.'))

    def _lock(self, scope):
        self.ensure_one()
        self.env.cr.execute('SELECT pg_advisory_xact_lock(%s)', [lock_key('%s:%s' % (self.id, scope))])

    def _dispatch_one(self, data):
        self.ensure_one()
        self._lock('%s:%s' % (data['kind'], data['id']))
        model = {'product': 'mw.catalog', 'customer': 'mw.customer', 'order': 'mw.order','exchange': 'mw.exchange'}[data['kind']]
        record = self.env[model]._ingest(self, data['data'], data['version'])
        result = {'ok': True, 'kind': data['kind'], 'id': data['id'], 'version': data['version'], 'state': record.sync_state}
        if data['kind'] == 'order' and record.ack_pending and record.stock_versions:
            result['ack'] = record._ack_payload()
        return result

    def _dispatch(self, data):
        self.ensure_one()
        validate_envelope(data, self.store_key)
        if data['kind'] == 'ping':
            return {'ok': True, 'schema': 2, 'odoo_version': 18, 'connector_version': '2.1.0'}
        if not self.integration_user_id.has_group('woo_commerce_connector.group_service'):
            raise UserError(_('Assign Connector Service to the dedicated integration user.'))
        if data['kind'] != 'batch':
            return self._dispatch_one(data)

        results = []
        for item in data['items']:
            try:
                with self.env.cr.savepoint():
                    # Re-validate the item in a normal envelope so one bad entity
                    # cannot weaken validation for the other batch members.
                    validate_envelope({'schema': 2, 'store': self.store_key, **item}, self.store_key)
                    results.append(self._dispatch_one(item))
            except ProtocolError:
                results.append({'ok': False, 'kind': item.get('kind'), 'id': item.get('id'), 'version': item.get('version'),
                                'state': 'review', 'error': 'invalid_payload'})
            except AccessError:
                results.append({'ok': False, 'kind': item.get('kind'), 'id': item.get('id'), 'version': item.get('version'),
                                'state': 'review', 'error': 'integration_user_permissions'})
            except (UserError, ValidationError, ValueError):
                results.append({'ok': False, 'kind': item.get('kind'), 'id': item.get('id'), 'version': item.get('version'),
                                'state': 'review', 'error': 'configuration_or_business_rule'})
            except Exception:
                _logger.exception('Woo batch item failed; connector=%s kind=%s id=%s', self.id, item.get('kind'), item.get('id'))
                results.append({'ok': False, 'kind': item.get('kind'), 'id': item.get('id'), 'version': item.get('version'),
                                'state': 'retry', 'error': 'temporary_server_error'})
        return {'ok': True, 'kind': 'batch', 'results': results}

    def _pricelist(self, code):
        self.ensure_one()
        if self.pricelist_id.currency_id.name == code:
            return self.pricelist_id
        match = self.currency_map_ids.filtered(lambda m: m.currency_id.name == code)
        if len(match) != 1:
            raise UserError(_('Map the WooCommerce order currency to an Odoo pricelist.'))
        return match.pricelist_id

    def action_queue_stock(self):
        self.ensure_one()
        if not self.env.user.has_group('woo_commerce_connector.group_manager'):
            raise UserError(_('Connector Manager rights are required.'))
        self.full_stock_cursor = 0
        return True

    def action_retry_stock(self):
        if not self.env.user.has_group('woo_commerce_connector.group_manager'):
            raise UserError(_('Connector Manager rights are required.'))
        for r in self:
            r.write({'delivery_failures': 0, 'delivery_after': False, 'last_error': False})
            rows = self.env['mw.stock.outbox'].search([('connector_id', '=', r.id), ('dirty', '=', True)])
            rows.write({'attempts': 0, 'next_attempt': False, 'last_error': False})
        return True


class TaxMap(models.Model):
    _name = 'mw.tax.map'
    _description = 'WooCommerce historical tax rate mapping'
    connector_id = fields.Many2one('mw.connector', required=True, ondelete='cascade')
    company_id = fields.Many2one(related='connector_id.company_id', store=True)
    woo_rate_id = fields.Char(required=True)
    name = fields.Char(help='Optional Woo tax label, for operator reference.')
    tax_id = fields.Many2one('account.tax', required=True, domain="[('type_tax_use', '=', 'sale'), ('company_id', '=', company_id)]")
    _sql_constraints = [('tax_unique', 'unique(connector_id,woo_rate_id)', 'Woo tax rate is already mapped.')]

    @api.constrains('tax_id', 'connector_id')
    def _check_tax(self):
        for r in self:
            if r.tax_id.company_id != r.company_id or r.tax_id.type_tax_use != 'sale' or r.tax_id.price_include:
                raise ValidationError(_('Map a sales tax from this company with tax excluded from price. Woo order lines are already net amounts.'))


class CurrencyMap(models.Model):
    _name = 'mw.currency.map'
    _description = 'WooCommerce currency/pricelist mapping'
    connector_id = fields.Many2one('mw.connector', required=True, ondelete='cascade')
    company_id = fields.Many2one(related='connector_id.company_id', store=True)
    currency_id = fields.Many2one('res.currency', required=True)
    pricelist_id = fields.Many2one('product.pricelist', required=True)
    _sql_constraints = [('currency_unique', 'unique(connector_id,currency_id)', 'Currency already mapped.')]

    @api.constrains('currency_id', 'pricelist_id', 'connector_id')
    def _check_currency(self):
        for r in self:
            if r.pricelist_id.currency_id != r.currency_id or r.pricelist_id.company_id not in (self.env['res.company'], r.company_id):
                raise ValidationError(_('Choose a matching currency and company pricelist.'))
