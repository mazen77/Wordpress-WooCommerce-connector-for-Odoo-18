import base64
import io
import json
from PIL import Image

from odoo import api, fields, models, Command, _
from odoo.exceptions import UserError, ValidationError
from ..protocol import clean_text, digest, integer, number


class AttributeMap(models.Model):
    _name = 'mw.attribute.map'
    _description = 'WooCommerce attribute mapping'
    _order = 'id'

    connector_id = fields.Many2one('mw.connector', required=True, ondelete='cascade', index=True)
    company_id = fields.Many2one(related='connector_id.company_id', store=True, index=True)
    woo_key = fields.Char(required=True, index=True)
    label = fields.Char(required=True)
    attribute_id = fields.Many2one('product.attribute', required=True, ondelete='restrict')
    owns_attribute = fields.Boolean(default=False)
    _sql_constraints = [('woo_attribute_unique', 'unique(connector_id,woo_key)', 'Woo attribute is already mapped.')]

    @api.model
    def _get_or_create(self, connector, key, label):
        key = clean_text(key, 190)
        label = clean_text(label or key, 256) or key
        if not key:
            raise UserError(_('A WooCommerce variation attribute has no key.'))
        connector._lock('attribute:' + key)
        record = self.search([('connector_id', '=', connector.id), ('woo_key', '=', key)], limit=1)
        if record:
            if record.label != label:
                record.label = label
                if record.owns_attribute:
                    record.attribute_id.sudo().name = label
            return record
        # Fixed-purpose elevation only for connector-owned catalog attributes.
        native = self.env['product.attribute'].sudo().create({'name': label, 'create_variant': 'dynamic'})
        return self.create({'connector_id': connector.id, 'woo_key': key, 'label': label,
                            'attribute_id': native.id, 'owns_attribute': True})


class AttributeValueMap(models.Model):
    _name = 'mw.attribute.value.map'
    _description = 'WooCommerce attribute value mapping'
    _order = 'id'

    connector_id = fields.Many2one('mw.connector', required=True, ondelete='cascade', index=True)
    company_id = fields.Many2one(related='connector_id.company_id', store=True, index=True)
    attribute_map_id = fields.Many2one('mw.attribute.map', required=True, ondelete='cascade', index=True)
    woo_key = fields.Char(required=True, index=True)
    label = fields.Char(required=True)
    value_id = fields.Many2one('product.attribute.value', required=True, ondelete='restrict')
    owns_value = fields.Boolean(default=False)
    _sql_constraints = [('woo_attribute_value_unique', 'unique(attribute_map_id,woo_key)', 'Woo attribute value is already mapped.')]

    @api.model
    def _get_or_create(self, connector, attribute_map, key, label):
        key = clean_text(key, 190)
        label = clean_text(label or key, 256) or key
        if not key:
            raise UserError(_('A WooCommerce variation value is empty.'))
        connector._lock('attribute-value:%s:%s' % (attribute_map.id, key))
        record = self.search([('attribute_map_id', '=', attribute_map.id), ('woo_key', '=', key)], limit=1)
        if record:
            if record.label != label:
                record.label = label
                if record.owns_value:
                    record.value_id.sudo().name = label
            return record
        native = self.env['product.attribute.value'].sudo().create({
            'name': label,
            'attribute_id': attribute_map.attribute_id.id,
        })
        return self.create({'connector_id': connector.id, 'attribute_map_id': attribute_map.id,
                            'woo_key': key, 'label': label, 'value_id': native.id, 'owns_value': True})


class Catalog(models.Model):
    _name = 'mw.catalog'
    _description = 'WooCommerce catalog record'
    _rec_name = 'name'
    _order = 'id desc'

    connector_id = fields.Many2one('mw.connector', required=True, ondelete='restrict', index=True)
    company_id = fields.Many2one(related='connector_id.company_id', store=True, index=True)
    woo_id = fields.Char(required=True, index=True)
    parent_woo_id = fields.Char(index=True)
    name = fields.Char(required=True)
    sku = fields.Char(index=True)
    product_type = fields.Char()
    template_id = fields.Many2one('product.template', ondelete='restrict', index=True)
    product_id = fields.Many2one('product.product', ondelete='restrict', index=True)
    owns_template = fields.Boolean(default=False)
    owns_product = fields.Boolean(default=False)
    version = fields.Integer(default=0)
    fingerprint = fields.Char()
    snapshot = fields.Json(readonly=True)
    snapshot_text = fields.Text(compute='_snapshot_text')
    sync_state = fields.Selection([('done', 'Synchronized'), ('review', 'Needs review')], default='done', index=True)
    last_error = fields.Text(readonly=True)
    image_1024 = fields.Image(max_width=1024, max_height=1024)
    website_price = fields.Float(digits='Product Price')
    regular_price = fields.Float(digits='Product Price')
    sale_price = fields.Float(digits='Product Price')
    currency_code = fields.Char()
    attributes_text = fields.Text()
    pricelist_item_id = fields.Many2one('product.pricelist.item', ondelete='set null')
    _sql_constraints = [
        ('woo_product_unique', 'unique(connector_id,woo_id)', 'Woo product already mapped.'),
        ('native_product_unique', 'unique(connector_id,product_id)', 'An Odoo variant may map to only one Woo stock leaf per connection.'),
    ]

    def _snapshot_text(self):
        for r in self:
            r.snapshot_text = json.dumps(r.snapshot or {}, ensure_ascii=False, indent=2)

    @api.model
    def _ingest(self, connector, d, version):
        wid = str(integer(d.get('id')))
        connector._lock('product:' + wid)
        r = self.search([('connector_id', '=', connector.id), ('woo_id', '=', wid)], limit=1)
        incoming_hash = digest(d)
        if r and (version < r.version or (version == 0 and r.version >= 0)):
            return r
        if r and version == r.version and incoming_hash != r.fingerprint:
            raise ValidationError(_('The same product revision has different content. Resave the product in WooCommerce.'))
        if r and version == r.version and r.sync_state == 'done':
            return r
        attrs = []
        for a in d.get('attributes', []):
            if not isinstance(a, dict):
                continue
            label = clean_text(a.get('label') or a.get('key') or '', 120)
            if 'value_label' in a:
                value = clean_text(a.get('value_label'), 180)
            else:
                value = ', '.join(clean_text(x.get('label'), 80) for x in a.get('options', []) if isinstance(x, dict))
            if label:
                attrs.append('%s: %s' % (label, value))
        values = {
            'connector_id': connector.id,
            'woo_id': wid,
            'parent_woo_id': str(d.get('parent_id') or ''),
            'name': clean_text(d.get('name') or ('Woo product ' + wid), 512),
            'sku': clean_text(d.get('sku'), 190),
            'product_type': clean_text(d.get('type'), 40),
            'snapshot': d,
            'version': version,
            'fingerprint': incoming_hash,
            'website_price': float(number(d.get('price'))),
            'regular_price': float(number(d.get('regular_price'))),
            'sale_price': float(number(d.get('sale_price'))),
            'currency_code': clean_text(d.get('currency'), 8),
            'attributes_text': '\n'.join(attrs),
        }
        if r:
            r.write(values)
        else:
            r = self.create(values)
        try:
            with self.env.cr.savepoint():
                r._apply_catalog()
            r.write({'sync_state': 'done', 'last_error': False})
        except (UserError, ValidationError, ValueError) as exc:
            r.write({'sync_state': 'review', 'last_error': str(exc)[:1000]})
        return r

    def _load_image(self):
        self.ensure_one()
        images = (self.snapshot or {}).get('images') or []
        if not images or not isinstance(images[0], dict) or not images[0].get('content_b64'):
            return
        encoded = images[0]['content_b64']
        if len(encoded) > 720000:
            raise UserError(_('Featured image exceeds the allowed size.'))
        content = base64.b64decode(encoded, validate=True)
        with Image.open(io.BytesIO(content)) as image:
            if image.width * image.height > 16000000 or image.format not in ('JPEG', 'PNG', 'WEBP'):
                raise UserError(_('Unsupported or oversized image dimensions.'))
            image.verify()
        self.image_1024 = encoded

    def _template_values(self):
        self.ensure_one()
        d = self.snapshot or {}
        vals = {
            'name': clean_text(self.name, 512),
            'type': 'service' if d.get('virtual') else 'consu',
            'is_storable': not bool(d.get('virtual')),
            'company_id': self.company_id.id,
            'sale_ok': d.get('status') == 'publish' and not d.get('deleted', False),
            'purchase_ok': not bool(d.get('virtual')),
            'description_sale': str(d.get('short_description') or d.get('description') or ''),
            'description': str(d.get('description') or ''),
        }
        category = self.env['mw.category']._from_woo(self.connector_id, d.get('categories') or [])
        if category:
            vals['categ_id'] = category.id
        if self.image_1024:
            vals['image_1920'] = self.image_1024
        return vals

    def _ensure_parent_template(self):
        self.ensure_one()
        if self.product_type != 'variable':
            return self.template_id
        tmpl = self.template_id
        if not tmpl:
            tmpl = self.env['product.template'].create(self._template_values())
            self.write({'template_id': tmpl.id, 'owns_template': True, 'product_id': False})
        else:
            if tmpl.company_id and tmpl.company_id != self.company_id:
                raise UserError(_('Mapped product template belongs to a different company.'))
            if not tmpl.company_id:
                self._ensure_parent_attributes(tmpl)
                return tmpl
            tmpl.write(self._template_values())
        self._ensure_parent_attributes(tmpl)
        return tmpl

    def _ensure_parent_attributes(self, tmpl):
        self.ensure_one()
        d = self.snapshot or {}
        AttrMap = self.env['mw.attribute.map']
        ValueMap = self.env['mw.attribute.value.map']
        Line = self.env['product.template.attribute.line'].sudo()
        for a in d.get('attributes', []):
            if not isinstance(a, dict) or not a.get('variation'):
                continue
            key = clean_text(a.get('key'), 190)
            amap = AttrMap._get_or_create(self.connector_id, key, a.get('label') or key)
            values = self.env['product.attribute.value']
            for option in a.get('options', []):
                if not isinstance(option, dict):
                    continue
                vmap = ValueMap._get_or_create(self.connector_id, amap, option.get('key'), option.get('label'))
                values |= vmap.value_id
            if not values:
                continue
            line = tmpl.attribute_line_ids.filtered(lambda l: l.attribute_id == amap.attribute_id)[:1]
            if line:
                merged = line.value_ids | values
                if set(merged.ids) != set(line.value_ids.ids):
                    line.sudo().write({'value_ids': [Command.set(merged.ids)]})
            else:
                Line.create({'product_tmpl_id': tmpl.id, 'attribute_id': amap.attribute_id.id,
                             'value_ids': [Command.set(values.ids)]})

    def _variation_combination(self, tmpl):
        self.ensure_one()
        attrs = [a for a in (self.snapshot or {}).get('attributes', []) if isinstance(a, dict) and a.get('variation')]
        selected = {}
        for a in attrs:
            key = clean_text(a.get('key'), 190)
            value_key = clean_text(a.get('value_key'), 190)
            if not key or not value_key:
                raise UserError(_('Woo variation %s uses an "Any"/empty attribute. One Woo SKU cannot be mapped safely to a single Odoo variant.') % self.woo_id)
            selected[key] = a
        parent_lines = tmpl.valid_product_template_attribute_line_ids.filtered(lambda l: l.attribute_id.create_variant != 'no_variant')
        if len(selected) != len(parent_lines):
            raise UserError(_('Woo variation %s does not define every variant-generating parent attribute.') % self.woo_id)
        combination = self.env['product.template.attribute.value']
        for line in parent_lines:
            amap = self.env['mw.attribute.map'].search([
                ('connector_id', '=', self.connector_id.id), ('attribute_id', '=', line.attribute_id.id)
            ], limit=1)
            if not amap or amap.woo_key not in selected:
                raise UserError(_('Parent/variation attribute mapping is incomplete for Woo variation %s.') % self.woo_id)
            a = selected[amap.woo_key]
            vmap = self.env['mw.attribute.value.map']._get_or_create(
                self.connector_id, amap, a.get('value_key'), a.get('value_label') or a.get('value_key'))
            if vmap.value_id not in line.value_ids:
                line.sudo().write({'value_ids': [Command.set((line.value_ids | vmap.value_id).ids)]})
            ptav = line.product_template_value_ids.filtered(
                lambda x: x.product_attribute_value_id == vmap.value_id and x.ptav_active)[:1]
            if not ptav:
                raise UserError(_('Odoo did not create the expected template attribute value for Woo variation %s.') % self.woo_id)
            combination |= ptav
        return combination

    def _legacy_product_has_business_usage(self, product):
        if not product:
            return False
        quant = self.env['stock.quant'].sudo().search_count([
            ('product_id', '=', product.id), '|', ('quantity', '!=', 0), ('reserved_quantity', '!=', 0)
        ], limit=1)
        if quant:
            return True
        if self.env['stock.move'].sudo().search_count([('product_id', '=', product.id)], limit=1):
            return True
        if self.env['sale.order.line'].sudo().search_count([('product_id', '=', product.id)], limit=1):
            return True
        return False

    def _retire_legacy_owned_product(self, old_product):
        self.ensure_one()
        if not old_product or old_product.product_tmpl_id == self.template_id:
            return
        if not self.owns_product:
            raise UserError(_('SKU %s is mapped to an existing Odoo product outside the Woo parent template. Review it manually before regrouping.') % self.sku)
        if self._legacy_product_has_business_usage(old_product):
            raise UserError(_('The old connector-created standalone product for SKU %s already has stock/moves/orders. It was not auto-regrouped; migrate it manually to preserve history.') % self.sku)
        if self.pricelist_item_id:
            self.pricelist_item_id.unlink()
            self.pricelist_item_id = False
        old_product.with_context(active_test=False).write({
            'default_code': 'MW-LEGACY-%s' % self.woo_id,
            'barcode': False,
            'sale_ok': False,
            'active': False,
        })
        self.product_id = False

    def _apply_variable_parent(self):
        self.ensure_one()
        self._ensure_parent_template()
        return

    def _apply_variation(self):
        self.ensure_one()
        if not self.parent_woo_id:
            raise UserError(_('Woo variation has no parent product ID.'))
        parent = self.search([('connector_id', '=', self.connector_id.id), ('woo_id', '=', self.parent_woo_id)],
                             limit=1)
        if not parent or parent.product_type != 'variable':
            raise UserError(_('Backfill/synchronize the Woo variable parent before this variation.'))

        self.connector_id._lock('sku:' + self.sku)
        Product = self.env['product.product'].with_context(active_test=False)
        existing = Product.search([
            ('default_code', '=', self.sku), '|', ('company_id', '=', False), ('company_id', '=', self.company_id.id)
        ], limit=2)
        if len(existing) > 1:
            raise UserError(_('Duplicate Odoo Internal References for SKU %s. Resolve manually.') % self.sku)

        if existing:
            desired = existing
            self.template_id = desired.product_tmpl_id
        else:
            parent._load_image()
            tmpl = parent._ensure_parent_template()
            self.template_id = tmpl
            combination = self._variation_combination(tmpl)
            desired = tmpl._create_product_variant(combination, log_warning=True)
            if not desired:
                raise UserError(
                    _('Odoo could not create the requested dynamic variant. Review the parent attribute configuration.'))

        other = self.search(
            [('connector_id', '=', self.connector_id.id), ('product_id', '=', desired.id), ('id', '!=', self.id)],
            limit=1)
        if other:
            raise UserError(_('This Odoo variant is already mapped to another WooCommerce variation.'))

        self.write({'product_id': desired.id, 'template_id': self.template_id.id, 'owns_product': not bool(existing)})
        if not desired.company_id:
            self.env['mw.stock.outbox']._touch_products(desired)
            return
        vals = {'default_code': self.sku}
        gtin = clean_text((self.snapshot or {}).get('global_unique_id'), 128)
        if gtin:
            vals['barcode'] = gtin
        if (self.snapshot or {}).get('weight_kg') is not None:
            vals['weight'] = float(number(self.snapshot['weight_kg'], nonnegative=True))
        if self.image_1024:
            vals['image_variant_1920'] = self.image_1024
        vals['active'] = not bool((self.snapshot or {}).get('deleted'))
        desired.write(vals)
        self._apply_price(desired)
        self.env['mw.stock.outbox']._touch_products(desired)


    def _apply_simple(self):
        self.ensure_one()
        d = self.snapshot or {}
        c = self.connector_id
        c._lock('sku:' + self.sku)
        Product = self.env['product.product'].with_context(active_test=False)
        p = self.product_id
        if not p:
            matches = Product.search([('default_code', '=', self.sku), '|', ('company_id', '=', False), ('company_id', '=', c.company_id.id)], limit=2)
            if len(matches) > 1:
                raise UserError(_('Duplicate Odoo Internal References. Resolve the SKU mapping.'))
            if matches:
                p = matches
            else:
                p = Product.create({'name': self.name, 'default_code': self.sku,
                                    'type': 'service' if d.get('virtual') else 'consu',
                                    'is_storable': not bool(d.get('virtual')), 'company_id': c.company_id.id,
                                    'sale_ok': True, 'purchase_ok': not bool(d.get('virtual'))})
                self.owns_product = True
            other = self.search([('connector_id', '=', c.id), ('product_id', '=', p.id), ('id', '!=', self.id)], limit=1)
            if other:
                raise UserError(_('This Odoo product is already mapped to another WooCommerce SKU record.'))
            self.product_id = p
        if p.company_id and p.company_id != c.company_id:
            raise UserError(_('Mapped product belongs to a different company.'))
        self.template_id = p.product_tmpl_id
        if not p.company_id:
            if not d.get('virtual') and not p.is_storable:
                raise UserError(_('Existing mapped goods must have inventory tracking enabled in Odoo.'))
            self.env['mw.stock.outbox']._touch_products(p)
            return
        vals = {'default_code': self.sku, 'name': clean_text(self.name, 512),
                'description_sale': str(d.get('short_description') or d.get('description') or ''),
                'description': str(d.get('description') or ''),
                'sale_ok': d.get('status') == 'publish' and not d.get('deleted', False)}
        gtin = clean_text(d.get('global_unique_id'), 128)
        if gtin:
            vals['barcode'] = gtin
        if d.get('weight_kg') is not None:
            vals['weight'] = float(number(d['weight_kg'], nonnegative=True))
        if self.image_1024:
            vals['image_1920'] = self.image_1024
        category = self.env['mw.category']._from_woo(c, d.get('categories') or [])
        if category:
            vals['categ_id'] = category.id
        p.write(vals)
        if not d.get('virtual') and not p.is_storable:
            raise UserError(_('Existing mapped goods must have inventory tracking enabled in Odoo.'))
        self._apply_price(p)
        self.env['mw.stock.outbox']._touch_products(p)

    def _apply_price(self, product):
        self.ensure_one()
        d = self.snapshot or {}
        pricelist = self.connector_id._pricelist(d.get('currency'))
        price = float(number(d.get('price_ex_tax'), nonnegative=True))
        item_values = {'pricelist_id': pricelist.id, 'applied_on': '0_product_variant', 'product_id': product.id,
                       'compute_price': 'fixed', 'fixed_price': price, 'min_quantity': 0}
        if self.pricelist_item_id:
            self.pricelist_item_id.write(item_values)
        else:
            self.pricelist_item_id = self.env['product.pricelist.item'].create(item_values)
        if product.product_tmpl_id.product_variant_count == 1 and pricelist.currency_id == self.connector_id.company_id.currency_id and product.company_id:
            product.list_price = price

    def _apply_catalog(self):
        self.ensure_one()
        self._load_image()
        if self.product_type == 'variable':
            return self._apply_variable_parent()
        if self.product_type == 'grouped':
            return  # Grouped relation is retained as a source snapshot; no stock leaf is created.
        if self.product_type == 'variation':
            if not self.sku:
                raise UserError(_('A sellable Woo variation needs a unique SKU.'))
            return self._apply_variation()
        if self.product_type == 'simple':
            if not self.sku:
                raise UserError(_('A sellable Woo product needs a unique SKU.'))
            return self._apply_simple()
        raise UserError(_('Product type needs a dedicated mapping; Woo data is retained.'))

    def action_retry(self):
        if not self.env.user.has_group('woo_commerce_connector.group_manager'):
            raise UserError(_('Connector Manager rights are required.'))
        for r in self:
            with self.env.cr.savepoint():
                r._apply_catalog()
                r.write({'sync_state': 'done', 'last_error': False})
        return True


class Category(models.Model):
    _name = 'mw.category'
    _description = 'WooCommerce category mapping'
    connector_id = fields.Many2one('mw.connector', required=True, ondelete='cascade')
    company_id = fields.Many2one(related='connector_id.company_id', store=True)
    woo_id = fields.Char(required=True)
    category_id = fields.Many2one('product.category', required=True, ondelete='restrict')
    _sql_constraints = [('woo_category_unique', 'unique(connector_id,woo_id)', 'Category already mapped.')]

    @api.model
    def _from_woo(self, connector, categories):
        first = self.env['product.category']
        for cat in categories:
            if not isinstance(cat, dict):
                continue
            parent = self.env['product.category']
            for part in cat.get('path', []):
                if not isinstance(part, dict):
                    continue
                key = str(integer(part.get('id')))
                connector._lock('category:' + key)
                mapped = self.search([('connector_id', '=', connector.id), ('woo_id', '=', key)], limit=1)
                if not mapped:
                    native = self.env['product.category'].create({'name': clean_text(part.get('name') or key, 256), 'parent_id': parent.id or False})
                    mapped = self.create({'connector_id': connector.id, 'woo_id': key, 'category_id': native.id})
                parent = mapped.category_id
            if not first:
                first = parent
        return first
