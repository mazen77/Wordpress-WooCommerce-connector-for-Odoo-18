from odoo import models, fields, api, _
from odoo.exceptions import UserError
import logging
import json

_logger = logging.getLogger(__name__)

class WooExchange(models.Model):
    _name = 'mw.exchange'
    _description = 'WooCommerce Exchange Request'

    name = fields.Char(string="Exchange Name", compute="_compute_name")
    connector_id = fields.Many2one('mw.connector', string='Connector', required=True, ondelete='cascade')
    company_id = fields.Many2one('res.company', related='connector_id.company_id', store=True)
    woo_order_id = fields.Char(string="WooCommerce Order ID", required=True)
    exchange_status = fields.Char(string="Exchange Status")
    reason = fields.Text(string="Reason")
    snapshot = fields.Json(string="Snapshot")
    original_sale_order_id = fields.Many2one('sale.order', string="Original Sales Order", compute="_compute_sale_order", store=True)
    new_sale_order_id = fields.Many2one('sale.order', string="New SO", readonly=True, copy=False)
    return_picking_id = fields.Many2one('stock.picking', string="Return Picking (for FROM items)", readonly=True)
    credit_note_id = fields.Many2one('account.move', string="Credit Note (for FROM items)", readonly=True)
    woo_exchange_id = fields.Char(string="WooCommerce Exchange ID", index=True)
    from_items_json = fields.Text(string="From Items (JSON)")
    to_items_json = fields.Text(string="To Items (JSON)")
    sync_state = fields.Selection([
        ('pending', 'Pending'),
        ('done', 'Synchronized'),
        ('review', 'Needs Review'),
        ('error', 'Error')
    ], string="Sync State", default='pending', readonly=True, copy=False)


    @api.depends('woo_order_id', 'reason')
    def _compute_name(self):
        for rec in self:
            rec.name = f"EXCHANGE-{rec.woo_order_id or 'NEW'}"

    @api.depends('woo_order_id', 'connector_id')
    def _compute_sale_order(self):
        for rec in self:
            if rec.woo_order_id and rec.connector_id:
                mw_order = self.env['mw.order'].search([
                    ('woo_id', '=', rec.woo_order_id),
                    ('connector_id', '=', rec.connector_id.id)
                ], limit=1)
                rec.original_sale_order_id = mw_order.sale_order_id.id if mw_order else False
            else:
                rec.original_sale_order_id = False

    @classmethod
    def _from_webhook(cls, connector, snapshot):
        woo_order_id = snapshot.get('order_id')
        if not woo_order_id:
            _logger.warning("Received exchange webhook with no 'order_id'. Skipping.")
            return
        vals = {
            'connector_id': connector.id,
            'woo_order_id': str(woo_order_id),
            'exchange_status': snapshot.get('exchange_status'),
            'reason': snapshot.get('reason'),
            'snapshot': snapshot,
        }
        exchange = cls.create(vals)
        _logger.info("Created new exchange record %s for Woo Order ID %s", exchange.name, woo_order_id)
        return exchange

    @api.model
    def _ingest(self, connector, data, version):
        exchange_id = data.get('id')
        if not exchange_id:
            _logger.warning("Received exchange webhook with no 'id'. Skipping.")
            return
        exchange = self.search([('connector_id', '=', connector.id), ('woo_exchange_id', '=', str(exchange_id))], limit=1)
        vals = {
            'connector_id': connector.id,
            'woo_exchange_id': str(exchange_id),
            'woo_order_id': str(data.get('order_id')),
            'exchange_status': data.get('exchange_status'),
            'reason': data.get('reason'),
            'from_items_json': json.dumps(data.get('from', [])),
            'to_items_json': json.dumps(data.get('to', [])),
            'snapshot': data,
        }
        if exchange:
            exchange.write(vals)
            _logger.info("Updated exchange record %s", exchange.name)
        else:
            exchange = self.create(vals)
            _logger.info("Created new exchange record %s", exchange.name)
        exchange._apply_native()
        return exchange

    def _apply_native(self):
        self.ensure_one()
        _logger.info("Processing exchange %s...", self.name)
        if self.exchange_status != 'approved':
            _logger.info("Exchange status is '%s'. No action will be taken.", self.exchange_status)
            return
        order = self.original_sale_order_id
        if not order:
            raise UserError(_("Could not find the original sales order with Woo ID %s.", self.woo_order_id))
        _logger.info("Processing 'FROM' items for exchange %s.", self.name)
        from_items = self.snapshot.get('from', [])
        if not from_items:
            _logger.warning("Exchange %s has no 'FROM' items to process.", self.name)
            return
        lines_to_return = self.env['sale.order.line']
        for item in from_items:
            line = order.order_line.filtered(lambda l: l.woo_line_item_id == str(item.get('item_id')))
            if not line:
                raise UserError(_("Could not find original order line with Woo Line ID %s.", item.get('item_id')))
            lines_to_return |= line
        posted_invoices = order.invoice_ids.filtered(lambda inv: inv.state == 'posted' and inv.move_type == 'out_invoice')
        if not posted_invoices:
            _logger.warning("Exchange %s: No posted invoice found for order %s. Cannot create credit note.", self.name, order.name)
        else:
            invoice_to_refund = posted_invoices[0]
            reversal_wizard = self.env['account.move.reversal'].with_context(
                active_model="account.move", active_ids=invoice_to_refund.ids
            ).create({
                'reason': _('Partial refund for exchange on order %s', order.name),
                'journal_id': invoice_to_refund.journal_id.id,
            })
            reversal_action = reversal_wizard.reverse_moves(is_modify=True)
            if reversal_action and reversal_action.get('res_id'):
                draft_credit_note = self.env['account.move'].browse(reversal_action['res_id'])
                lines_to_keep = draft_credit_note.invoice_line_ids.filtered(lambda l: l.sale_line_ids in lines_to_return)
                lines_to_remove = draft_credit_note.invoice_line_ids - lines_to_keep
                lines_to_remove.unlink()
                draft_credit_note.action_post()
                self.credit_note_id = draft_credit_note.id
                _logger.info("Created and posted credit note %s for exchange %s.", draft_credit_note.name, self.name)
        done_pickings = order.picking_ids.filtered(lambda p: p.state == 'done')
        if not done_pickings:
            _logger.warning("Exchange %s: No 'Done' picking found for order %s. Cannot create return.", self.name, order.name)
        else:
            picking_to_return = done_pickings[0]
            moves_to_return = picking_to_return.move_ids.filtered(lambda m: m.sale_line_id in lines_to_return)
            return_wizard = self.env['stock.return.picking'].with_context(active_id=picking_to_return.id, active_model='stock.picking').create({})
            for move in moves_to_return:
                self.env['stock.return.picking.line'].create({
                    'product_id': move.product_id.id,
                    'quantity': move.quantity,
                    'wizard_id': return_wizard.id,
                    'move_id': move.id,
                })
            return_action = return_wizard.action_create_returns()
            if return_action and return_action.get('res_id'):
                return_picking = self.env['stock.picking'].browse(return_action['res_id'])
                self.return_picking_id = return_picking.id
                _logger.info("Created return picking %s for exchange %s.", return_picking.name, self.name)
        _logger.info("Processing 'TO' items for exchange %s.", self.name)
        if self.new_sale_order_id:
            _logger.info("Exchange %s: New sales order %s already exists. Skipping creation.", self.name,
                         self.new_sale_order_id.name)
            return True
        to_items = self.snapshot.get('to', [])
        if not to_items:
            _logger.info("Exchange %s: No 'TO' items found. Nothing to create.", self.name)
            return True
        _logger.info("Exchange %s: Creating new sales order for %d 'TO' items.", self.name, len(to_items))
        original_order = self.original_sale_order_id
        order_lines = []
        ProductProduct = self.env['product.product']
        for item in to_items:
            sku = item.get('sku')
            quantity = item.get('qty')
            if not sku or not quantity:
                _logger.warning("Exchange %s: Skipping TO item with missing SKU or quantity: %s", self.name, item)
                continue
            product = ProductProduct.search([('default_code', '=', sku)], limit=1)
            if not product:
                raise UserError(_("Could not find Odoo product with SKU '%s' for the new exchange order.", sku))
            order_lines.append((0, 0, {
                'product_id': product.id,
                'product_uom_qty': quantity,
            }))
        if not order_lines:
            _logger.error("Exchange %s: Could not resolve any 'TO' items to Odoo products. No order created.",
                          self.name)
            return True
        new_order_vals = {
            'partner_id': original_order.partner_id.id,
            'partner_invoice_id': original_order.partner_invoice_id.id,
            'partner_shipping_id': original_order.partner_shipping_id.id,
            'order_line': order_lines,
            'origin': f"Exchange for {original_order.name} (Ref: {self.name})",
            'team_id': original_order.team_id.id,
            'company_id': original_order.company_id.id,
        }
        new_order = self.env['sale.order'].create(new_order_vals)
        _logger.info("Exchange %s: Created new Sales Order %s.", self.name, new_order.name)
        new_order.action_confirm()
        _logger.info("Exchange %s: Confirmed new Sales Order %s.", self.name, new_order.name)
        self.write({'new_sale_order_id': new_order.id})
        return True