import json
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
from ..protocol import digest, integer


class Customer(models.Model):
    _name = 'mw.customer'
    _description = 'WooCommerce customer and delivery details'
    _rec_name = 'name'
    connector_id = fields.Many2one('mw.connector', required=True, ondelete='restrict', index=True)
    company_id = fields.Many2one(related='connector_id.company_id', store=True, index=True)
    woo_id = fields.Char(required=True, index=True)
    name = fields.Char(required=True)
    partner_id = fields.Many2one('res.partner', required=True, ondelete='restrict')
    billing_partner_id = fields.Many2one('res.partner', ondelete='restrict')
    shipping_partner_id = fields.Many2one('res.partner', ondelete='restrict')
    version = fields.Integer(default=0)
    fingerprint = fields.Char()
    snapshot = fields.Json(readonly=True)
    snapshot_text = fields.Text(compute='_snapshot_text')
    sync_state = fields.Selection([('done', 'Synchronized'), ('review', 'Needs review')], default='done')
    _sql_constraints = [('woo_customer_unique', 'unique(connector_id,woo_id)', 'Customer already mapped.')]

    def _snapshot_text(self):
        for r in self:
            r.snapshot_text = json.dumps(r.snapshot or {}, ensure_ascii=False, indent=2)

    @api.model
    def _address_values(self, data):
        country = self.env['res.country'].search([('code', '=', str(data.get('country') or '').upper())], limit=1)
        state = self.env['res.country.state'].search([('country_id', '=', country.id), ('code', '=', str(data.get('state') or ''))], limit=1) if country else self.env['res.country.state']
        name = ('%s %s' % (data.get('first_name') or '', data.get('last_name') or '')).strip()
        return {'name': name or data.get('company') or _('WooCommerce customer'),
                'email': data.get('email') or False,
                'phone': data.get('phone') or False,
                'street': data.get('address_1') or False,
                'street2': data.get('address_2') or False,
                'city': data.get('city') or False,
                'zip': data.get('postcode') or False,
                'country_id': country.id or False,
                'state_id': state.id or False}

    @api.model
    def _ingest(self, connector, d, version):
        key = str(integer(d.get('id')))
        return self._upsert(connector, key, d, version)

    @api.model
    def _upsert(self, connector, key, d, version, from_order=False):
        connector._lock('customer:' + key)
        r = self.search([('connector_id', '=', connector.id), ('woo_id', '=', key)], limit=1)
        if r and (from_order or version < r.version):
            return r
        h = digest(d)
        if r and version == r.version and r.fingerprint != h:
            raise ValidationError(_('Customer revision collision. Resave the customer in WooCommerce.'))
        if r and version == r.version and r.sync_state == 'done':
            return r
        billing = d.get('billing') or {}
        shipping = d.get('shipping') or {}
        values = self._address_values(billing)
        values['name'] = (str(d.get('first_name') or '') + ' ' + str(d.get('last_name') or '')).strip() or d.get('display_name') or values['name']
        values['email'] = d.get('email') or billing.get('email') or False
        values['company_id'] = connector.company_id.id
        values['customer_rank'] = 1
        if not r:
            partner = self.env['res.partner'].create(values)
            r = self.create({'connector_id': connector.id, 'woo_id': key, 'name': values['name'], 'partner_id': partner.id})
        else:
            r.partner_id.write(values)
        for data, role, field in [(billing, 'invoice', 'billing_partner_id'), (shipping, 'delivery', 'shipping_partner_id')]:
            if not data:
                continue
            child_vals = self._address_values(data)
            child_vals.update({'parent_id': r.partner_id.id, 'type': role, 'company_id': connector.company_id.id})
            child = r[field]
            if child:
                child.write(child_vals)
            else:
                r[field] = self.env['res.partner'].create(child_vals)
        r.write({'name': values['name'], 'version': version, 'fingerprint': h, 'snapshot': d, 'sync_state': 'done'})
        return r

    @api.model
    def _from_order(self, connector, order):
        customer_id = int(order.get('customer_id') or 0)
        key = str(customer_id) if customer_id else 'guest:' + str(order['id'])
        d = {'id': customer_id, 'email': (order.get('billing') or {}).get('email'),
             'billing': order.get('billing') or {}, 'shipping': order.get('shipping') or {},
             'metadata': order.get('metadata') or []}
        return self._upsert(connector, key, d, 0, from_order=True)

    def _order_address(self, order_id, data, role):
        """Immutable per-order address snapshot; never rewrite previously invoiced addresses."""
        self.ensure_one()
        key = '%s:%s:%s:%s' % (self.connector_id.id, order_id, role, digest(data))
        existing = self.env['res.partner'].search([('mw_address_key', '=', key)], limit=1)
        if existing:
            return existing
        vals = self._address_values(data)
        vals.update({'parent_id': self.partner_id.id, 'type': role, 'company_id': self.company_id.id, 'mw_address_key': key})
        return self.env['res.partner'].create(vals)


class Partner(models.Model):
    _inherit = 'res.partner'
    mw_address_key = fields.Char(index=True, copy=False, groups='woo_commerce_connector.group_service')
    _sql_constraints = [('mw_address_key_unique', 'unique(mw_address_key)', 'Woo address snapshot already exists.')]
