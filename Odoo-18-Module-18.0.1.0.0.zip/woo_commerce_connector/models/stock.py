import ipaddress
import json
import socket
import time
from datetime import timedelta
from urllib.parse import urlparse

import requests

from odoo import api, fields, models
from ..protocol import signed, lock_key


class StockOutbox(models.Model):
    _name = 'mw.stock.outbox'
    _description = 'Versioned WooCommerce stock outbox'
    _order = 'id'

    catalog_id = fields.Many2one('mw.catalog', required=True, ondelete='cascade', index=True)
    connector_id = fields.Many2one('mw.connector', required=True, ondelete='cascade', index=True)
    company_id = fields.Many2one('res.company', required=True, index=True)
    product_id = fields.Many2one('product.product', required=True, ondelete='cascade', index=True)
    version = fields.Integer(default=1)
    sent_version = fields.Integer(default=0)
    dirty = fields.Boolean(default=True, index=True)
    attempts = fields.Integer(default=0)
    next_attempt = fields.Datetime(index=True)
    last_error = fields.Char()
    _sql_constraints = [('stock_catalog_unique', 'unique(catalog_id)', 'Stock outbox row already exists.')]

    @api.model
    def _touch_products(self, products, company_ids=None):
        if not products:
            return
        # Internal, fixed-purpose elevation: warehouse users may not have connector ACLs.
        # No network operation and no arbitrary data/model writes.
        Outbox = self.sudo()
        Catalog = self.env['mw.catalog'].sudo()
        Catalog.flush_model(['product_id', 'connector_id', 'company_id'])
        domain = [('product_id', 'in', products.ids), ('connector_id.enabled', '=', True),
                  ('sync_state', '=', 'done'), ('product_id.is_storable', '=', True)]
        if company_ids:
            domain.append(('company_id', 'in', list(set(int(cid) for cid in company_ids if cid))))
        maps = Catalog.search(domain)
        if not maps:
            return
        now = fields.Datetime.now()
        vals = [(m.id, m.connector_id.id, m.company_id.id, m.product_id.id, 1, True, 0,
                 self.env.uid, self.env.uid, now, now) for m in maps]
        placeholders = ','.join(['(' + ','.join(['%s'] * 11) + ')'] * len(vals))
        self.env.cr.execute('''
            INSERT INTO mw_stock_outbox (catalog_id,connector_id,company_id,product_id,version,dirty,attempts,create_uid,write_uid,create_date,write_date)
            VALUES ''' + placeholders + '''
            ON CONFLICT (catalog_id) DO UPDATE SET product_id=EXCLUDED.product_id,connector_id=EXCLUDED.connector_id,company_id=EXCLUDED.company_id,
            version=mw_stock_outbox.version+1,dirty=TRUE,attempts=0,next_attempt=NULL,last_error=NULL,write_date=EXCLUDED.write_date
        ''', [value for row in vals for value in row])
        Outbox.invalidate_model(['version', 'dirty', 'attempts', 'next_attempt', 'last_error'])

    @api.model
    def _post(self, connector, payload):
        url = connector.stock_url
        u = urlparse(url)
        if u.scheme != 'https' or not u.hostname or u.username or u.password or u.query or u.fragment or u.port not in (None, 443):
            raise ValueError('unsafe_stock_endpoint')
        addresses = socket.getaddrinfo(u.hostname, 443, type=socket.SOCK_STREAM)
        if not addresses or any(not ipaddress.ip_address(a[4][0]).is_global for a in addresses):
            raise ValueError('non_public_stock_endpoint')
        raw = json.dumps(payload, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
        ts = str(int(time.time()))
        headers = {'Content-Type': 'application/json; charset=utf-8', 'X-MW-Store': connector.store_key,
                   'X-MW-Timestamp': ts, 'X-MW-Signature': signed(raw, ts, connector.sudo().outgoing_secret)}
        timeout = max(3, min(15, connector.network_timeout))
        with requests.Session() as session:
            session.trust_env = False
            with session.post(url, data=raw, headers=headers, timeout=(3, timeout), allow_redirects=False, stream=True) as response:
                if response.status_code != 200:
                    raise ValueError('woocommerce_http_%s' % response.status_code)
                chunks = []; size = 0
                for block in response.iter_content(8192):
                    size += len(block)
                    if size > 262144:
                        raise ValueError('oversized_woocommerce_reply')
                    chunks.append(block)
                body = json.loads(b''.join(chunks).decode('utf-8'))
        if not isinstance(body, dict) or body.get('ok') is not True:
            raise ValueError('invalid_woocommerce_acknowledgement')
        return body

    @api.model
    def _try_delivery_lock(self, connector):
        """Prevent overlapping Woo stock POSTs for the same connector without blocking a worker."""
        self.env.cr.execute(
            'SELECT pg_try_advisory_xact_lock(%s)',
            [lock_key('%s:%s' % (connector.id, 'stock_delivery'))],
        )
        return bool(self.env.cr.fetchone()[0])

    @api.model
    def _cron(self):
        # ir.cron serializes this job. No per-SKU/per-order scheduled tasks.
        started = time.monotonic()
        connectors = self.env['mw.connector'].sudo().search([('enabled', '=', True)], order='id', limit=20)
        for c in connectors:
            if time.monotonic() - started > 35:
                break
            try:
                with self.env.cr.savepoint():
                    worker = self.with_user(c.integration_user_id).with_company(c.company_id).with_context(allowed_company_ids=[c.company_id.id])
                    worker._tick_connector(c.with_env(worker.env))
            except Exception:
                c.sudo().write({'last_error': 'queue_processing_error: check connector user permissions/configuration'})

    @api.model
    def _tick_connector(self, c):
        now = fields.Datetime.now()
        if c.delivery_failures >= 8 or (c.delivery_after and c.delivery_after > now):
            return
        if not self._try_delivery_lock(c):
            # Another cron/manual worker is already posting stock for this connector.
            # Skip instead of stacking HTTP requests against WooCommerce.
            return
        if c.full_stock_cursor >= 0:
            maps = self.env['mw.catalog'].search([('connector_id', '=', c.id), ('id', '>', c.full_stock_cursor),
                                                 ('product_id', '!=', False)], order='id', limit=100)
            self._touch_products(maps.mapped('product_id'), company_ids=[c.company_id.id])
            c.sudo().full_stock_cursor = maps[-1].id if len(maps) == 100 else -1
        request_limit = max(1, min(int(c.batch_size or 50), int(c.stock_request_batch_size or 10)))
        rows = self.browse()
        if c.stock_enabled:
            base_domain = [('connector_id', '=', c.id), ('dirty', '=', True), ('attempts', '<', 8),
                           ('catalog_id.sync_state', '=', 'done')]
            # Fresh dirty rows must not be starved by old deferred/error rows.
            # Process never-deferred work first; only use remaining capacity for due retries.
            fresh_rows = self.search(base_domain + [('next_attempt', '=', False)], order='id', limit=request_limit)
            remaining = request_limit - len(fresh_rows)
            retry_rows = self.browse()
            if remaining > 0:
                retry_rows = self.search(
                    base_domain + [('next_attempt', '!=', False), ('next_attempt', '<=', now)],
                    order='next_attempt,id', limit=remaining,
                )
            rows = fresh_rows | retry_rows
        orders = self.env['mw.order'].search([('connector_id', '=', c.id), ('ack_pending', '=', True), ('sync_state', '=', 'done')], order='id', limit=20)
        if not rows and not orders:
            return
        products = rows.mapped('product_id').with_company(c.company_id).with_context(warehouse_id=c.warehouse_id.id, allowed_company_ids=[c.company_id.id])
        quantities = {p['id']: p['free_qty'] for p in products.read(['free_qty'])}
        items = []; snapshots = {}
        for row in rows:
            version = row.version
            wid = int(row.catalog_id.woo_id)
            qty = max(0.0, round(float(quantities.get(row.product_id.id, 0)) - c.safety_stock, 6))
            items.append({'product_id': wid, 'sku': row.catalog_id.sku, 'quantity': qty, 'version': version})
            snapshots[(wid, version)] = row.id
        ack_snapshots = {(int(r.woo_id), r.version): r.id for r in orders}
        payload = {'schema': 2, 'store': c.store_key, 'items': items, 'order_acks': [r._ack_payload() for r in orders]}
        try:
            result = self._post(c, payload)
        except Exception as exc:
            self._fail_versions(snapshots, str(exc)[:120])
            attempts = c.delivery_failures + 1
            delays = (60, 120, 300, 900, 1800, 3600, 10800, 21600)
            c.sudo().write({'last_error': 'stock_delivery_failed; check endpoint/TLS/authentication; retry after repair',
                            'delivery_failures': attempts, 'delivery_after': now + timedelta(seconds=delays[min(attempts - 1, 7)])})
            return
        received = set()
        for item in result.get('items', []):
            pair = (int(item.get('product_id') or 0), int(item.get('version') or 0))
            row_id = snapshots.get(pair)
            if not row_id or pair in received:
                continue
            received.add(pair)
            if item.get('status') in ('applied', 'stale'):
                self.env.cr.execute('UPDATE mw_stock_outbox SET dirty=FALSE,sent_version=%s,attempts=0,next_attempt=NULL,last_error=NULL WHERE id=%s AND version=%s', [pair[1], row_id, pair[1]])
            elif item.get('status') == 'deferred':
                reason = str(item.get('message') or item.get('code') or 'deferred')[:80]
                labels = {
                    'stock_sync_disabled': 'Woo stock sync is disabled',
                    'waiting_for_order_reservation': 'Waiting for Woo order reservation acknowledgement',
                    'busy': 'Woo product is temporarily busy',
                }
                message = labels.get(reason, 'Woo deferred stock update: %s' % reason)
                if reason == 'waiting_for_order_reservation':
                    retry_seconds = int(c.stock_guard_retry_seconds or 900)
                elif reason == 'stock_sync_disabled':
                    retry_seconds = max(900, int(c.stock_deferred_retry_seconds or 120))
                else:
                    retry_seconds = int(c.stock_deferred_retry_seconds or 120)
                self.env.cr.execute('UPDATE mw_stock_outbox SET next_attempt=%s,last_error=%s WHERE id=%s AND version=%s',
                                    [now + timedelta(seconds=retry_seconds), message, row_id, pair[1]])
            else:
                self._fail_versions({pair: row_id}, 'Woo rejected stock item; check SKU/units/product ownership')
        missing = {pair: rowid for pair, rowid in snapshots.items() if pair not in received}
        if missing:
            self._fail_versions(missing, 'Missing per-product acknowledgement')
        for ack in result.get('acknowledged', []):
            pair = (int(ack.get('order_id') or 0), int(ack.get('source_version') or 0))
            row_id = ack_snapshots.get(pair)
            if row_id:
                self.env.cr.execute('UPDATE mw_order SET ack_pending=FALSE WHERE id=%s AND version=%s', [row_id, pair[1]])
        self.invalidate_model()
        self.env['mw.order'].invalidate_model(['ack_pending'])
        c.sudo().write({'last_success': now, 'last_error': False, 'delivery_failures': 0, 'delivery_after': False})

    @api.model
    def _fail_versions(self, snapshots, message):
        delays = (60, 120, 300, 900, 1800, 3600, 10800, 21600)
        for (_, version), rowid in snapshots.items():
            row = self.browse(rowid)
            attempts = row.attempts + 1
            due = fields.Datetime.now() + timedelta(seconds=delays[min(attempts - 1, 7)])
            # Do not overwrite a newer stock mutation made while the HTTP request was running.
            self.env.cr.execute('UPDATE mw_stock_outbox SET attempts=%s,next_attempt=%s,last_error=%s WHERE id=%s AND version=%s',
                                [attempts, due, message[:150], rowid, version])
        self.invalidate_model(['attempts', 'next_attempt', 'last_error'])


class StockQuant(models.Model):
    _inherit = 'stock.quant'

    @api.model
    def _mw_company_product_pairs(self, quants):
        """Return exact (company, product) pairs represented by these quants."""
        return {(q.company_id.id, q.product_id.id) for q in quants if q.company_id and q.product_id}

    @api.model
    def _mw_touch_company_product_pairs(self, pairs):
        """Dirty connector stock only inside the company whose quant actually changed."""
        if not pairs:
            return
        Product = self.env['product.product']
        by_company = {}
        for company_id, product_id in pairs:
            if company_id and product_id:
                by_company.setdefault(int(company_id), set()).add(int(product_id))
        for company_id, product_ids in by_company.items():
            self.env['mw.stock.outbox']._touch_products(
                Product.browse(sorted(product_ids)), company_ids=[company_id]
            )

    @api.model_create_multi
    def create(self, values):
        records = super().create(values)
        self._mw_touch_company_product_pairs(self._mw_company_product_pairs(records))
        return records

    def write(self, values):
        relevant = bool({'quantity', 'reserved_quantity', 'product_id', 'location_id', 'company_id'} & set(values))
        before = self._mw_company_product_pairs(self) if relevant else set()
        result = super().write(values)
        if relevant:
            after = self._mw_company_product_pairs(self)
            self._mw_touch_company_product_pairs(before | after)
        return result

    def unlink(self):
        pairs = self._mw_company_product_pairs(self)
        result = super().unlink()
        self._mw_touch_company_product_pairs(pairs)
        return result
