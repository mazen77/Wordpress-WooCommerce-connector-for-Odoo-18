import json
import logging
import time

from werkzeug.exceptions import BadRequest, RequestEntityTooLarge

from odoo import http
from odoo.http import request
from odoo.exceptions import AccessError, UserError, ValidationError
from ..protocol import authorized, ProtocolError

_logger = logging.getLogger(__name__)
MAX_BODY_BYTES = 2 * 1024 * 1024


class _BodyError(ValueError):
    def __init__(self, code, status):
        super().__init__(code)
        self.code = code
        self.status = status


def _read_body(httprequest):
    """Read exact signed bytes through Odoo 18's public request wrapper.

    HTTPRequest exposes get_data and max_content_length, but not stream or
    wsgi.input. Require a bounded, fixed-length body before buffering it. The
    WordPress sender uses a fixed JSON body; an intermediary must retain a
    Content-Length rather than forwarding an unbounded/chunked request.
    """
    if httprequest.headers.get('Transfer-Encoding'):
        raise _BodyError('unsupported_transfer_encoding', 400)
    length = httprequest.content_length
    if length is None:
        raise _BodyError('content_length_required', 411)
    if length <= 0:
        raise _BodyError('invalid_payload', 422)
    if length > MAX_BODY_BYTES:
        raise _BodyError('body_too_large', 413)

    # The route also sets this before Odoo parses HTTP parameters. Do not
    # increase a stricter limit set by the deployment or other middleware.
    current_limit = httprequest.max_content_length
    httprequest.max_content_length = (
        min(current_limit, MAX_BODY_BYTES)
        if current_limit is not None else MAX_BODY_BYTES
    )
    try:
        # Cache bytes for Odoo's same-request transaction retry. No form
        # parsing or Unicode conversion before checking the HMAC signature.
        raw = httprequest.get_data(cache=True, as_text=False, parse_form_data=False)
    except RequestEntityTooLarge:
        raise _BodyError('body_too_large', 413) from None
    except BadRequest:
        raise _BodyError('invalid_request_body', 400) from None
    if len(raw) > MAX_BODY_BYTES:
        raise _BodyError('body_too_large', 413)
    if len(raw) != length:
        raise _BodyError('invalid_request_body', 400)
    return raw


class CommerceWebhook(http.Controller):
    @http.route('/mw-sync/v2/event', type='http', auth='public', methods=['POST'],
                csrf=False, save_session=False, max_content_length=MAX_BODY_BYTES)
    def event(self, **kwargs):
        # No db query string selection, no public model name/method, no generic ORM proxy.
        try:
            raw = _read_body(request.httprequest)
        except _BodyError as exc:
            return request.make_json_response({'ok': False, 'error': exc.code}, status=exc.status)
        store = request.httprequest.headers.get('X-MW-Store', '')
        if len(store) > 80:
            return request.make_json_response({'ok': False, 'error': 'unauthorized'}, status=401)
        connector = request.env['mw.connector'].sudo().search([('store_key', '=', store), ('enabled', '=', True)], limit=1)
        try:
            authenticated = bool(connector) and authorized(
                raw, request.httprequest.headers.get('X-MW-Timestamp', ''),
                request.httprequest.headers.get('X-MW-Signature', ''),
                connector.incoming_secret, time.time())
        except (TypeError, ValueError, UnicodeError):
            # Malformed authentication headers must not become a server error.
            authenticated = False
        if not authenticated:
            return request.make_json_response({'ok': False, 'error': 'unauthorized'}, status=401)
        try:
            data = json.loads(raw.decode('utf-8'))
            with request.env.cr.savepoint():
                scoped = connector.with_user(connector.integration_user_id).with_company(
                    connector.company_id).with_context(allowed_company_ids=[connector.company_id.id],
                                                       tracking_disable=True, mail_create_nosubscribe=True,
                                                       mail_notrack=True, mw_connector_id=connector.id)
                result = scoped._dispatch(data)
        except (ProtocolError, ValueError, TypeError, KeyError, UnicodeError):
            return request.make_json_response({'ok': False, 'error': 'invalid_payload'}, status=422)
        except AccessError:
            return request.make_json_response({'ok': False, 'error': 'integration_user_permissions'}, status=403)
        except (UserError, ValidationError):
            return request.make_json_response({'ok': False, 'error': 'configuration_or_business_rule'}, status=422)
        except Exception:
            # No raw payload, customer info, exception text or gateway responses in logs.
            _logger.error('MW inbound operation failed; connector=%s', connector.id)
            return request.make_json_response({'ok': False, 'error': 'temporary_server_error'}, status=500)
        return request.make_json_response(result)
