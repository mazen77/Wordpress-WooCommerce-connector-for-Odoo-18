{
    'name': 'WooCommerce Connector (Odoo 18 Module)',
    'version': '18.0.1.0.0',
    'summary': 'Fast signed WooCommerce catalog, real variants, customer, order and stock sync',
    'author': 'mazen',
    'license': 'LGPL-3',
    'category': 'Sales/Sales',
    'depends': ['sale_management', 'sale_stock', 'stock', 'contacts'],
    'external_dependencies': {'python': ['requests', 'PIL']},
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'data/woo_data.xml',
        'data/cron.xml',
        'views/connector_views.xml',
        'views/record_views.xml'
    ],
    'application': True, 'installable': True,
}
