from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
cat = (ROOT / 'models' / 'catalog.py').read_text()
stock = (ROOT / 'models' / 'stock.py').read_text()
webhook = (ROOT / 'controllers' / 'webhook.py').read_text()
assert "_create_product_variant" in cat
assert "product.template.attribute.line" in cat
assert "create_variant': 'dynamic'" in cat
assert "clean_text" in cat
assert "('sync_state', '=', 'done')" in stock
assert '.stream' not in webhook
print('v2.1 source-contract tests passed')
