import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('protocol', ROOT / 'protocol.py')
protocol = importlib.util.module_from_spec(spec)
spec.loader.exec_module(protocol)


def expect_error(fn, code):
    try:
        fn()
    except protocol.ProtocolError as exc:
        assert str(exc) == code, (str(exc), code)
    else:
        raise AssertionError('Expected ProtocolError: ' + code)


def main():
    assert protocol.clean_text('<span> - </span> Blue&nbsp; Lens') == '- Blue Lens'
    item1 = {'kind': 'product', 'id': 10, 'version': 2, 'event_id': 'x', 'data': {'id': 10}}
    item2 = {'kind': 'customer', 'id': 11, 'version': 3, 'event_id': 'y', 'data': {'id': 11}}
    env = {'schema': 2, 'store': 'STOREKEY123456789', 'kind': 'batch', 'items': [item1, item2]}
    assert protocol.validate_envelope(env, 'STOREKEY123456789') is env
    expect_error(lambda: protocol.validate_envelope({**env, 'items': []}, 'STOREKEY123456789'), 'invalid_batch')
    expect_error(lambda: protocol.validate_envelope({**env, 'items': [item1] * 51}, 'STOREKEY123456789'), 'invalid_batch')
    nested = {'kind': 'batch', 'id': 1, 'version': 1, 'data': {'id': 1}}
    expect_error(lambda: protocol.validate_envelope({**env, 'items': [nested]}, 'STOREKEY123456789'), 'unknown_entity')
    print('v2.1 protocol tests passed')


if __name__ == '__main__':
    main()
