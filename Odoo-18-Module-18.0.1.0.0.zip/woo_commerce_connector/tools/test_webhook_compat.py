#!/usr/bin/env python3
"""Isolated controller regression tests; no Odoo DB or network is used.

Run: python tools/test_webhook_compat.py
These tests use a deliberately restricted HTTPRequest double that exposes the
public members used by the controller but NOT .stream or private WSGI access.
The real controller and HMAC implementation are executed. ORM operations and
framework response/exception types are stubbed, not live Odoo integration tests.
"""
import ast
import contextlib
import importlib.util
import io
import json
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch

ADDON = Path(__file__).resolve().parents[1]
SECRET = 'test-only-secret-' * 4
STORE = 'test-store'
NOW = 1788704993
BODY = b'{"schema":2,"store":"test-store","kind":"ping"}'
MISSING = object()


class BadRequest(Exception):
    pass


class RequestEntityTooLarge(Exception):
    pass


class AccessError(Exception):
    pass


class UserError(Exception):
    pass


class ValidationError(UserError):
    pass


def _route(path, **options):
    def decorate(fn):
        fn.routing = dict(options, routes=[path])
        return fn
    return decorate


def _load_controller():
    http = types.ModuleType('odoo.http')
    http.Controller = type('Controller', (), {})
    http.route = _route
    http.request = None
    odoo = types.ModuleType('odoo')
    odoo.http = http
    exceptions = types.ModuleType('odoo.exceptions')
    exceptions.AccessError = AccessError
    exceptions.UserError = UserError
    exceptions.ValidationError = ValidationError
    wz = types.ModuleType('werkzeug')
    wz_exc = types.ModuleType('werkzeug.exceptions')
    wz_exc.BadRequest = BadRequest
    wz_exc.RequestEntityTooLarge = RequestEntityTooLarge
    wz.exceptions = wz_exc
    package = types.ModuleType('_mw_compat')
    package.__path__ = [str(ADDON)]
    controllers = types.ModuleType('_mw_compat.controllers')
    controllers.__path__ = [str(ADDON/'controllers')]
    modules = {'odoo': odoo, 'odoo.http': http, 'odoo.exceptions': exceptions,
               'werkzeug': wz, 'werkzeug.exceptions': wz_exc,
               '_mw_compat': package, '_mw_compat.controllers': controllers}
    with patch.dict(sys.modules, modules):
        spec = importlib.util.spec_from_file_location('_mw_compat.protocol', ADDON/'protocol.py')
        protocol = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = protocol
        spec.loader.exec_module(protocol)
        spec = importlib.util.spec_from_file_location('_mw_compat.controllers.webhook', ADDON/'controllers/webhook.py')
        controller = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = controller
        spec.loader.exec_module(controller)
    return controller, protocol


W, P = _load_controller()


class HTTPRequest:
    """Strict public API double, deliberately lacking .stream and .environ."""
    __slots__ = ('headers', 'content_length', 'max_content_length', '_input',
                 '_cached', 'read_calls', 'get_data_calls', 'error', 'last_options')

    def __init__(self, raw, *, length=MISSING, headers=None, error=None):
        self.headers = dict(headers or {})
        self.content_length = len(raw) if length is MISSING else length
        self.max_content_length = 128 * 1024 * 1024
        self._input = io.BytesIO(raw)
        self._cached = None
        self.read_calls = 0
        self.get_data_calls = 0
        self.error = error
        self.last_options = None

    def get_data(self, cache=True, as_text=False, parse_form_data=False):
        self.get_data_calls += 1
        self.last_options = (cache, as_text, parse_form_data)
        if self.error:
            raise self.error
        if self._cached is not None:
            data = self._cached
        else:
            self.read_calls += 1
            data = self._input.read()
            if self.max_content_length is not None and len(data) > self.max_content_length:
                raise RequestEntityTooLarge()
            if cache:
                self._cached = data
        return data.decode('utf-8', errors='replace') if as_text else data


class Cursor:
    def __init__(self):
        self.savepoints = 0
        self.rollbacks = 0

    @contextlib.contextmanager
    def savepoint(self):
        self.savepoints += 1
        try:
            yield
        except Exception:
            self.rollbacks += 1
            raise


class Connector:
    def __init__(self):
        self.id = 7
        self.incoming_secret = SECRET
        self.company_id = types.SimpleNamespace(id=9)
        self.integration_user_id = types.SimpleNamespace(id=11)
        self.dispatched = []
        self.scope = {}
        self.exception = None

    def with_user(self, user):
        self.scope['user'] = user
        return self

    def with_company(self, company):
        self.scope['company'] = company
        return self

    def with_context(self, **context):
        self.scope['context'] = context
        return self

    def _dispatch(self, data):
        self.dispatched.append(data)
        if self.exception:
            raise self.exception
        P.validate_envelope(data, STORE)
        if data['kind'] == 'ping':
            return {'ok': True, 'schema': 2, 'odoo_version': 18}
        return {'ok': True, 'kind': data['kind'], 'id': data['id'], 'version': data['version']}


class Env:
    def __init__(self, connector):
        self.connector = connector
        self.cr = Cursor()
        self.searches = []

    def __getitem__(self, model):
        assert model == 'mw.connector', model
        return self

    def sudo(self):
        return self

    def search(self, domain, limit):
        self.searches.append((domain, limit))
        return self.connector


class Request:
    def __init__(self, httprequest, connector):
        self.httprequest = httprequest
        self.env = Env(connector)

    @staticmethod
    def make_json_response(data, status=200):
        return types.SimpleNamespace(data=data, status_code=status)


def make_request(raw=BODY, *, length=MISSING, headers=None, connector=MISSING, error=None):
    auth = {'X-MW-Store': STORE, 'X-MW-Timestamp': str(NOW),
            'X-MW-Signature': P.signed(raw, str(NOW), SECRET)}
    auth.update(headers or {})
    return Request(HTTPRequest(raw, length=length, headers=auth, error=error),
                   Connector() if connector is MISSING else connector)


def call(req):
    with patch.object(W, 'request', req), patch.object(W.time, 'time', return_value=NOW):
        return W.CommerceWebhook().event()


class WebhookCompatibilityTests(unittest.TestCase):
    def assert_error(self, req, status, code, *, no_dispatch=True):
        result = call(req)
        self.assertEqual(result.status_code, status)
        self.assertEqual(result.data, {'ok': False, 'error': code})
        if no_dispatch and req.env.connector:
            self.assertEqual(req.env.connector.dispatched, [])
        return result

    def test_original_stream_error_reproduced(self):
        req = make_request()
        with self.assertRaisesRegex(AttributeError, "'HTTPRequest' object has no attribute 'stream'"):
            req.httprequest.stream.read(2097153)

    def test_signed_ping_passes(self):
        req = make_request()
        result = call(req)
        self.assertEqual(result.status_code, 200)
        self.assertEqual(result.data, {'ok': True, 'schema': 2, 'odoo_version': 18})
        self.assertEqual(req.httprequest.last_options, (True, False, False))
        self.assertEqual(req.httprequest.max_content_length, W.MAX_BODY_BYTES)

    def test_scoped_service_user_company_and_savepoint(self):
        req = make_request()
        call(req)
        c = req.env.connector
        self.assertIs(c.scope['user'], c.integration_user_id)
        self.assertIs(c.scope['company'], c.company_id)
        self.assertEqual(c.scope['context']['allowed_company_ids'], [9])
        self.assertEqual(req.env.cr.savepoints, 1)
        self.assertEqual(req.env.searches, [([('store_key', '=', STORE), ('enabled', '=', True)], 1)])

    def test_signed_customer_preserves_utf8_and_whitespace(self):
        data = {'schema': 2, 'store': STORE, 'kind': 'customer', 'id': 51, 'version': 1,
                'data': {'id': 51, 'name': '\u0645\u0627\u0632\u0646', 'city': '\u0627\u0644\u0631\u064a\u0627\u0636'}}
        raw = ('  ' + json.dumps(data, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
        req = make_request(raw)
        self.assertEqual(call(req).status_code, 200)
        self.assertEqual(req.env.connector.dispatched, [data])

    def test_product_and_order_envelopes_reach_dispatch(self):
        for kind in ('product', 'order'):
            with self.subTest(kind=kind):
                data = {'schema': 2, 'store': STORE, 'kind': kind, 'id': 1, 'version': 3, 'data': {'id': 1}}
                req = make_request(json.dumps(data).encode())
                self.assertEqual(call(req).status_code, 200)
                self.assertEqual(req.env.connector.dispatched, [data])

    def test_cached_body_survives_second_controller_call(self):
        req = make_request()
        self.assertEqual(call(req).status_code, 200)
        self.assertEqual(call(req).status_code, 200)
        self.assertEqual(req.httprequest.read_calls, 1)
        self.assertEqual(req.httprequest.get_data_calls, 2)

    def test_pre_cached_body_works(self):
        req = make_request()
        req.httprequest.get_data()
        self.assertEqual(call(req).status_code, 200)
        self.assertEqual(req.httprequest.read_calls, 1)

    def test_limit_exactly_two_mib_accepted(self):
        raw = BODY + b' ' * (W.MAX_BODY_BYTES - len(BODY))
        self.assertEqual(call(make_request(raw)).status_code, 200)

    def test_advertised_large_body_rejected_before_read_or_db(self):
        req = make_request(length=W.MAX_BODY_BYTES + 1)
        self.assert_error(req, 413, 'body_too_large')
        self.assertEqual(req.httprequest.get_data_calls, 0)
        self.assertEqual(req.env.searches, [])

    def test_missing_length_rejected_before_read_or_db(self):
        req = make_request(length=None)
        self.assert_error(req, 411, 'content_length_required')
        self.assertEqual(req.httprequest.get_data_calls, 0)
        self.assertEqual(req.env.searches, [])

    def test_empty_body_rejected_without_read(self):
        req = make_request(b'')
        self.assert_error(req, 422, 'invalid_payload')
        self.assertEqual(req.httprequest.get_data_calls, 0)

    def test_negative_length_rejected(self):
        req = make_request(length=-1)
        self.assert_error(req, 422, 'invalid_payload')
        self.assertEqual(req.httprequest.get_data_calls, 0)

    def test_chunked_transfer_rejected_before_read(self):
        req = make_request(headers={'Transfer-Encoding': 'chunked'})
        self.assert_error(req, 400, 'unsupported_transfer_encoding')
        self.assertEqual(req.httprequest.get_data_calls, 0)

    def test_wrong_length_rejected(self):
        for delta in (-1, 1):
            with self.subTest(delta=delta):
                req = make_request(length=len(BODY) + delta)
                self.assert_error(req, 400, 'invalid_request_body')
                self.assertEqual(req.env.searches, [])

    def test_werkzeug_size_exception_returns_413(self):
        self.assert_error(make_request(error=RequestEntityTooLarge()), 413, 'body_too_large')

    def test_werkzeug_disconnect_exception_returns_400(self):
        self.assert_error(make_request(error=BadRequest()), 400, 'invalid_request_body')

    def test_stricter_existing_request_limit_not_increased(self):
        req = make_request()
        req.httprequest.max_content_length = len(BODY) - 1
        self.assert_error(req, 413, 'body_too_large')
        self.assertEqual(req.httprequest.max_content_length, len(BODY) - 1)

    def test_default_none_limit_is_set(self):
        req = make_request()
        req.httprequest.max_content_length = None
        self.assertEqual(call(req).status_code, 200)
        self.assertEqual(req.httprequest.max_content_length, W.MAX_BODY_BYTES)

    def test_large_precached_body_still_rejected(self):
        req = make_request(length=1)
        req.httprequest._cached = b'x' * (W.MAX_BODY_BYTES + 1)
        self.assert_error(req, 413, 'body_too_large')
        self.assertEqual(req.env.searches, [])

    def test_tampered_payload_is_unauthorized(self):
        sig = P.signed(BODY, str(NOW), SECRET)
        req = make_request(BODY + b' ', headers={'X-MW-Signature': sig})
        self.assert_error(req, 401, 'unauthorized')

    def test_invalid_signatures_are_401_not_500(self):
        for signature in ('', 'x' * 64, 'a' * 63, '\u00e9' * 64):
            with self.subTest(signature=signature[:4]):
                req = make_request(headers={'X-MW-Signature': signature})
                self.assert_error(req, 401, 'unauthorized')

    def test_bad_or_expired_timestamp(self):
        for ts in ('', 'bad', '-1', '9' * 20, str(NOW - 301), str(NOW + 301)):
            with self.subTest(ts=ts):
                self.assert_error(make_request(headers={'X-MW-Timestamp': ts}), 401, 'unauthorized')

    def test_unknown_connector_is_401(self):
        self.assert_error(make_request(connector=None), 401, 'unauthorized')

    def test_excessive_store_key_rejected_without_db_search(self):
        req = make_request(headers={'X-MW-Store': 'x' * 81})
        self.assert_error(req, 401, 'unauthorized')
        self.assertEqual(req.env.searches, [])

    def test_signed_invalid_json_is_422(self):
        self.assert_error(make_request(b'{'), 422, 'invalid_payload')

    def test_signed_invalid_utf8_is_422(self):
        self.assert_error(make_request(b'\xff\xfe'), 422, 'invalid_payload')

    def test_wrong_envelope_is_422_and_rolls_back_savepoint(self):
        req = make_request(b'{"schema":1,"kind":"ping","store":"test-store"}')
        self.assert_error(req, 422, 'invalid_payload', no_dispatch=False)
        self.assertEqual(req.env.cr.rollbacks, 1)

    def test_permission_error_is_403(self):
        req = make_request()
        req.env.connector.exception = AccessError('private details')
        self.assert_error(req, 403, 'integration_user_permissions', no_dispatch=False)
        self.assertEqual(req.env.cr.rollbacks, 1)

    def test_business_error_is_422(self):
        for exc in (UserError('private details'), ValidationError('private details')):
            with self.subTest(exc=type(exc).__name__):
                req = make_request()
                req.env.connector.exception = exc
                self.assert_error(req, 422, 'configuration_or_business_rule', no_dispatch=False)

    def test_unexpected_error_does_not_expose_details(self):
        req = make_request()
        req.env.connector.exception = RuntimeError('private customer details')
        with self.assertLogs(W._logger, level='ERROR') as logs:
            result = self.assert_error(req, 500, 'temporary_server_error', no_dispatch=False)
        self.assertNotIn('private customer', str(result.data) + str(logs.output))
        self.assertNotIn(SECRET, str(logs.output))
        self.assertEqual(req.env.cr.rollbacks, 1)

    def test_route_remains_post_only_with_early_body_cap(self):
        routing = W.CommerceWebhook.event.routing
        self.assertEqual(routing['routes'], ['/mw-sync/v2/event'])
        self.assertEqual(routing['methods'], ['POST'])
        self.assertEqual(routing['type'], 'http')
        self.assertEqual(routing['auth'], 'public')
        self.assertIs(routing['csrf'], False)
        self.assertIs(routing['save_session'], False)
        self.assertEqual(routing['max_content_length'], 2097152)

    def test_source_avoids_stream_private_wsgi_or_disabling_auth(self):
        tree = ast.parse((ADDON/'controllers/webhook.py').read_text())
        attributes = {node.attr for node in ast.walk(tree) if isinstance(node, ast.Attribute)}
        self.assertNotIn('stream', attributes)
        self.assertNotIn('_HTTPRequest__wrapped', attributes)
        self.assertNotIn('environ', attributes)
        self.assertIn('get_data', attributes)
        self.assertIn('max_content_length', attributes)


if __name__ == '__main__':
    unittest.main(verbosity=2)
