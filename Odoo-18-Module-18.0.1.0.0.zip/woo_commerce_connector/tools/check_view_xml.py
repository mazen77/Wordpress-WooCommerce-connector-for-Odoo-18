#!/usr/bin/env python3
"""Read-only regression check for Odoo 18 file-backed XML view loading.

Run with the same Python environment as Odoo (lxml is required):
    python tools/check_view_xml.py

This tool is not imported by the addon. It does not connect to Odoo, a database,
WordPress, or a network. It is a focused source check, not an Odoo UI test.
"""
import argparse
import ast
import sys
from pathlib import Path

from lxml import etree


def read_record_arch(field):
    """Exercise the failing record branch, not the complete Odoo loader.

    Reference: Odoo 18.0, odoo/addons/base/models/ir_ui_view.py,
    get_view_arch_from_file(). All views in this addon have exactly one root,
    so Odoo's multiple-root normalization is not involved here. Keep the direct
    text concatenation: replacing it with `(field.text or '')` would hide the bug.
    """
    if len(field) != 1:
        raise ValueError('Expected exactly one architecture root in this addon')
    inner = ''.join(etree.tostring(child, encoding='unicode')
                    for child in field.iterchildren())
    return field.text + inner


def inspect_addon(addon):
    manifest_path = addon / '__manifest__.py'
    manifest = ast.literal_eval(manifest_path.read_text(encoding='utf-8'))
    results = []
    for relative in manifest.get('data', []):
        if not relative.endswith('.xml'):
            continue
        path = (addon / relative).resolve()
        if not path.is_relative_to(addon.resolve()):
            raise ValueError('Manifest data path escapes addon directory')
        # Do not use remove_blank_text=True; that would strip the required text.
        parser = etree.XMLParser(resolve_entities=False, no_network=True)
        document = etree.parse(str(path), parser)
        for record in document.xpath('//record[@model="ir.ui.view"]'):
            xmlid = 'woo_commerce_connector.' + record.get('id', '<missing-id>')
            fields = record.findall('field[@name="arch"]')
            try:
                if len(fields) != 1:
                    raise ValueError('Expected one architecture field')
                architecture = read_record_arch(fields[0])
                etree.fromstring(architecture.encode('utf-8'), parser)
            except (TypeError, ValueError, etree.XMLSyntaxError) as exc:
                results.append((xmlid, False, type(exc).__name__ + ': ' + str(exc)))
            else:
                results.append((xmlid, True, 'architecture read and parsed'))
    if not results:
        raise ValueError('No addon view records found')
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--addon-dir', type=Path,
                        default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    try:
        results = inspect_addon(args.addon_dir.resolve())
    except (OSError, ValueError, SyntaxError, etree.XMLSyntaxError) as exc:
        print('ERROR: ' + str(exc), file=sys.stderr)
        return 2
    for xmlid, passed, message in results:
        print(('PASS' if passed else 'FAIL') + ' ' + xmlid + ': ' + message)
    failures = sum(not passed for _, passed, _ in results)
    print(f'{len(results) - failures}/{len(results)} views passed; {failures} failed.')
    return 1 if failures else 0


if __name__ == '__main__':
    raise SystemExit(main())
