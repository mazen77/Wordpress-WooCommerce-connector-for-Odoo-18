from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
stock = (ROOT / 'models' / 'stock.py').read_text()
connector = (ROOT / 'models' / 'connector.py').read_text()
view = (ROOT / 'views' / 'connector_views.xml').read_text()

assert "domain.append(('company_id', 'in'" in stock
assert '_mw_company_product_pairs' in stock
assert 'company_ids=[company_id]' in stock
assert 'pg_try_advisory_xact_lock' in stock
assert 'stock_request_batch_size' in stock
assert 'waiting_for_order_reservation' in stock
assert 'Woo product is temporarily busy' in stock
assert 'stock_deferred_retry_seconds' in stock
assert 'stock_guard_retry_seconds' in stock
assert "[('next_attempt', '=', False)]" in stock
assert "[('next_attempt', '!=', False), ('next_attempt', '<=', now)]" in stock
assert "order='next_attempt,id'" in stock
assert 'stock_request_batch_size' in connector
assert 'stock_deferred_retry_seconds' in connector
assert 'stock_guard_retry_seconds' in connector
assert 'stock_request_batch_size' in view
assert 'stock_guard_retry_seconds' in view
print('stock company/throttle source-contract tests passed')
