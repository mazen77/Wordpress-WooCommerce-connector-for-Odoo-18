"""Pure validation helpers shared by the running connector and unit tests."""
import hashlib
import hmac
import html
import json
import re
from decimal import Decimal, InvalidOperation
from datetime import datetime, timezone


class ProtocolError(ValueError):
    pass


def clean_text(value, limit=512):
    """Convert Woo/HTML-ish labels into safe plain text for Odoo names."""
    text = html.unescape(str(value or ''))
    text = re.sub(r'<[^>]*>', ' ', text)
    text = text.replace('\xa0', ' ').replace('\u200b', '').replace('\ufeff', '')
    text = re.sub(r'\s+', ' ', text).strip()
    return text[:limit]


def number(value, *, nonnegative=False):
    if isinstance(value, bool):
        raise ProtocolError('invalid_number')
    try:
        n = Decimal(str(value if value not in ('', None) else 0))
    except (InvalidOperation, ValueError):
        raise ProtocolError('invalid_number') from None
    if not n.is_finite() or abs(n) > Decimal('1000000000000') or (nonnegative and n < 0):
        raise ProtocolError('invalid_number')
    return n


def integer(value, *, positive=True):
    if isinstance(value, bool) or not isinstance(value, int):
        raise ProtocolError('invalid_integer')
    if value < (1 if positive else 0) or value > 2147483647:
        raise ProtocolError('integer_out_of_range')
    return value


def signed(raw, timestamp, secret):
    return hmac.new(secret.encode('utf-8'), str(timestamp).encode('ascii') + b'.' + raw, hashlib.sha256).hexdigest()


def authorized(raw, timestamp, signature, secret, now):
    if not isinstance(timestamp, str) or not timestamp.isascii() or not timestamp.isdigit() or len(timestamp) > 12:
        return False
    if len(secret or '') < 32 or abs(int(now) - int(timestamp)) > 300 or len(signature or '') != 64:
        return False
    return hmac.compare_digest(signed(raw, timestamp, secret), signature)


def digest(data):
    return hashlib.sha256(json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def lock_key(value):
    return int.from_bytes(hashlib.sha256(value.encode()).digest()[:8], 'big', signed=True)


def parse_date(value):
    if not value:
        return False
    try:
        d = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
        if d.tzinfo:
            d = d.astimezone(timezone.utc).replace(tzinfo=None)
        return d
    except (ValueError, TypeError):
        raise ProtocolError('invalid_date') from None


def _validate_item(item):
    if not isinstance(item, dict) or item.get('kind') not in ('product', 'customer', 'order', 'exchange'):
        raise ProtocolError('unknown_entity')
    integer(item.get('id')); integer(item.get('version'))
    if not isinstance(item.get('data'), dict) or item['data'].get('id') != item['id']:
        raise ProtocolError('entity_id_mismatch')
    event_id = item.get('event_id', '')
    if event_id and (not isinstance(event_id, str) or len(event_id) > 220):
        raise ProtocolError('invalid_event_id')
    return item


def validate_envelope(d, store):
    if not isinstance(d, dict) or d.get('schema') != 2 or d.get('store') != store:
        raise ProtocolError('invalid_schema_or_store')
    if d.get('kind') == 'ping':
        return d
    if d.get('kind') == 'batch':
        items = d.get('items')
        if not isinstance(items, list) or not items or len(items) > 50:
            raise ProtocolError('invalid_batch')
        for item in items:
            _validate_item(item)
        return d
    _validate_item(d)
    return d


def validate_order(d):
    if not d.get('confirmed_at'):
        raise ProtocolError('order_not_confirmed')
    parse_date(d['confirmed_at'])
    if not isinstance(d.get('status'), str) or not d.get('currency'):
        raise ProtocolError('invalid_order_header')
    if not isinstance(d.get('line_items'), list) or not d['line_items'] or len(d['line_items']) > 500:
        raise ProtocolError('invalid_order_lines')
    if not isinstance(d.get('billing', {}), dict) or not isinstance(d.get('shipping', {}), dict):
        raise ProtocolError('invalid_addresses')
    precision = integer(d.get('decimals', 2), positive=False)
    if precision > 6:
        raise ProtocolError('invalid_currency_precision')
    unit = Decimal(10) ** -precision
    net = Decimal(0)
    tax = Decimal(0)
    for key in ('line_items', 'shipping_lines', 'fee_lines'):
        lines = d.get(key, [])
        if not isinstance(lines, list) or len(lines) > 500:
            raise ProtocolError('invalid_line_collection')
        seen = set()
        for line in lines:
            if not isinstance(line, dict):
                raise ProtocolError('invalid_line')
            lid = integer(line.get('id'))
            if lid in seen:
                raise ProtocolError('duplicate_line_id')
            seen.add(lid)
            if key == 'line_items' and number(line.get('quantity'), nonnegative=True) <= 0:
                raise ProtocolError('invalid_quantity')
            net += number(line.get('total'))
            tax += number(line.get('total_tax'))
    total = number(d.get('total'), nonnegative=True)
    if abs(net + tax - total) > unit:
        raise ProtocolError('woo_total_does_not_match_lines')
    if abs(tax - number(d.get('total_tax'))) > unit:
        raise ProtocolError('woo_tax_does_not_match_lines')
    if d.get('payment_method') != 'cod':
        expected_paid = bool(d.get('date_paid'))
        if d.get('paid') is not expected_paid:
            raise ProtocolError('paid_flag_mismatch')
    return {'net': net, 'tax': tax, 'total': total, 'unit': unit}
